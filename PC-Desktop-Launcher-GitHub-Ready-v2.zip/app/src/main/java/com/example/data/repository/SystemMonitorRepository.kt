package com.example.data.repository

import android.app.ActivityManager
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.example.data.model.SystemStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SystemMonitorRepository(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _status = MutableStateFlow(SystemStatus())
    val status: StateFlow<SystemStatus> = _status.asStateFlow()

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager

    private var monitoring = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val pct = if (level >= 0 && scale > 0) ((level * 100f) / scale).toInt() else _status.value.batteryPercent
            val statusInt = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING ||
                statusInt == BatteryManager.BATTERY_STATUS_FULL
            _status.update { it.copy(batteryPercent = pct, isCharging = charging) }
        }
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            refreshNetworkAndHardware()
        }

        override fun onLost(network: Network) {
            refreshNetworkAndHardware()
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            refreshNetworkAndHardware()
        }
    }

    fun startMonitoring() {
        if (monitoring) return
        monitoring = true

        runCatching {
            val batteryFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val sticky = context.registerReceiver(batteryReceiver, batteryFilter)
            if (sticky != null) batteryReceiver.onReceive(context, sticky)
        }

        runCatching {
            connectivityManager?.registerDefaultNetworkCallback(networkCallback)
        }

        refreshAll()

        scope.launch {
            while (monitoring) {
                refreshClockAndMetrics()
                delay(5000L)
            }
        }
    }

    fun stopMonitoring() {
        if (!monitoring) return
        monitoring = false
        runCatching { context.unregisterReceiver(batteryReceiver) }
        runCatching { connectivityManager?.unregisterNetworkCallback(networkCallback) }
    }

    fun refreshAll() {
        refreshNetworkAndHardware()
        refreshClockAndMetrics()
    }

    fun refreshClockAndMetrics() {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)
        val ramTotal = memInfo.totalMem
        val ramUsed = (ramTotal - memInfo.availMem).coerceAtLeast(0L)

        val stat = StatFs(Environment.getDataDirectory().path)
        val storageTotal = stat.totalBytes
        val storageAvail = stat.availableBytes
        val storageUsed = (storageTotal - storageAvail).coerceAtLeast(0L)

        val maxVol = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC)?.coerceAtLeast(1) ?: 15
        val curVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 8
        val volPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        val muted = curVol == 0 || (audioManager?.isStreamMute(AudioManager.STREAM_MUSIC) == true)

        val maxRing = audioManager?.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION)?.coerceAtLeast(1) ?: 7
        val curRing = audioManager?.getStreamVolume(AudioManager.STREAM_NOTIFICATION) ?: 5
        val ringPct = ((curRing * 100f) / maxRing).toInt().coerceIn(0, 100)

        _status.update {
            it.copy(
                currentTimeMillis = System.currentTimeMillis(),
                ramTotalBytes = ramTotal,
                ramUsedBytes = ramUsed,
                storageTotalBytes = storageTotal,
                storageUsedBytes = storageUsed,
                volumePercent = volPct,
                ringVolumePercent = ringPct,
                isMuted = muted,
                isDefaultLauncher = isDefaultHomeLauncher(),
                supportsFreeformWindows = context.packageManager.hasSystemFeature(
                    PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT
                )
            )
        }
    }

    private fun refreshNetworkAndHardware() {
        val activeNetwork = connectivityManager?.activeNetwork
        val caps = connectivityManager?.getNetworkCapabilities(activeNetwork)
        val hasWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val hasCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val wifiEnabled = runCatching { wifiManager?.isWifiEnabled == true }.getOrDefault(hasWifi)
        val signalLevel = if (hasWifi) {
            runCatching {
                @Suppress("DEPRECATION")
                val rssi = wifiManager?.connectionInfo?.rssi ?: -60
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    wifiManager?.calculateSignalLevel(rssi) ?: 3
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.calculateSignalLevel(rssi, 5)
                }
            }.getOrDefault(3)
        } else 0

        val btEnabled = runCatching {
            val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            btManager?.adapter?.isEnabled == true
        }.getOrDefault(false)

        _status.update {
            it.copy(
                wifiConnected = hasWifi,
                wifiEnabled = wifiEnabled,
                wifiSignalLevel = signalLevel.coerceIn(0, 4),
                mobileConnected = hasCellular,
                bluetoothEnabled = btEnabled
            )
        }
    }

    fun setMediaVolumePercent(percent: Int) {
        val am = audioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val target = ((percent.coerceIn(0, 100) / 100f) * maxVol).toInt().coerceIn(0, maxVol)
        runCatching {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        }
        refreshClockAndMetrics()
    }

    fun setRingVolumePercent(percent: Int) {
        val am = audioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION).coerceAtLeast(1)
        val target = ((percent.coerceIn(0, 100) / 100f) * maxVol).toInt().coerceIn(0, maxVol)
        runCatching {
            am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, target, 0)
        }
        refreshClockAndMetrics()
    }

    fun toggleMute() {
        val am = audioManager ?: return
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (current > 0) {
            runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0) }
        } else {
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, (maxVol * 0.5f).toInt().coerceAtLeast(1), 0) }
        }
        refreshClockAndMetrics()
    }

    fun isDefaultHomeLauncher(): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
        }
        val resolveInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.resolveActivity(
                intent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }
        return resolveInfo?.activityInfo?.packageName == context.packageName
    }
}
