package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.example.data.local.GalleryAlbumEntity
import com.example.data.local.GalleryMediaEntity
import com.example.data.local.LauncherDao
import com.example.data.model.GalleryAlbum
import com.example.data.model.GalleryMediaItem
import com.example.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class GalleryRepository(
    private val context: Context,
    private val dao: LauncherDao
) {
    val albums: Flow<List<GalleryAlbum>> = dao.observeGalleryAlbums().map { list ->
        list.map { it.toDomain() }
    }

    val mediaItems: Flow<List<GalleryMediaItem>> = dao.observeGalleryMedia().map { list ->
        list.map { it.toDomain() }
    }

    private fun galleryRootDir(): File {
        val dir = File(context.filesDir, "pc_gallery")
        if (!dir.exists()) dir.mkdirs()
        val nomedia = File(dir, ".nomedia")
        if (!nomedia.exists()) {
            runCatching { nomedia.createNewFile() }
        }
        return dir
    }

    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        galleryRootDir()
        if (dao.countGalleryAlbums() > 0) return@withContext
        val now = System.currentTimeMillis()
        dao.upsertGalleryAlbum(
            GalleryAlbumEntity(
                id = DEFAULT_ALBUM_IMPORTS,
                name = "Camera & Imports",
                isPrivate = false,
                createdAt = now
            )
        )
        dao.upsertGalleryAlbum(
            GalleryAlbumEntity(
                id = DEFAULT_ALBUM_CAPTURES,
                name = "Screenshots & Captures",
                isPrivate = false,
                createdAt = now + 1
            )
        )
        dao.upsertGalleryAlbum(
            GalleryAlbumEntity(
                id = DEFAULT_ALBUM_PRIVATE_SAFE,
                name = "Private Safe",
                isPrivate = true,
                createdAt = now + 2
            )
        )
    }

    suspend fun createAlbum(name: String, isPrivate: Boolean): GalleryAlbum = withContext(Dispatchers.IO) {
        val cleanName = name.trim().ifEmpty { if (isPrivate) "Private Album" else "New Album" }
        val entity = GalleryAlbumEntity(
            id = "album_${UUID.randomUUID().toString().take(8)}",
            name = cleanName,
            isPrivate = isPrivate,
            createdAt = System.currentTimeMillis()
        )
        dao.upsertGalleryAlbum(entity)
        entity.toDomain()
    }

    suspend fun renameAlbum(albumId: String, newName: String) = withContext(Dispatchers.IO) {
        val clean = newName.trim()
        if (clean.isEmpty()) return@withContext
        val existing = dao.getGalleryAlbum(albumId) ?: return@withContext
        dao.upsertGalleryAlbum(existing.copy(name = clean))
    }

    suspend fun deleteAlbum(albumId: String) = withContext(Dispatchers.IO) {
        if (albumId == DEFAULT_ALBUM_IMPORTS || albumId == DEFAULT_ALBUM_PRIVATE_SAFE) return@withContext
        val album = dao.getGalleryAlbum(albumId) ?: return@withContext
        val fallbackAlbumId = if (album.isPrivate) DEFAULT_ALBUM_PRIVATE_SAFE else DEFAULT_ALBUM_IMPORTS
        val items = dao.getGalleryMediaForAlbum(albumId)
        items.forEach { item ->
            dao.upsertGalleryMedia(item.copy(albumId = fallbackAlbumId, isPrivate = album.isPrivate))
        }
        dao.deleteGalleryAlbumById(albumId)
    }

    suspend fun importMediaUris(
        uris: List<Uri>,
        targetAlbumId: String = DEFAULT_ALBUM_IMPORTS,
        markPrivate: Boolean = false
    ): Result<List<GalleryMediaItem>> = withContext(Dispatchers.IO) {
        runCatching {
            ensureSeeded()
            val album = dao.getGalleryAlbum(targetAlbumId)
            val resolvedAlbumId = album?.id ?: if (markPrivate) DEFAULT_ALBUM_PRIVATE_SAFE else DEFAULT_ALBUM_IMPORTS
            val isPrivateAlbum = markPrivate || (album?.isPrivate == true)
            val root = galleryRootDir()
            val imported = mutableListOf<GalleryMediaItem>()

            uris.forEach { uri ->
                val rawMime = context.contentResolver.getType(uri) ?: guessMimeFromUri(uri)
                val isVideo = rawMime.startsWith("video/")
                val mediaType = if (isVideo) MediaType.VIDEO else MediaType.PHOTO
                val originalName = queryDisplayName(uri)
                    ?: if (isVideo) "Video_${System.currentTimeMillis()}.mp4" else "Photo_${System.currentTimeMillis()}.jpg"
                val ext = originalName.substringAfterLast('.', "").takeIf { it.isNotBlank() }
                    ?: MimeTypeMap.getSingleton().getExtensionFromMimeType(rawMime)
                    ?: if (isVideo) "mp4" else "jpg"

                val id = "media_${UUID.randomUUID().toString().take(10)}"
                val destFile = File(root, "$id.$ext")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                } ?: error("Unable to read selected media item.")

                val durationMs = if (isVideo) extractVideoDuration(destFile.absolutePath) else 0L
                val entity = GalleryMediaEntity(
                    id = id,
                    albumId = resolvedAlbumId,
                    displayName = originalName,
                    mediaType = mediaType.name,
                    filePath = destFile.absolutePath,
                    mimeType = rawMime,
                    sizeBytes = destFile.length(),
                    durationMs = durationMs,
                    addedAt = System.currentTimeMillis(),
                    isPrivate = isPrivateAlbum
                )
                dao.upsertGalleryMedia(entity)
                imported.add(entity.toDomain())
            }
            imported
        }
    }

    suspend fun importLocalFile(
        sourceFile: File,
        targetAlbumId: String = DEFAULT_ALBUM_IMPORTS,
        markPrivate: Boolean = false
    ): Result<GalleryMediaItem> = withContext(Dispatchers.IO) {
        runCatching {
            ensureSeeded()
            require(sourceFile.exists() && sourceFile.isFile) { "Source file missing" }
            val ext = sourceFile.extension.lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: if (ext in setOf("mp4", "mkv", "webm", "mov")) "video/mp4" else "image/jpeg"
            val isVideo = mime.startsWith("video/")
            val id = "media_${UUID.randomUUID().toString().take(10)}"
            val destFile = File(galleryRootDir(), "$id.${ext.ifBlank { if (isVideo) "mp4" else "jpg" }}")
            sourceFile.copyTo(destFile, overwrite = true)

            val album = dao.getGalleryAlbum(targetAlbumId)
            val resolvedAlbumId = album?.id ?: if (markPrivate) DEFAULT_ALBUM_PRIVATE_SAFE else DEFAULT_ALBUM_IMPORTS
            val isPrivate = markPrivate || (album?.isPrivate == true)
            val entity = GalleryMediaEntity(
                id = id,
                albumId = resolvedAlbumId,
                displayName = sourceFile.name,
                mediaType = if (isVideo) MediaType.VIDEO.name else MediaType.PHOTO.name,
                filePath = destFile.absolutePath,
                mimeType = mime,
                sizeBytes = destFile.length(),
                durationMs = if (isVideo) extractVideoDuration(destFile.absolutePath) else 0L,
                addedAt = System.currentTimeMillis(),
                isPrivate = isPrivate
            )
            dao.upsertGalleryMedia(entity)
            entity.toDomain()
        }
    }

    suspend fun moveMediaToAlbum(mediaId: String, targetAlbumId: String) = withContext(Dispatchers.IO) {
        val item = dao.getGalleryMediaById(mediaId) ?: return@withContext
        val album = dao.getGalleryAlbum(targetAlbumId) ?: return@withContext
        dao.upsertGalleryMedia(item.copy(albumId = album.id, isPrivate = album.isPrivate))
    }

    suspend fun setMediaPrivate(mediaId: String, makePrivate: Boolean) = withContext(Dispatchers.IO) {
        val item = dao.getGalleryMediaById(mediaId) ?: return@withContext
        val targetAlbum = if (makePrivate) {
            DEFAULT_ALBUM_PRIVATE_SAFE
        } else {
            if (item.albumId == DEFAULT_ALBUM_PRIVATE_SAFE) DEFAULT_ALBUM_IMPORTS else item.albumId
        }
        dao.upsertGalleryMedia(item.copy(albumId = targetAlbum, isPrivate = makePrivate))
    }

    suspend fun renameMedia(mediaId: String, newName: String) = withContext(Dispatchers.IO) {
        val clean = newName.trim()
        if (clean.isEmpty()) return@withContext
        val item = dao.getGalleryMediaById(mediaId) ?: return@withContext
        dao.upsertGalleryMedia(item.copy(displayName = clean))
    }

    suspend fun deleteMedia(mediaId: String) = withContext(Dispatchers.IO) {
        val item = dao.getGalleryMediaById(mediaId) ?: return@withContext
        runCatching { File(item.filePath).delete() }
        dao.deleteGalleryMediaById(mediaId)
    }

    suspend fun exportMediaToUri(mediaItem: GalleryMediaItem, destUri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(mediaItem.filePath)
            require(src.exists()) { "Media file no longer exists." }
            context.contentResolver.openOutputStream(destUri)?.use { out ->
                src.inputStream().use { input ->
                    input.copyTo(out)
                }
            } ?: error("Unable to open destination file for export.")
            Unit
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
        }.getOrNull()
    }

    private fun guessMimeFromUri(uri: Uri): String {
        val ext = uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase().orEmpty()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "image/jpeg"
    }

    private fun extractVideoDuration(path: String): Long {
        val retriever = MediaMetadataRetriever()
        return runCatching {
            retriever.setDataSource(path)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        }.getOrDefault(0L).also {
            runCatching { retriever.release() }
        }
    }

    companion object {
        const val DEFAULT_ALBUM_IMPORTS = "album_imports"
        const val DEFAULT_ALBUM_CAPTURES = "album_captures"
        const val DEFAULT_ALBUM_PRIVATE_SAFE = "album_private_safe"
    }
}
