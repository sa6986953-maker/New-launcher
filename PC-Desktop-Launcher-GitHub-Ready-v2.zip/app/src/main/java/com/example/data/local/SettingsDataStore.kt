package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AnimationEffectStyle
import com.example.data.model.AnimationSpeed
import com.example.data.model.CornerStyle
import com.example.data.model.DesktopThemePreset
import com.example.data.model.FontStyleOption
import com.example.data.model.IconPackStyle
import com.example.data.model.IconSizeOption
import com.example.data.model.LauncherMode
import com.example.data.model.OrientationMode
import com.example.data.model.PcSettingsState
import com.example.data.model.ScreenLayoutDensity
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarSizeOption
import com.example.data.model.TaskbarStyle
import com.example.data.model.ThemeMode
import com.example.data.model.VaultAccessMethod
import com.example.data.model.WallpaperFitOption
import com.example.data.model.WallpaperPreset
import com.example.data.model.WindowAppearance
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.pcSettingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "pc_launcher_settings")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val LAUNCHER_MODE = stringPreferencesKey("launcher_mode")
        val AUTO_LAUNCH_APP_IN_DESKTOP = booleanPreferencesKey("auto_launch_app_in_desktop")
        val LOCK_SCREEN_ENABLED = booleanPreferencesKey("lock_screen_enabled")
        val LOCK_SCREEN_SECONDS = booleanPreferencesKey("lock_screen_seconds")
        val LOCK_SCREEN_BIOMETRIC = booleanPreferencesKey("lock_screen_biometric")
        val LOCK_WALLPAPER_ID = stringPreferencesKey("lock_wallpaper_id")
        val CUSTOM_LOCK_WALLPAPER_URI = stringPreferencesKey("custom_lock_wallpaper_uri")
        val VAULT_ACCESS_METHOD = stringPreferencesKey("vault_access_method")
        val VAULT_SECRET_PHRASE = stringPreferencesKey("vault_secret_phrase")
        val VAULT_BIOMETRIC = booleanPreferencesKey("vault_biometric")

        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_KEY = stringPreferencesKey("accent_key")
        val CUSTOM_ACCENT_ARGB = longPreferencesKey("custom_accent_argb")
        val DESKTOP_BG_ARGB = longPreferencesKey("desktop_bg_argb")
        val WALLPAPER_ID = stringPreferencesKey("wallpaper_id")
        val CUSTOM_WALLPAPER_URI = stringPreferencesKey("custom_wallpaper_uri")
        val WALLPAPER_FIT = stringPreferencesKey("wallpaper_fit")
        val WALLPAPER_DIM_ALPHA = floatPreferencesKey("wallpaper_dim_alpha")
        val FULL_SCREEN_IMMERSIVE = booleanPreferencesKey("full_screen_immersive")
        val ORIENTATION_MODE = stringPreferencesKey("orientation_mode")
        val DESKTOP_SCALE = floatPreferencesKey("desktop_scale")
        val SCREEN_LAYOUT = stringPreferencesKey("screen_layout")
        val ICON_SIZE = stringPreferencesKey("icon_size")
        val ICON_SCALE = floatPreferencesKey("icon_scale")
        val ICON_PACK = stringPreferencesKey("icon_pack")
        val SHOW_ICON_SCRIM = booleanPreferencesKey("show_icon_scrim")
        val AUTO_ARRANGE_GRID = booleanPreferencesKey("auto_arrange_grid")
        val SHOW_DESKTOP_CLOCK = booleanPreferencesKey("show_desktop_clock")
        val SHOW_FILE_EXTENSIONS = booleanPreferencesKey("show_file_extensions")
        val TASKBAR_POSITION = stringPreferencesKey("taskbar_position")
        val TASKBAR_SIZE = stringPreferencesKey("taskbar_size")
        val TASKBAR_HEIGHT_OVERRIDE = intPreferencesKey("taskbar_height_override")
        val TASKBAR_ICON_SPACING = intPreferencesKey("taskbar_icon_spacing")
        val TASKBAR_STYLE = stringPreferencesKey("taskbar_style")
        val TASKBAR_TRANSPARENCY = floatPreferencesKey("taskbar_transparency")
        val CUSTOM_TASKBAR_ARGB = longPreferencesKey("custom_taskbar_argb")
        val SHOW_TASKBAR_SEARCH = booleanPreferencesKey("show_taskbar_search")
        val SHOW_TASKBAR_DATE = booleanPreferencesKey("show_taskbar_date")
        val SHOW_TASKBAR_NOTIF_BADGE = booleanPreferencesKey("show_taskbar_notif_badge")
        val WINDOW_APPEARANCE = stringPreferencesKey("window_appearance")
        val CORNER_STYLE = stringPreferencesKey("corner_style")
        val FONT_STYLE = stringPreferencesKey("font_style")
        val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
        val ANIMATION_SPEED = stringPreferencesKey("animation_speed")
        val ANIMATION_EFFECT = stringPreferencesKey("animation_effect")
        val BATTERY_SAVER_MODE = booleanPreferencesKey("battery_saver_mode")
        val HAPTIC_FEEDBACK = booleanPreferencesKey("haptic_feedback")
        val SHOW_TOASTS = booleanPreferencesKey("show_toasts")
        val PREFER_FREEFORM_LAUNCH = booleanPreferencesKey("prefer_freeform_launch")
        val DEFAULT_BROWSER_PKG = stringPreferencesKey("default_browser_pkg")
        val DEFAULT_FILES_PKG = stringPreferencesKey("default_files_pkg")
        val DEFAULT_GALLERY_PKG = stringPreferencesKey("default_gallery_pkg")
        val DEFAULT_MUSIC_PKG = stringPreferencesKey("default_music_pkg")
    }

    val settingsFlow: Flow<PcSettingsState> = context.pcSettingsDataStore.data.map(::readFromPrefs)

    suspend fun update(transform: (PcSettingsState) -> PcSettingsState) {
        context.pcSettingsDataStore.edit { prefs ->
            val current = readFromPrefs(prefs)
            val next = transform(current)
            writeToPrefs(prefs, next)
        }
    }

    private fun readFromPrefs(prefs: Preferences): PcSettingsState = PcSettingsState(
        launcherMode = prefs[Keys.LAUNCHER_MODE]?.let { n -> LauncherMode.entries.firstOrNull { it.name == n } }
            ?: LauncherMode.DESKTOP,
        autoLaunchAppInDesktopMode = prefs[Keys.AUTO_LAUNCH_APP_IN_DESKTOP] ?: false,
        lockScreenEnabled = prefs[Keys.LOCK_SCREEN_ENABLED] ?: false,
        lockScreenShowClockSeconds = prefs[Keys.LOCK_SCREEN_SECONDS] ?: false,
        lockScreenBiometricEnabled = prefs[Keys.LOCK_SCREEN_BIOMETRIC] ?: true,
        lockWallpaperId = prefs[Keys.LOCK_WALLPAPER_ID] ?: WallpaperPreset.ABSTRACT_PRISM.id,
        customLockWallpaperUri = prefs[Keys.CUSTOM_LOCK_WALLPAPER_URI],
        vaultAccessMethod = prefs[Keys.VAULT_ACCESS_METHOD]?.let { n -> VaultAccessMethod.entries.firstOrNull { it.name == n } }
            ?: VaultAccessMethod.CALENDAR_HEADER_HOLD,
        vaultSecretPhrase = prefs[Keys.VAULT_SECRET_PHRASE]?.takeIf { it.isNotBlank() } ?: "//vault",
        vaultBiometricEnabled = prefs[Keys.VAULT_BIOMETRIC] ?: true,
        themePreset = prefs[Keys.THEME_PRESET]?.let { n -> DesktopThemePreset.entries.firstOrNull { it.name == n } }
            ?: DesktopThemePreset.WINDOWS_11,
        themeMode = prefs[Keys.THEME_MODE]?.let { n -> ThemeMode.entries.firstOrNull { it.name == n } }
            ?: ThemeMode.DARK,
        accentKey = prefs[Keys.ACCENT_KEY] ?: "blue",
        customAccentArgb = prefs[Keys.CUSTOM_ACCENT_ARGB],
        desktopBackgroundArgb = prefs[Keys.DESKTOP_BG_ARGB] ?: 0xFF0A192FL,
        wallpaperId = prefs[Keys.WALLPAPER_ID] ?: WallpaperPreset.BLOOM.id,
        customWallpaperUri = prefs[Keys.CUSTOM_WALLPAPER_URI],
        wallpaperFit = prefs[Keys.WALLPAPER_FIT]?.let { n -> WallpaperFitOption.entries.firstOrNull { it.name == n } }
            ?: WallpaperFitOption.CROP,
        wallpaperDimAlpha = (prefs[Keys.WALLPAPER_DIM_ALPHA] ?: 0.0f).coerceIn(0f, 0.7f),
        fullScreenImmersive = prefs[Keys.FULL_SCREEN_IMMERSIVE] ?: true,
        orientationMode = prefs[Keys.ORIENTATION_MODE]?.let { n -> OrientationMode.entries.firstOrNull { it.name == n } }
            ?: OrientationMode.LANDSCAPE,
        desktopScale = (prefs[Keys.DESKTOP_SCALE] ?: 1.0f).coerceIn(0.8f, 1.25f),
        screenLayout = prefs[Keys.SCREEN_LAYOUT]?.let { n -> ScreenLayoutDensity.entries.firstOrNull { it.name == n } }
            ?: ScreenLayoutDensity.STANDARD_PC,
        iconSize = prefs[Keys.ICON_SIZE]?.let { n -> IconSizeOption.entries.firstOrNull { it.name == n } }
            ?: IconSizeOption.MEDIUM,
        iconScale = (prefs[Keys.ICON_SCALE] ?: 1.0f).coerceIn(0.75f, 1.35f),
        iconPack = prefs[Keys.ICON_PACK]?.let { n -> IconPackStyle.entries.firstOrNull { it.name == n } }
            ?: IconPackStyle.FLUENT,
        showDesktopIconScrim = prefs[Keys.SHOW_ICON_SCRIM] ?: true,
        autoArrangeGrid = prefs[Keys.AUTO_ARRANGE_GRID] ?: false,
        showDesktopClock = prefs[Keys.SHOW_DESKTOP_CLOCK] ?: true,
        showFileExtensions = prefs[Keys.SHOW_FILE_EXTENSIONS] ?: true,
        taskbarPosition = prefs[Keys.TASKBAR_POSITION]?.let { n -> TaskbarPosition.entries.firstOrNull { it.name == n } }
            ?: TaskbarPosition.BOTTOM,
        taskbarSize = prefs[Keys.TASKBAR_SIZE]?.let { n -> TaskbarSizeOption.entries.firstOrNull { it.name == n } }
            ?: TaskbarSizeOption.STANDARD,
        taskbarHeightOverrideDp = prefs[Keys.TASKBAR_HEIGHT_OVERRIDE]?.coerceIn(36, 80),
        taskbarIconSpacingDp = (prefs[Keys.TASKBAR_ICON_SPACING] ?: 4).coerceIn(0, 16),
        taskbarStyle = prefs[Keys.TASKBAR_STYLE]?.let { n -> TaskbarStyle.entries.firstOrNull { it.name == n } }
            ?: TaskbarStyle.BLURRED,
        taskbarTransparency = (prefs[Keys.TASKBAR_TRANSPARENCY] ?: 0.84f).coerceIn(0.2f, 1.0f),
        customTaskbarArgb = prefs[Keys.CUSTOM_TASKBAR_ARGB],
        showTaskbarSearch = prefs[Keys.SHOW_TASKBAR_SEARCH] ?: true,
        showTaskbarDate = prefs[Keys.SHOW_TASKBAR_DATE] ?: true,
        showTaskbarNotificationBadge = prefs[Keys.SHOW_TASKBAR_NOTIF_BADGE] ?: true,
        windowAppearance = prefs[Keys.WINDOW_APPEARANCE]?.let { n -> WindowAppearance.entries.firstOrNull { it.name == n } }
            ?: WindowAppearance.ACRYLIC,
        cornerStyle = prefs[Keys.CORNER_STYLE]?.let { n -> CornerStyle.entries.firstOrNull { it.name == n } }
            ?: CornerStyle.ROUNDED,
        fontStyle = prefs[Keys.FONT_STYLE]?.let { n -> FontStyleOption.entries.firstOrNull { it.name == n } }
            ?: FontStyleOption.PLUS_JAKARTA,
        animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
        animationSpeed = prefs[Keys.ANIMATION_SPEED]?.let { n -> AnimationSpeed.entries.firstOrNull { it.name == n } }
            ?: AnimationSpeed.STANDARD,
        animationEffect = prefs[Keys.ANIMATION_EFFECT]?.let { n -> AnimationEffectStyle.entries.firstOrNull { it.name == n } }
            ?: AnimationEffectStyle.SPRING,
        batterySaverMode = prefs[Keys.BATTERY_SAVER_MODE] ?: false,
        hapticFeedbackEnabled = prefs[Keys.HAPTIC_FEEDBACK] ?: true,
        showToastNotifications = prefs[Keys.SHOW_TOASTS] ?: true,
        preferFreeformLaunch = prefs[Keys.PREFER_FREEFORM_LAUNCH] ?: true,
        defaultBrowserPackage = prefs[Keys.DEFAULT_BROWSER_PKG],
        defaultFilesPackage = prefs[Keys.DEFAULT_FILES_PKG],
        defaultGalleryPackage = prefs[Keys.DEFAULT_GALLERY_PKG],
        defaultMusicPackage = prefs[Keys.DEFAULT_MUSIC_PKG]
    )

    private fun writeToPrefs(prefs: androidx.datastore.preferences.core.MutablePreferences, next: PcSettingsState) {
        prefs[Keys.LAUNCHER_MODE] = next.launcherMode.name
        prefs[Keys.AUTO_LAUNCH_APP_IN_DESKTOP] = next.autoLaunchAppInDesktopMode
        prefs[Keys.LOCK_SCREEN_ENABLED] = next.lockScreenEnabled
        prefs[Keys.LOCK_SCREEN_SECONDS] = next.lockScreenShowClockSeconds
        prefs[Keys.LOCK_SCREEN_BIOMETRIC] = next.lockScreenBiometricEnabled
        prefs[Keys.LOCK_WALLPAPER_ID] = next.lockWallpaperId
        if (next.customLockWallpaperUri != null) prefs[Keys.CUSTOM_LOCK_WALLPAPER_URI] = next.customLockWallpaperUri else prefs.remove(Keys.CUSTOM_LOCK_WALLPAPER_URI)
        prefs[Keys.VAULT_ACCESS_METHOD] = next.vaultAccessMethod.name
        prefs[Keys.VAULT_SECRET_PHRASE] = next.vaultSecretPhrase
        prefs[Keys.VAULT_BIOMETRIC] = next.vaultBiometricEnabled

        prefs[Keys.THEME_PRESET] = next.themePreset.name
        prefs[Keys.THEME_MODE] = next.themeMode.name
        prefs[Keys.ACCENT_KEY] = next.accentKey
        if (next.customAccentArgb != null) prefs[Keys.CUSTOM_ACCENT_ARGB] = next.customAccentArgb else prefs.remove(Keys.CUSTOM_ACCENT_ARGB)
        prefs[Keys.DESKTOP_BG_ARGB] = next.desktopBackgroundArgb
        prefs[Keys.WALLPAPER_ID] = next.wallpaperId
        if (next.customWallpaperUri != null) prefs[Keys.CUSTOM_WALLPAPER_URI] = next.customWallpaperUri else prefs.remove(Keys.CUSTOM_WALLPAPER_URI)
        prefs[Keys.WALLPAPER_FIT] = next.wallpaperFit.name
        prefs[Keys.WALLPAPER_DIM_ALPHA] = next.wallpaperDimAlpha
        prefs[Keys.FULL_SCREEN_IMMERSIVE] = next.fullScreenImmersive
        prefs[Keys.ORIENTATION_MODE] = next.orientationMode.name
        prefs[Keys.DESKTOP_SCALE] = next.desktopScale
        prefs[Keys.SCREEN_LAYOUT] = next.screenLayout.name
        prefs[Keys.ICON_SIZE] = next.iconSize.name
        prefs[Keys.ICON_SCALE] = next.iconScale
        prefs[Keys.ICON_PACK] = next.iconPack.name
        prefs[Keys.SHOW_ICON_SCRIM] = next.showDesktopIconScrim
        prefs[Keys.AUTO_ARRANGE_GRID] = next.autoArrangeGrid
        prefs[Keys.SHOW_DESKTOP_CLOCK] = next.showDesktopClock
        prefs[Keys.SHOW_FILE_EXTENSIONS] = next.showFileExtensions
        prefs[Keys.TASKBAR_POSITION] = next.taskbarPosition.name
        prefs[Keys.TASKBAR_SIZE] = next.taskbarSize.name
        if (next.taskbarHeightOverrideDp != null) prefs[Keys.TASKBAR_HEIGHT_OVERRIDE] = next.taskbarHeightOverrideDp else prefs.remove(Keys.TASKBAR_HEIGHT_OVERRIDE)
        prefs[Keys.TASKBAR_ICON_SPACING] = next.taskbarIconSpacingDp
        prefs[Keys.TASKBAR_STYLE] = next.taskbarStyle.name
        prefs[Keys.TASKBAR_TRANSPARENCY] = next.taskbarTransparency
        if (next.customTaskbarArgb != null) prefs[Keys.CUSTOM_TASKBAR_ARGB] = next.customTaskbarArgb else prefs.remove(Keys.CUSTOM_TASKBAR_ARGB)
        prefs[Keys.SHOW_TASKBAR_SEARCH] = next.showTaskbarSearch
        prefs[Keys.SHOW_TASKBAR_DATE] = next.showTaskbarDate
        prefs[Keys.SHOW_TASKBAR_NOTIF_BADGE] = next.showTaskbarNotificationBadge
        prefs[Keys.WINDOW_APPEARANCE] = next.windowAppearance.name
        prefs[Keys.CORNER_STYLE] = next.cornerStyle.name
        prefs[Keys.FONT_STYLE] = next.fontStyle.name
        prefs[Keys.ANIMATIONS_ENABLED] = next.animationsEnabled
        prefs[Keys.ANIMATION_SPEED] = next.animationSpeed.name
        prefs[Keys.ANIMATION_EFFECT] = next.animationEffect.name
        prefs[Keys.BATTERY_SAVER_MODE] = next.batterySaverMode
        prefs[Keys.HAPTIC_FEEDBACK] = next.hapticFeedbackEnabled
        prefs[Keys.SHOW_TOASTS] = next.showToastNotifications
        prefs[Keys.PREFER_FREEFORM_LAUNCH] = next.preferFreeformLaunch
        if (next.defaultBrowserPackage != null) prefs[Keys.DEFAULT_BROWSER_PKG] = next.defaultBrowserPackage else prefs.remove(Keys.DEFAULT_BROWSER_PKG)
        if (next.defaultFilesPackage != null) prefs[Keys.DEFAULT_FILES_PKG] = next.defaultFilesPackage else prefs.remove(Keys.DEFAULT_FILES_PKG)
        if (next.defaultGalleryPackage != null) prefs[Keys.DEFAULT_GALLERY_PKG] = next.defaultGalleryPackage else prefs.remove(Keys.DEFAULT_GALLERY_PKG)
        if (next.defaultMusicPackage != null) prefs[Keys.DEFAULT_MUSIC_PKG] = next.defaultMusicPackage else prefs.remove(Keys.DEFAULT_MUSIC_PKG)
    }
}
