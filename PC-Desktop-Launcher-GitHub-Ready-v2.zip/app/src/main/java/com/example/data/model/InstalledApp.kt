package com.example.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class InstalledApp(
    val packageName: String,
    val activityName: String,
    val label: String,
    val isSystemApp: Boolean = false,
    val lastLaunchTime: Long = 0L
) {
    val componentKey: String get() = "$packageName/$activityName"
}
