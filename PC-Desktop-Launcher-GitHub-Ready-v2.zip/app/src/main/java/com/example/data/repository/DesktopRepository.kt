package com.example.data.repository

import com.example.data.local.DesktopItemEntity
import com.example.data.local.HiddenAppEntity
import com.example.data.local.LauncherDao
import com.example.data.local.PinnedAppEntity
import com.example.data.local.RecentAppEntity
import com.example.data.local.RecycleBinEntity
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopItemType
import com.example.data.model.HiddenAppInfo
import com.example.data.model.InstalledApp
import com.example.data.model.RecycleBinItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class DesktopRepository(
    private val dao: LauncherDao
) {
    val desktopItems: Flow<List<DesktopItem>> = dao.observeDesktopItems().map { list ->
        list.map { it.toDomain() }
    }

    val recycleBinItems: Flow<List<RecycleBinItem>> = dao.observeRecycleBin().map { list ->
        list.map { it.toDomain() }
    }

    val pinnedApps: Flow<List<PinnedAppEntity>> = dao.observePinnedApps()

    val recentApps: Flow<List<RecentAppEntity>> = dao.observeRecentApps()

    val hiddenApps: Flow<List<HiddenAppInfo>> = dao.observeHiddenApps().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun hideApp(app: InstalledApp) {
        dao.upsertHiddenApp(
            HiddenAppEntity(
                componentKey = app.componentKey,
                packageName = app.packageName,
                activityName = app.activityName,
                label = app.label,
                hiddenAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun unhideApp(componentKey: String) {
        dao.deleteHiddenApp(componentKey)
    }

    suspend fun ensureSeeded(installedApps: List<InstalledApp>) {
        if (dao.countDesktopItems() > 0) {
            // Upgrade safeguard: ensure existing users receive the Gallery icon if missing
            val existing = dao.getDesktopItemsOnce()
            if (existing.none { it.type == DesktopItemType.GALLERY.name }) {
                val (col, row) = findNextFreeCell(existing.filter { it.parentFolderId == null })
                dao.upsertDesktopItem(
                    DesktopItemEntity(
                        id = "sys_gallery",
                        title = "Gallery",
                        type = DesktopItemType.GALLERY.name,
                        gridCol = col,
                        gridRow = row,
                        sortOrder = 4
                    )
                )
            }
            return
        }

        val defaults = mutableListOf(
            DesktopItemEntity(
                id = "sys_this_pc",
                title = "This PC",
                type = DesktopItemType.THIS_PC.name,
                gridCol = 0,
                gridRow = 0,
                sortOrder = 0
            ),
            DesktopItemEntity(
                id = "sys_pc_settings",
                title = "PC Settings",
                type = DesktopItemType.PC_SETTINGS.name,
                gridCol = 0,
                gridRow = 1,
                sortOrder = 1
            ),
            DesktopItemEntity(
                id = "sys_recycle_bin",
                title = "Recycle Bin",
                type = DesktopItemType.RECYCLE_BIN.name,
                gridCol = 0,
                gridRow = 2,
                sortOrder = 2
            ),
            DesktopItemEntity(
                id = "sys_task_monitor",
                title = "Task Manager",
                type = DesktopItemType.TASK_MONITOR.name,
                gridCol = 0,
                gridRow = 3,
                sortOrder = 3
            ),
            DesktopItemEntity(
                id = "sys_gallery",
                title = "Gallery",
                type = DesktopItemType.GALLERY.name,
                gridCol = 0,
                gridRow = 4,
                sortOrder = 4
            ),
            DesktopItemEntity(
                id = "folder_workspace",
                title = "Workspaces",
                type = DesktopItemType.FOLDER.name,
                gridCol = 1,
                gridRow = 0,
                sortOrder = 5
            ),
            DesktopItemEntity(
                id = "file_readme",
                title = "Welcome.txt",
                type = DesktopItemType.FILE.name,
                targetPath = "Documents/Welcome_to_PC_Desktop.txt",
                gridCol = 1,
                gridRow = 1,
                sortOrder = 6
            )
        )

        // Add up to 3 common installed Android apps to Desktop + pin top 6 to Start Menu
        val priorityKeywords = listOf("chrome", "browser", "camera", "gallery", "photos", "music", "dialer", "phone", "messages", "settings")
        val prioritized = installedApps
            .sortedBy { app ->
                val idx = priorityKeywords.indexOfFirst { kw ->
                    app.packageName.contains(kw, ignoreCase = true) || app.label.contains(kw, ignoreCase = true)
                }
                if (idx >= 0) idx else 100
            }
            .take(6)

        prioritized.take(3).forEachIndexed { index, app ->
            defaults.add(
                DesktopItemEntity(
                    id = "app_${app.packageName}_${index}",
                    title = app.label,
                    type = DesktopItemType.APP_SHORTCUT.name,
                    targetPackage = app.packageName,
                    targetActivity = app.activityName,
                    gridCol = 1,
                    gridRow = 2 + index,
                    sortOrder = 10 + index
                )
            )
        }

        dao.upsertDesktopItems(defaults)

        prioritized.forEachIndexed { index, app ->
            if (dao.getPinnedApp(app.componentKey) == null) {
                dao.upsertPinnedApp(
                    PinnedAppEntity(
                        componentKey = app.componentKey,
                        packageName = app.packageName,
                        activityName = app.activityName,
                        label = app.label,
                        pinnedToTaskbar = index < 2,
                        pinnedToStart = true,
                        sortOrder = index
                    )
                )
            }
        }
    }

    suspend fun resetDefaultDesktop(installedApps: List<InstalledApp>) {
        dao.clearAllDesktopItems()
        ensureSeeded(installedApps)
    }

    suspend fun createDesktopFolder(name: String, parentFolderId: String? = null) {
        val current = dao.getDesktopItemsOnce().filter { it.parentFolderId == parentFolderId }
        val (col, row) = findNextFreeCell(current)
        dao.upsertDesktopItem(
            DesktopItemEntity(
                id = "folder_${UUID.randomUUID()}",
                title = name.trim().ifEmpty { "New Folder" },
                type = DesktopItemType.FOLDER.name,
                gridCol = col,
                gridRow = row,
                parentFolderId = parentFolderId,
                sortOrder = current.size + 10
            )
        )
    }

    suspend fun createDesktopFileShortcut(title: String, relativePath: String, parentFolderId: String? = null) {
        val current = dao.getDesktopItemsOnce().filter { it.parentFolderId == parentFolderId }
        val (col, row) = findNextFreeCell(current)
        dao.upsertDesktopItem(
            DesktopItemEntity(
                id = "file_${UUID.randomUUID()}",
                title = title.trim().ifEmpty { "New Document.txt" },
                type = DesktopItemType.FILE.name,
                targetPath = relativePath,
                gridCol = col,
                gridRow = row,
                parentFolderId = parentFolderId,
                sortOrder = current.size + 10
            )
        )
    }

    suspend fun addAppShortcutToDesktop(app: InstalledApp, parentFolderId: String? = null) {
        val current = dao.getDesktopItemsOnce().filter { it.parentFolderId == parentFolderId }
        val (col, row) = findNextFreeCell(current)
        dao.upsertDesktopItem(
            DesktopItemEntity(
                id = "app_${UUID.randomUUID()}",
                title = app.label,
                type = DesktopItemType.APP_SHORTCUT.name,
                targetPackage = app.packageName,
                targetActivity = app.activityName,
                gridCol = col,
                gridRow = row,
                parentFolderId = parentFolderId,
                sortOrder = current.size + 10
            )
        )
    }

    suspend fun renameDesktopItem(id: String, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        val item = dao.getDesktopItemsOnce().firstOrNull { it.id == id } ?: return
        dao.updateDesktopItem(item.copy(title = trimmed))
    }

    suspend fun moveDesktopItemToGrid(id: String, targetCol: Int, targetRow: Int) {
        val items = dao.getDesktopItemsOnce()
        val moving = items.firstOrNull { it.id == id } ?: return
        val occupant = items.firstOrNull {
            it.id != id && it.parentFolderId == moving.parentFolderId && it.gridCol == targetCol && it.gridRow == targetRow
        }
        if (occupant != null) {
            // Swap positions cleanly
            dao.updateDesktopItem(occupant.copy(gridCol = moving.gridCol, gridRow = moving.gridRow))
        }
        dao.updateDesktopItem(moving.copy(gridCol = targetCol, gridRow = targetRow))
    }

    suspend fun autoArrangeDesktop(maxRows: Int = 6, sortByName: Boolean = false) {
        val all = dao.getDesktopItemsOnce()
        val rootItems = all.filter { it.parentFolderId == null }
        val ordered = if (sortByName) {
            rootItems.sortedWith(
                compareBy<DesktopItemEntity> {
                    when (it.type) {
                        DesktopItemType.THIS_PC.name -> 0
                        DesktopItemType.PC_SETTINGS.name -> 1
                        DesktopItemType.RECYCLE_BIN.name -> 2
                        DesktopItemType.TASK_MONITOR.name -> 3
                        DesktopItemType.FOLDER.name -> 4
                        else -> 5
                    }
                }.thenBy { it.title.lowercase() }
            )
        } else {
            rootItems.sortedWith(compareBy<DesktopItemEntity> { it.gridCol }.thenBy { it.gridRow }.thenBy { it.sortOrder })
        }

        val rows = maxRows.coerceAtLeast(3)
        val updated = ordered.mapIndexed { index, item ->
            val col = index / rows
            val row = index % rows
            item.copy(gridCol = col, gridRow = row, sortOrder = index)
        }
        dao.upsertDesktopItems(updated)
    }

    suspend fun moveToRecycleBin(item: DesktopItem) {
        // System icons cannot be deleted, only shortcuts/folders/files
        if (item.type == DesktopItemType.THIS_PC ||
            item.type == DesktopItemType.PC_SETTINGS ||
            item.type == DesktopItemType.RECYCLE_BIN
        ) return

        dao.insertRecycleBinItem(
            RecycleBinEntity(
                id = "bin_${UUID.randomUUID()}",
                originalItemId = item.id,
                title = item.title,
                type = item.type.name,
                targetPackage = item.targetPackage,
                targetActivity = item.targetActivity,
                targetPath = item.targetPath,
                originalLocation = if (item.parentFolderId == null) "Desktop" else "Desktop Folder",
                deletedAt = System.currentTimeMillis()
            )
        )
        dao.deleteDesktopItemById(item.id)
    }

    suspend fun restoreFromRecycleBin(binItem: RecycleBinItem) {
        val current = dao.getDesktopItemsOnce().filter { it.parentFolderId == null }
        val (col, row) = findNextFreeCell(current)
        dao.upsertDesktopItem(
            DesktopItemEntity(
                id = binItem.originalItemId,
                title = binItem.title,
                type = binItem.type.name,
                targetPackage = binItem.targetPackage,
                targetActivity = binItem.targetActivity,
                targetPath = binItem.targetPath,
                gridCol = col,
                gridRow = row,
                parentFolderId = null,
                sortOrder = current.size + 10
            )
        )
        dao.deleteRecycleBinItemById(binItem.id)
    }

    suspend fun deletePermanentlyFromRecycleBin(binId: String) {
        dao.deleteRecycleBinItemById(binId)
    }

    suspend fun emptyRecycleBin() {
        dao.emptyRecycleBin()
    }

    suspend fun togglePinToStart(app: InstalledApp) {
        val existing = dao.getPinnedApp(app.componentKey)
        if (existing == null) {
            dao.upsertPinnedApp(
                PinnedAppEntity(
                    componentKey = app.componentKey,
                    packageName = app.packageName,
                    activityName = app.activityName,
                    label = app.label,
                    pinnedToStart = true,
                    pinnedToTaskbar = false,
                    sortOrder = 50
                )
            )
        } else {
            val nextStart = !existing.pinnedToStart
            if (!nextStart && !existing.pinnedToTaskbar) {
                dao.deletePinnedApp(app.componentKey)
            } else {
                dao.upsertPinnedApp(existing.copy(pinnedToStart = nextStart))
            }
        }
    }

    suspend fun togglePinToTaskbar(app: InstalledApp) {
        val existing = dao.getPinnedApp(app.componentKey)
        if (existing == null) {
            dao.upsertPinnedApp(
                PinnedAppEntity(
                    componentKey = app.componentKey,
                    packageName = app.packageName,
                    activityName = app.activityName,
                    label = app.label,
                    pinnedToStart = false,
                    pinnedToTaskbar = true,
                    sortOrder = 50
                )
            )
        } else {
            val nextTaskbar = !existing.pinnedToTaskbar
            if (!existing.pinnedToStart && !nextTaskbar) {
                dao.deletePinnedApp(app.componentKey)
            } else {
                dao.upsertPinnedApp(existing.copy(pinnedToTaskbar = nextTaskbar))
            }
        }
    }

    private fun findNextFreeCell(existing: List<DesktopItemEntity>, maxRows: Int = 6): Pair<Int, Int> {
        val occupied = existing.map { it.gridCol to it.gridRow }.toSet()
        for (col in 0..12) {
            for (row in 0 until maxRows) {
                if ((col to row) !in occupied) return col to row
            }
        }
        return 0 to existing.size
    }
}
