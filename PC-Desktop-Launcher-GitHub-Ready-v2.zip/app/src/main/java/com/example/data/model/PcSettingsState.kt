package com.example.data.model

import androidx.compose.runtime.Immutable
import org.json.JSONObject

enum class LauncherMode(val label: String) {
    DESKTOP("Desktop Mode"),
    MOBILE("Normal Mobile Mode")
}

enum class ThemeMode(val label: String) {
    SYSTEM("Follow System"),
    DARK("Dark Mode"),
    LIGHT("Light Mode")
}

enum class OrientationMode(val label: String) {
    LANDSCAPE("Landscape (PC Default)"),
    PORTRAIT("Portrait"),
    AUTO("Auto-Rotate")
}

enum class VaultAccessMethod(val label: String, val description: String) {
    CALENDAR_HEADER_HOLD(
        "Calendar Month Long-Press",
        "Tap the taskbar Clock to open the Calendar flyout, then press and hold the Month/Year title."
    ),
    CLOCK_TRIPLE_TAP(
        "Taskbar Clock Triple-Tap",
        "Tap the taskbar Clock & Date tray 3 times rapidly within 1.2 seconds."
    ),
    START_SECRET_PHRASE(
        "Start Search Secret Command",
        "Open Start Search and type your secret command phrase (invisible in normal lists)."
    )
}

enum class DesktopThemePreset(
    val label: String,
    val subtitle: String,
    val defaultDark: Boolean,
    val defaultAccentKey: String,
    val defaultWallpaperId: String,
    val defaultTaskbarPos: TaskbarPosition,
    val defaultTaskbarStyle: TaskbarStyle,
    val defaultCornerStyle: CornerStyle,
    val defaultWindowAppearance: WindowAppearance,
    val defaultFontStyle: FontStyleOption,
    val defaultIconPack: IconPackStyle
) {
    WINDOWS_11(
        label = "Windows 11",
        subtitle = "Mica acrylic, rounded corners, Fluent icons",
        defaultDark = true,
        defaultAccentKey = "blue",
        defaultWallpaperId = "bloom",
        defaultTaskbarPos = TaskbarPosition.BOTTOM,
        defaultTaskbarStyle = TaskbarStyle.BLURRED,
        defaultCornerStyle = CornerStyle.ROUNDED,
        defaultWindowAppearance = WindowAppearance.ACRYLIC,
        defaultFontStyle = FontStyleOption.PLUS_JAKARTA,
        defaultIconPack = IconPackStyle.FLUENT
    ),
    WINDOWS_10(
        label = "Windows 10",
        subtitle = "Sharp slate tiles, crisp bottom taskbar",
        defaultDark = true,
        defaultAccentKey = "blue",
        defaultWallpaperId = "ocean",
        defaultTaskbarPos = TaskbarPosition.BOTTOM,
        defaultTaskbarStyle = TaskbarStyle.SOLID,
        defaultCornerStyle = CornerStyle.SUBTLE,
        defaultWindowAppearance = WindowAppearance.SOLID,
        defaultFontStyle = FontStyleOption.PLUS_JAKARTA,
        defaultIconPack = IconPackStyle.FLUENT
    ),
    CLASSIC_WINDOWS(
        label = "Classic Windows",
        subtitle = "Retro 95/XP beveled frames, square edges",
        defaultDark = false,
        defaultAccentKey = "cyan",
        defaultWallpaperId = "classic_teal",
        defaultTaskbarPos = TaskbarPosition.BOTTOM,
        defaultTaskbarStyle = TaskbarStyle.SOLID,
        defaultCornerStyle = CornerStyle.SQUARE,
        defaultWindowAppearance = WindowAppearance.BEVELED,
        defaultFontStyle = FontStyleOption.JETBRAINS_MONO,
        defaultIconPack = IconPackStyle.CLASSIC
    ),
    MACOS_INSPIRED(
        label = "macOS Inspired",
        subtitle = "Floating dock, soft curves, airy glass",
        defaultDark = false,
        defaultAccentKey = "violet",
        defaultWallpaperId = "sunrise",
        defaultTaskbarPos = TaskbarPosition.BOTTOM,
        defaultTaskbarStyle = TaskbarStyle.TRANSPARENT,
        defaultCornerStyle = CornerStyle.ROUNDED,
        defaultWindowAppearance = WindowAppearance.ACRYLIC,
        defaultFontStyle = FontStyleOption.PLUS_JAKARTA,
        defaultIconPack = IconPackStyle.VIBRANT
    ),
    LINUX_INSPIRED(
        label = "Linux Desktop",
        subtitle = "Left vertical dock, Ubuntu typography",
        defaultDark = true,
        defaultAccentKey = "amber",
        defaultWallpaperId = "aurora",
        defaultTaskbarPos = TaskbarPosition.LEFT,
        defaultTaskbarStyle = TaskbarStyle.BLURRED,
        defaultCornerStyle = CornerStyle.SUBTLE,
        defaultWindowAppearance = WindowAppearance.ACRYLIC,
        defaultFontStyle = FontStyleOption.UBUNTU,
        defaultIconPack = IconPackStyle.VIBRANT
    ),
    MINIMAL_DESKTOP(
        label = "Minimal Desktop",
        subtitle = "Clean monochrome, zero distraction",
        defaultDark = true,
        defaultAccentKey = "emerald",
        defaultWallpaperId = "midnight",
        defaultTaskbarPos = TaskbarPosition.BOTTOM,
        defaultTaskbarStyle = TaskbarStyle.TRANSPARENT,
        defaultCornerStyle = CornerStyle.SUBTLE,
        defaultWindowAppearance = WindowAppearance.MINIMAL,
        defaultFontStyle = FontStyleOption.SPACE_GROTESK,
        defaultIconPack = IconPackStyle.MONOCHROME
    ),
    CUSTOM(
        label = "Custom User Theme",
        subtitle = "Your personalized desktop configuration",
        defaultDark = true,
        defaultAccentKey = "blue",
        defaultWallpaperId = "bloom",
        defaultTaskbarPos = TaskbarPosition.BOTTOM,
        defaultTaskbarStyle = TaskbarStyle.BLURRED,
        defaultCornerStyle = CornerStyle.ROUNDED,
        defaultWindowAppearance = WindowAppearance.ACRYLIC,
        defaultFontStyle = FontStyleOption.PLUS_JAKARTA,
        defaultIconPack = IconPackStyle.FLUENT
    )
}

enum class IconSizeOption(val label: String, val tileWidthDp: Int, val iconDp: Int, val fontSp: Int) {
    SMALL("Small", 74, 34, 11),
    MEDIUM("Medium", 88, 42, 12),
    LARGE("Large", 104, 52, 13)
}

enum class TaskbarPosition(val label: String) {
    BOTTOM("Bottom"),
    TOP("Top"),
    LEFT("Left"),
    RIGHT("Right")
}

enum class TaskbarSizeOption(val label: String, val heightDp: Int, val iconDp: Int) {
    COMPACT("Compact", 44, 20),
    STANDARD("Standard", 52, 24),
    LARGE("Large", 62, 28)
}

enum class TaskbarStyle(val label: String) {
    TRANSPARENT("Transparent"),
    BLURRED("Blurred Acrylic"),
    SOLID("Solid"),
    CUSTOM("Custom Color")
}

enum class WindowAppearance(val label: String) {
    ACRYLIC("Acrylic Glass"),
    SOLID("Solid Flat"),
    BEVELED("Classic Beveled"),
    MINIMAL("Minimal Borderless")
}

enum class CornerStyle(val label: String, val windowRadiusDp: Int, val cardRadiusDp: Int) {
    ROUNDED("Rounded", 14, 10),
    SUBTLE("Subtle", 6, 4),
    SQUARE("Square", 0, 0)
}

enum class IconPackStyle(val label: String) {
    FLUENT("Windows Fluent"),
    CLASSIC("Classic Retro"),
    MONOCHROME("Minimal Mono"),
    VIBRANT("Vibrant Rounded")
}

enum class FontStyleOption(val label: String) {
    PLUS_JAKARTA("Segoe / Jakarta"),
    UBUNTU("Ubuntu"),
    SPACE_GROTESK("Space Grotesk"),
    JETBRAINS_MONO("Terminal Mono"),
    SYSTEM_DEFAULT("Android System")
}

enum class WallpaperFitOption(val label: String) {
    CROP("Fill (Crop)"),
    FIT("Fit Screen"),
    STRETCH("Stretch"),
    CENTER("Center")
}

enum class ScreenLayoutDensity(val label: String, val scaleMultiplier: Float) {
    COMPACT_LAPTOP("Compact Laptop", 0.90f),
    STANDARD_PC("Standard PC", 1.00f),
    SPACIOUS_MONITOR("Large Display", 1.12f)
}

enum class AnimationSpeed(val label: String, val durationMs: Int) {
    SNAPPY("Snappy (120ms)", 120),
    STANDARD("Standard (220ms)", 220),
    SMOOTH("Smooth (320ms)", 320)
}

enum class AnimationEffectStyle(val label: String) {
    SPRING("Smooth Spring"),
    SLIDE("Snappy Slide"),
    FADE("Clean Fade"),
    REDUCED("Reduced Motion")
}

enum class WallpaperCategory(val label: String) {
    WINDOWS("Windows-Inspired"),
    MINIMAL_DARK("Minimal Dark"),
    ABSTRACT("Abstract Premium"),
    NATURE("Nature"),
    GRADIENT("Gradient"),
    AMOLED("AMOLED")
}

enum class WallpaperPreset(
    val id: String,
    val title: String,
    val category: WallpaperCategory,
    val isLight: Boolean
) {
    // 1-4: Windows-Inspired
    BLOOM("bloom", "Luminous Bloom", WallpaperCategory.WINDOWS, false),
    LUMINOUS_RIBBON("luminous_ribbon", "Fluent Light Ribbon", WallpaperCategory.WINDOWS, true),
    FLUENT_WAVES("fluent_waves", "Azure Acrylic Waves", WallpaperCategory.WINDOWS, false),
    CLASSIC_TEAL("classic_teal", "Classic Desktop Teal", WallpaperCategory.WINDOWS, false),

    // 5-8: Minimal Dark
    MIDNIGHT_MESH("midnight", "Midnight Carbon", WallpaperCategory.MINIMAL_DARK, false),
    OBSIDIAN_GRID("obsidian_grid", "Obsidian Blueprint", WallpaperCategory.MINIMAL_DARK, false),
    SLATE_HORIZON("slate_horizon", "Monochrome Horizon", WallpaperCategory.MINIMAL_DARK, false),
    GRAPHITE_RADIAL("graphite_radial", "Graphite Studio", WallpaperCategory.MINIMAL_DARK, false),

    // 9-12: Abstract Premium
    ABSTRACT_PRISM("prism", "Iridescent Prism", WallpaperCategory.ABSTRACT, false),
    SILK_RIBBONS("silk_ribbons", "Velvet Silk Waves", WallpaperCategory.ABSTRACT, false),
    COSMIC_ORBS("cosmic_orbs", "Luminous Glass Orbs", WallpaperCategory.ABSTRACT, false),
    CRYSTAL_FACETS("crystal_facets", "Crystal Facets", WallpaperCategory.ABSTRACT, false),

    // 13-16: Nature
    AURORA("aurora", "Northern Aurora", WallpaperCategory.NATURE, false),
    ALPINE_LAKE("alpine", "Alpine Blue Hour", WallpaperCategory.NATURE, false),
    SUNSET("sunset", "Dusk Dunes", WallpaperCategory.NATURE, false),
    SUNRISE("sunrise", "Pearl Sunrise", WallpaperCategory.NATURE, true),

    // 17-20: Gradient
    OCEAN_GLASS("ocean", "Azure Deep Gradient", WallpaperCategory.GRADIENT, false),
    EMERALD_MIST("emerald_mist", "Northern Pine Mist", WallpaperCategory.GRADIENT, false),
    ROYAL_DUSK("royal_dusk", "Royal Indigo Dusk", WallpaperCategory.GRADIENT, false),
    COPPER_DAWN("copper_dawn", "Warm Copper Dawn", WallpaperCategory.GRADIENT, false),

    // 21-24: AMOLED & Custom Solid
    AMOLED_PURE("amoled_pure", "AMOLED Pitch Black", WallpaperCategory.AMOLED, false),
    AMOLED_CONSTELLATION("amoled_constellation", "AMOLED Starfield", WallpaperCategory.AMOLED, false),
    AMOLED_NEON_RING("amoled_neon_ring", "AMOLED Neon Halo", WallpaperCategory.AMOLED, false),
    SOLID_COLOR("solid_color", "Custom Solid Color", WallpaperCategory.MINIMAL_DARK, false);

    companion object {
        fun byId(id: String): WallpaperPreset = entries.firstOrNull { it.id == id } ?: BLOOM
    }
}

@Immutable
data class SavedThemeProfile(
    val id: String,
    val name: String,
    val themeJson: String,
    val createdAt: Long
)

@Immutable
data class LauncherNotification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isUnread: Boolean = true
)

@Immutable
data class PcSettingsState(
    val launcherMode: LauncherMode = LauncherMode.DESKTOP,
    val autoLaunchAppInDesktopMode: Boolean = false,
    val lockScreenEnabled: Boolean = false,
    val lockScreenShowClockSeconds: Boolean = false,
    val lockScreenBiometricEnabled: Boolean = true,
    val lockWallpaperId: String = WallpaperPreset.ABSTRACT_PRISM.id,
    val customLockWallpaperUri: String? = null,
    val vaultAccessMethod: VaultAccessMethod = VaultAccessMethod.CALENDAR_HEADER_HOLD,
    val vaultSecretPhrase: String = "//vault",
    val vaultBiometricEnabled: Boolean = true,
    val themePreset: DesktopThemePreset = DesktopThemePreset.WINDOWS_11,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val accentKey: String = "blue",
    val customAccentArgb: Long? = null,
    val desktopBackgroundArgb: Long = 0xFF0A192FL,
    val wallpaperId: String = WallpaperPreset.BLOOM.id,
    val customWallpaperUri: String? = null,
    val wallpaperFit: WallpaperFitOption = WallpaperFitOption.CROP,
    val wallpaperDimAlpha: Float = 0.0f,
    val fullScreenImmersive: Boolean = true,
    val orientationMode: OrientationMode = OrientationMode.LANDSCAPE,
    val desktopScale: Float = 1.0f,
    val screenLayout: ScreenLayoutDensity = ScreenLayoutDensity.STANDARD_PC,
    val iconSize: IconSizeOption = IconSizeOption.MEDIUM,
    val iconScale: Float = 1.0f,
    val iconPack: IconPackStyle = IconPackStyle.FLUENT,
    val showDesktopIconScrim: Boolean = true,
    val autoArrangeGrid: Boolean = false,
    val showDesktopClock: Boolean = true,
    val showFileExtensions: Boolean = true,
    val taskbarPosition: TaskbarPosition = TaskbarPosition.BOTTOM,
    val taskbarSize: TaskbarSizeOption = TaskbarSizeOption.STANDARD,
    val taskbarHeightOverrideDp: Int? = null,
    val taskbarIconSpacingDp: Int = 4,
    val taskbarStyle: TaskbarStyle = TaskbarStyle.BLURRED,
    val taskbarTransparency: Float = 0.84f,
    val customTaskbarArgb: Long? = null,
    val showTaskbarSearch: Boolean = true,
    val showTaskbarDate: Boolean = true,
    val showTaskbarNotificationBadge: Boolean = true,
    val windowAppearance: WindowAppearance = WindowAppearance.ACRYLIC,
    val cornerStyle: CornerStyle = CornerStyle.ROUNDED,
    val fontStyle: FontStyleOption = FontStyleOption.PLUS_JAKARTA,
    val animationsEnabled: Boolean = true,
    val animationSpeed: AnimationSpeed = AnimationSpeed.STANDARD,
    val animationEffect: AnimationEffectStyle = AnimationEffectStyle.SPRING,
    val batterySaverMode: Boolean = false,
    val hapticFeedbackEnabled: Boolean = true,
    val showToastNotifications: Boolean = true,
    val preferFreeformLaunch: Boolean = true,
    val defaultBrowserPackage: String? = null,
    val defaultFilesPackage: String? = null,
    val defaultGalleryPackage: String? = null,
    val defaultMusicPackage: String? = null
) {
    fun effectiveTaskbarThicknessDp(): Int = taskbarHeightOverrideDp ?: taskbarSize.heightDp

    fun toThemeJson(): String {
        val obj = JSONObject()
        obj.put("themePreset", themePreset.name)
        obj.put("themeMode", themeMode.name)
        obj.put("accentKey", accentKey)
        if (customAccentArgb != null) obj.put("customAccentArgb", customAccentArgb)
        obj.put("desktopBackgroundArgb", desktopBackgroundArgb)
        obj.put("wallpaperId", wallpaperId)
        obj.put("lockWallpaperId", lockWallpaperId)
        obj.put("wallpaperFit", wallpaperFit.name)
        obj.put("wallpaperDimAlpha", wallpaperDimAlpha.toDouble())
        obj.put("fullScreenImmersive", fullScreenImmersive)
        obj.put("orientationMode", orientationMode.name)
        obj.put("desktopScale", desktopScale.toDouble())
        obj.put("screenLayout", screenLayout.name)
        obj.put("iconSize", iconSize.name)
        obj.put("iconScale", iconScale.toDouble())
        obj.put("iconPack", iconPack.name)
        obj.put("showDesktopIconScrim", showDesktopIconScrim)
        obj.put("autoArrangeGrid", autoArrangeGrid)
        obj.put("showDesktopClock", showDesktopClock)
        obj.put("showFileExtensions", showFileExtensions)
        obj.put("taskbarPosition", taskbarPosition.name)
        obj.put("taskbarSize", taskbarSize.name)
        if (taskbarHeightOverrideDp != null) obj.put("taskbarHeightOverrideDp", taskbarHeightOverrideDp)
        obj.put("taskbarIconSpacingDp", taskbarIconSpacingDp)
        obj.put("taskbarStyle", taskbarStyle.name)
        obj.put("taskbarTransparency", taskbarTransparency.toDouble())
        if (customTaskbarArgb != null) obj.put("customTaskbarArgb", customTaskbarArgb)
        obj.put("showTaskbarSearch", showTaskbarSearch)
        obj.put("showTaskbarDate", showTaskbarDate)
        obj.put("showTaskbarNotificationBadge", showTaskbarNotificationBadge)
        obj.put("windowAppearance", windowAppearance.name)
        obj.put("cornerStyle", cornerStyle.name)
        obj.put("fontStyle", fontStyle.name)
        obj.put("animationsEnabled", animationsEnabled)
        obj.put("animationSpeed", animationSpeed.name)
        obj.put("animationEffect", animationEffect.name)
        obj.put("batterySaverMode", batterySaverMode)
        obj.put("hapticFeedbackEnabled", hapticFeedbackEnabled)
        obj.put("showToastNotifications", showToastNotifications)
        return obj.toString(2)
    }

    companion object {
        fun applyJsonTo(base: PcSettingsState, jsonString: String): PcSettingsState {
            val obj = JSONObject(jsonString)
            return base.copy(
                themePreset = obj.optString("themePreset").let { n -> DesktopThemePreset.entries.firstOrNull { it.name == n } } ?: base.themePreset,
                themeMode = obj.optString("themeMode").let { n -> ThemeMode.entries.firstOrNull { it.name == n } } ?: base.themeMode,
                accentKey = obj.optString("accentKey", base.accentKey),
                customAccentArgb = if (obj.has("customAccentArgb")) obj.optLong("customAccentArgb") else null,
                desktopBackgroundArgb = obj.optLong("desktopBackgroundArgb", base.desktopBackgroundArgb),
                wallpaperId = obj.optString("wallpaperId", base.wallpaperId),
                lockWallpaperId = obj.optString("lockWallpaperId", base.lockWallpaperId),
                wallpaperFit = obj.optString("wallpaperFit").let { n -> WallpaperFitOption.entries.firstOrNull { it.name == n } } ?: base.wallpaperFit,
                wallpaperDimAlpha = obj.optDouble("wallpaperDimAlpha", base.wallpaperDimAlpha.toDouble()).toFloat().coerceIn(0f, 0.7f),
                fullScreenImmersive = obj.optBoolean("fullScreenImmersive", base.fullScreenImmersive),
                orientationMode = obj.optString("orientationMode").let { n -> OrientationMode.entries.firstOrNull { it.name == n } } ?: base.orientationMode,
                desktopScale = obj.optDouble("desktopScale", base.desktopScale.toDouble()).toFloat().coerceIn(0.8f, 1.25f),
                screenLayout = obj.optString("screenLayout").let { n -> ScreenLayoutDensity.entries.firstOrNull { it.name == n } } ?: base.screenLayout,
                iconSize = obj.optString("iconSize").let { n -> IconSizeOption.entries.firstOrNull { it.name == n } } ?: base.iconSize,
                iconScale = obj.optDouble("iconScale", base.iconScale.toDouble()).toFloat().coerceIn(0.75f, 1.35f),
                iconPack = obj.optString("iconPack").let { n -> IconPackStyle.entries.firstOrNull { it.name == n } } ?: base.iconPack,
                showDesktopIconScrim = obj.optBoolean("showDesktopIconScrim", base.showDesktopIconScrim),
                autoArrangeGrid = obj.optBoolean("autoArrangeGrid", base.autoArrangeGrid),
                showDesktopClock = obj.optBoolean("showDesktopClock", base.showDesktopClock),
                showFileExtensions = obj.optBoolean("showFileExtensions", base.showFileExtensions),
                taskbarPosition = obj.optString("taskbarPosition").let { n -> TaskbarPosition.entries.firstOrNull { it.name == n } } ?: base.taskbarPosition,
                taskbarSize = obj.optString("taskbarSize").let { n -> TaskbarSizeOption.entries.firstOrNull { it.name == n } } ?: base.taskbarSize,
                taskbarHeightOverrideDp = if (obj.has("taskbarHeightOverrideDp")) obj.optInt("taskbarHeightOverrideDp").coerceIn(36, 80) else null,
                taskbarIconSpacingDp = obj.optInt("taskbarIconSpacingDp", base.taskbarIconSpacingDp).coerceIn(0, 16),
                taskbarStyle = obj.optString("taskbarStyle").let { n -> TaskbarStyle.entries.firstOrNull { it.name == n } } ?: base.taskbarStyle,
                taskbarTransparency = obj.optDouble("taskbarTransparency", base.taskbarTransparency.toDouble()).toFloat().coerceIn(0.2f, 1.0f),
                customTaskbarArgb = if (obj.has("customTaskbarArgb")) obj.optLong("customTaskbarArgb") else null,
                showTaskbarSearch = obj.optBoolean("showTaskbarSearch", base.showTaskbarSearch),
                showTaskbarDate = obj.optBoolean("showTaskbarDate", base.showTaskbarDate),
                showTaskbarNotificationBadge = obj.optBoolean("showTaskbarNotificationBadge", base.showTaskbarNotificationBadge),
                windowAppearance = obj.optString("windowAppearance").let { n -> WindowAppearance.entries.firstOrNull { it.name == n } } ?: base.windowAppearance,
                cornerStyle = obj.optString("cornerStyle").let { n -> CornerStyle.entries.firstOrNull { it.name == n } } ?: base.cornerStyle,
                fontStyle = obj.optString("fontStyle").let { n -> FontStyleOption.entries.firstOrNull { it.name == n } } ?: base.fontStyle,
                animationsEnabled = obj.optBoolean("animationsEnabled", base.animationsEnabled),
                animationSpeed = obj.optString("animationSpeed").let { n -> AnimationSpeed.entries.firstOrNull { it.name == n } } ?: base.animationSpeed,
                animationEffect = obj.optString("animationEffect").let { n -> AnimationEffectStyle.entries.firstOrNull { it.name == n } } ?: base.animationEffect,
                batterySaverMode = obj.optBoolean("batterySaverMode", base.batterySaverMode),
                hapticFeedbackEnabled = obj.optBoolean("hapticFeedbackEnabled", base.hapticFeedbackEnabled),
                showToastNotifications = obj.optBoolean("showToastNotifications", base.showToastNotifications)
            )
        }
    }
}
