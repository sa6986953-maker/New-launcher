package com.example.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/**
 * Hardware-backed security vault using AndroidKeyStore AES-GCM key wrapping
 * + salted PBKDF2-HMAC-SHA256 credential verifiers (never storing plaintext PINs/answers).
 */
class SecurityVaultManager(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val secureRandom = SecureRandom()

    fun hasPinConfigured(): Boolean = !prefs.getString(KEY_PIN_RECORD, null).isNullOrBlank()

    fun getRecoveryQuestion(): String? = prefs.getString(KEY_RECOVERY_QUESTION, null)?.takeIf { it.isNotBlank() }

    fun setupPinAndRecovery(
        pin: String,
        recoveryQuestion: String,
        recoveryAnswer: String
    ): String {
        val cleanPin = pin.trim()
        require(cleanPin.length >= 4) { "PIN or password must be at least 4 characters." }
        val cleanQuestion = recoveryQuestion.trim().ifEmpty { "What is your recovery keyword?" }
        val cleanAnswer = recoveryAnswer.trim().lowercase()
        require(cleanAnswer.isNotEmpty()) { "Recovery answer cannot be empty." }

        val pinHash = hashCredential(cleanPin)
        val answerHash = hashCredential(cleanAnswer)
        val recoveryCode = generateBackupRecoveryCode()
        val recoveryHash = hashCredential(normalizeRecoveryCode(recoveryCode))

        prefs.edit()
            .putString(KEY_PIN_RECORD, sealRecord(pinHash))
            .putString(KEY_RECOVERY_QUESTION, cleanQuestion)
            .putString(KEY_RECOVERY_ANSWER_RECORD, sealRecord(answerHash))
            .putString(KEY_BACKUP_CODE_RECORD, sealRecord(recoveryHash))
            .apply()

        return recoveryCode
    }

    fun updatePin(newPin: String) {
        val clean = newPin.trim()
        require(clean.length >= 4) { "PIN or password must be at least 4 characters." }
        val hash = hashCredential(clean)
        prefs.edit()
            .putString(KEY_PIN_RECORD, sealRecord(hash))
            .apply()
    }

    fun verifyPin(candidate: String): Boolean {
        val stored = prefs.getString(KEY_PIN_RECORD, null) ?: return false
        val record = unsealRecord(stored) ?: return false
        return verifyHashedCredential(candidate.trim(), record)
    }

    fun verifyRecoveryAnswer(answer: String): Boolean {
        val stored = prefs.getString(KEY_RECOVERY_ANSWER_RECORD, null) ?: return false
        val record = unsealRecord(stored) ?: return false
        return verifyHashedCredential(answer.trim().lowercase(), record)
    }

    fun verifyBackupKey(code: String): Boolean {
        val stored = prefs.getString(KEY_BACKUP_CODE_RECORD, null) ?: return false
        val record = unsealRecord(stored) ?: return false
        return verifyHashedCredential(normalizeRecoveryCode(code), record)
    }

    fun clearSecurityConfig() {
        prefs.edit().clear().apply()
    }

    fun canUseBiometrics(): Boolean {
        val bm = BiometricManager.from(context)
        val res = bm.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        )
        return res == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticateWithBiometric(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        negativeButtonText: String = "Use PIN / Password",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (!canUseBiometrics()) {
            onError("Biometric authentication is not available or not enrolled on this device.")
            return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_USER_CANCELED
                    ) {
                        onError(errString.toString())
                    }
                }

                override fun onAuthenticationFailed() {
                    // System dialog handles retry feedback; keep user in prompt
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText(negativeButtonText)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            .build()
        prompt.authenticate(info)
    }

    private fun hashCredential(secret: String): String {
        val salt = ByteArray(16).also { secureRandom.nextBytes(it) }
        val spec = PBEKeySpec(secret.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        val hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        val saltB64 = Base64.encodeToString(salt, Base64.NO_WRAP)
        val hashB64 = Base64.encodeToString(hash, Base64.NO_WRAP)
        return "$saltB64:$hashB64"
    }

    private fun verifyHashedCredential(candidate: String, storedHashRecord: String): Boolean {
        val parts = storedHashRecord.split(':')
        if (parts.size != 2) return false
        val salt = runCatching { Base64.decode(parts[0], Base64.NO_WRAP) }.getOrNull() ?: return false
        val expected = runCatching { Base64.decode(parts[1], Base64.NO_WRAP) }.getOrNull() ?: return false
        val spec = PBEKeySpec(candidate.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        val actual = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return MessageDigest.isEqual(expected, actual)
    }

    private fun sealRecord(plainHashRecord: String): String {
        return runCatching {
            val key = getOrCreateKeystoreSecretKey()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val cipherBytes = cipher.doFinal(plainHashRecord.toByteArray(Charsets.UTF_8))
            val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
            val dataB64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP)
            "KS1:$ivB64:$dataB64"
        }.getOrElse {
            // Salted PBKDF2 hash already contains zero plaintext; safe JVM/Robolectric fallback
            "PBK:$plainHashRecord"
        }
    }

    private fun unsealRecord(sealed: String): String? {
        return when {
            sealed.startsWith("KS1:") -> runCatching {
                val parts = sealed.split(':')
                if (parts.size != 3) return null
                val iv = Base64.decode(parts[1], Base64.NO_WRAP)
                val data = Base64.decode(parts[2], Base64.NO_WRAP)
                val key = getOrCreateKeystoreSecretKey()
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                String(cipher.doFinal(data), Charsets.UTF_8)
            }.getOrNull()
            sealed.startsWith("PBK:") -> sealed.removePrefix("PBK:")
            else -> null
        }
    }

    private fun getOrCreateKeystoreSecretKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGen.init(spec)
        return keyGen.generateKey()
    }

    private fun generateBackupRecoveryCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        fun group(): String = (1..4).map { alphabet[secureRandom.nextInt(alphabet.length)] }.joinToString("")
        return "PCD-${group()}-${group()}"
    }

    private fun normalizeRecoveryCode(code: String): String =
        code.trim().uppercase().replace(" ", "")

    companion object {
        private const val PREFS_NAME = "pc_launcher_secure_vault"
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val KEY_ALIAS = "pc_desktop_launcher_vault_aes"
        private const val KEY_PIN_RECORD = "pin_record"
        private const val KEY_RECOVERY_QUESTION = "recovery_question"
        private const val KEY_RECOVERY_ANSWER_RECORD = "recovery_answer_record"
        private const val KEY_BACKUP_CODE_RECORD = "backup_code_record"
        private const val PBKDF2_ITERATIONS = 12_000
    }
}
