package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        DesktopItemEntity::class,
        RecycleBinEntity::class,
        PinnedAppEntity::class,
        RecentAppEntity::class,
        SafMountEntity::class,
        SavedThemeEntity::class,
        HiddenAppEntity::class,
        GalleryAlbumEntity::class,
        GalleryMediaEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class LauncherDatabase : RoomDatabase() {
    abstract fun launcherDao(): LauncherDao

    companion object {
        @Volatile
        private var INSTANCE: LauncherDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS saved_themes (
                        id TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        themeJson TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS hidden_apps (
                        componentKey TEXT NOT NULL PRIMARY KEY,
                        packageName TEXT NOT NULL,
                        activityName TEXT NOT NULL,
                        label TEXT NOT NULL,
                        hiddenAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS gallery_albums (
                        id TEXT NOT NULL PRIMARY KEY,
                        name TEXT NOT NULL,
                        isPrivate INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS gallery_media (
                        id TEXT NOT NULL PRIMARY KEY,
                        albumId TEXT NOT NULL,
                        displayName TEXT NOT NULL,
                        mediaType TEXT NOT NULL,
                        filePath TEXT NOT NULL,
                        mimeType TEXT NOT NULL,
                        sizeBytes INTEGER NOT NULL,
                        durationMs INTEGER NOT NULL,
                        addedAt INTEGER NOT NULL,
                        isPrivate INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): LauncherDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LauncherDatabase::class.java,
                    "pc_desktop_launcher.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
