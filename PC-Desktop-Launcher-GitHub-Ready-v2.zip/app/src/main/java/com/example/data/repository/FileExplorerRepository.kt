package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.example.data.local.LauncherDao
import com.example.data.local.SafMountEntity
import com.example.data.model.ExplorerRootSection
import com.example.data.model.FileNode
import com.example.data.model.SafMount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class FileExplorerRepository(
    private val context: Context,
    private val dao: LauncherDao
) {
    private val workspaceRoot: File by lazy {
        File(context.filesDir, "PC_User").apply { mkdirs() }
    }

    val safMounts: Flow<List<SafMount>> = dao.observeSafMounts().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun ensureWorkspaceSeeded() = withContext(Dispatchers.IO) {
        ExplorerRootSection.entries
            .filter { it != ExplorerRootSection.THIS_PC }
            .forEach { section ->
                File(workspaceRoot, section.folderName).mkdirs()
            }

        val welcomeFile = File(workspaceRoot, "Documents/Welcome_to_PC_Desktop.txt")
        if (!welcomeFile.exists()) {
            welcomeFile.writeText(
                """
                Welcome to PC Desktop Launcher!
                
                Tips for using your Android phone as a PC:
                1. Long-press any Desktop icon to move, rename, pin, or delete it.
                2. Long-press empty desktop space to create folders, text files, or auto-arrange icons.
                3. In File Explorer, tap "Mount Folder (SAF)" to connect Android's Downloads, Documents, Pictures, Music, Videos, or Internal Storage safely via Storage Access Framework.
                4. Open PC Settings -> System to set PC Desktop Launcher as your default Home app.
                """.trimIndent()
            )
        }

        val guideFile = File(workspaceRoot, "Documents/Window_Management_Notes.md")
        if (!guideFile.exists()) {
            guideFile.writeText(
                """
                # Window Management on Android
                
                - Built-in PC apps (File Explorer, PC Settings, Recycle Bin, Notepad, Task Manager, and Desktop Folders) support draggable, resizable, minimizable, and maximizable floating windows.
                - Third-party Android apps launch via Android's Activity manager (and optional Freeform bounds on devices that support Android Freeform Window Management).
                """.trimIndent()
            )
        }
    }

    fun getWorkspaceRootPath(): String = workspaceRoot.absolutePath

    fun getSectionPath(section: ExplorerRootSection): String {
        if (section == ExplorerRootSection.THIS_PC) return workspaceRoot.absolutePath
        val dir = File(workspaceRoot, section.folderName)
        if (!dir.exists()) dir.mkdirs()
        return dir.absolutePath
    }

    fun resolveRelativeWorkspaceFile(relativePath: String): File {
        return File(workspaceRoot, relativePath)
    }

    suspend fun listLocalDirectory(path: String): List<FileNode> = withContext(Dispatchers.IO) {
        val dir = File(path)
        if (!dir.exists() || !dir.isDirectory) return@withContext emptyList()
        val children = dir.listFiles()?.toList().orEmpty()
        children.map { file ->
            FileNode(
                id = file.absolutePath,
                name = file.name,
                pathOrUri = file.absolutePath,
                isDirectory = file.isDirectory,
                sizeBytes = if (file.isDirectory) (file.listFiles()?.size?.toLong() ?: 0L) else file.length(),
                lastModified = file.lastModified(),
                mimeType = if (file.isDirectory) "inode/directory" else guessMimeType(file.name),
                isSafDocument = false,
                canWrite = file.canWrite()
            )
        }.sortedWith(compareByDescending<FileNode> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    suspend fun listSafDirectory(treeOrDirUri: String): List<FileNode> = withContext(Dispatchers.IO) {
        val uri = Uri.parse(treeOrDirUri)
        val doc = DocumentFile.fromTreeUri(context, uri) ?: return@withContext emptyList()
        if (!doc.exists() || !doc.isDirectory) return@withContext emptyList()
        doc.listFiles().map { child ->
            val name = child.name ?: "Unnamed"
            val isDir = child.isDirectory
            FileNode(
                id = child.uri.toString(),
                name = name,
                pathOrUri = child.uri.toString(),
                isDirectory = isDir,
                sizeBytes = if (isDir) 0L else child.length(),
                lastModified = child.lastModified(),
                mimeType = if (isDir) "inode/directory" else (child.type ?: guessMimeType(name)),
                isSafDocument = true,
                canWrite = child.canWrite()
            )
        }.sortedWith(compareByDescending<FileNode> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    suspend fun addSafMount(treeUri: Uri): Result<SafMount> = withContext(Dispatchers.IO) {
        runCatching {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching {
                context.contentResolver.takePersistableUriPermission(treeUri, flags)
            }.onFailure {
                context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val doc = DocumentFile.fromTreeUri(context, treeUri)
            val label = doc?.name?.takeIf { it.isNotBlank() } ?: treeUri.lastPathSegment ?: "Mounted Storage"
            val entity = SafMountEntity(
                id = "saf_${UUID.randomUUID()}",
                treeUri = treeUri.toString(),
                displayName = label,
                addedAt = System.currentTimeMillis()
            )
            dao.upsertSafMount(entity)
            entity.toDomain()
        }
    }

    suspend fun removeSafMount(mount: SafMount) = withContext(Dispatchers.IO) {
        runCatching {
            val uri = Uri.parse(mount.treeUri)
            context.contentResolver.releasePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        dao.deleteSafMount(mount.id)
    }

    suspend fun createFolder(parentPathOrUri: String, name: String, isSaf: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val safeName = name.trim().ifEmpty { error("Folder name cannot be empty") }
                if (isSaf) {
                    val parent = DocumentFile.fromTreeUri(context, Uri.parse(parentPathOrUri))
                        ?: error("Cannot access SAF directory")
                    parent.createDirectory(safeName) ?: error("Could not create folder in mounted storage")
                } else {
                    val folder = File(parentPathOrUri, safeName)
                    if (!folder.exists() && !folder.mkdirs()) {
                        error("Could not create folder")
                    }
                }
                Unit
            }
        }

    suspend fun createTextFile(
        parentPathOrUri: String,
        fileName: String,
        initialContent: String = "",
        isSaf: Boolean
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val safeName = fileName.trim().let {
                if (it.contains('.')) it else "$it.txt"
            }
            if (isSaf) {
                val parent = DocumentFile.fromTreeUri(context, Uri.parse(parentPathOrUri))
                    ?: error("Cannot access SAF directory")
                val created = parent.createFile("text/plain", safeName)
                    ?: error("Could not create file in mounted storage")
                context.contentResolver.openOutputStream(created.uri)?.use { out ->
                    out.write(initialContent.toByteArray())
                }
                created.uri.toString()
            } else {
                val file = File(parentPathOrUri, safeName)
                file.parentFile?.mkdirs()
                file.writeText(initialContent)
                file.absolutePath
            }
        }
    }

    suspend fun readTextFile(pathOrUri: String, isSaf: Boolean): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (isSaf) {
                    context.contentResolver.openInputStream(Uri.parse(pathOrUri))?.bufferedReader()?.use {
                        it.readText()
                    } ?: ""
                } else {
                    val file = File(pathOrUri)
                    if (file.exists()) file.readText() else ""
                }
            }
        }

    suspend fun writeTextFile(pathOrUri: String, content: String, isSaf: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (isSaf) {
                    context.contentResolver.openOutputStream(Uri.parse(pathOrUri), "wt")?.use { out ->
                        out.write(content.toByteArray())
                    } ?: error("Unable to open SAF file for writing")
                } else {
                    val file = File(pathOrUri)
                    file.parentFile?.mkdirs()
                    file.writeText(content)
                }
                Unit
            }
        }

    suspend fun renameNode(node: FileNode, newName: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val clean = newName.trim().ifEmpty { error("Name cannot be empty") }
                if (node.isSafDocument) {
                    val doc = DocumentFile.fromSingleUri(context, Uri.parse(node.pathOrUri))
                        ?: DocumentFile.fromTreeUri(context, Uri.parse(node.pathOrUri))
                        ?: error("Document unavailable")
                    if (!doc.renameTo(clean)) error("SAF provider refused rename")
                } else {
                    val src = File(node.pathOrUri)
                    val dst = File(src.parentFile, clean)
                    if (!src.renameTo(dst)) error("Could not rename item")
                }
                Unit
            }
        }

    suspend fun deleteNode(node: FileNode): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (node.isSafDocument) {
                val doc = DocumentFile.fromSingleUri(context, Uri.parse(node.pathOrUri))
                    ?: DocumentFile.fromTreeUri(context, Uri.parse(node.pathOrUri))
                    ?: error("Document unavailable")
                if (!doc.delete()) error("Could not delete item")
            } else {
                val file = File(node.pathOrUri)
                val deleted = if (file.isDirectory) file.deleteRecursively() else file.delete()
                if (!deleted) error("Could not delete item")
            }
            Unit
        }
    }

    suspend fun copyOrMoveNode(
        source: FileNode,
        destDirPathOrUri: String,
        destIsSaf: Boolean,
        isMove: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (source.isDirectory) {
                error("Copying/moving entire directories across providers is limited; copy individual files.")
            }

            val input = if (source.isSafDocument) {
                context.contentResolver.openInputStream(Uri.parse(source.pathOrUri))
            } else {
                File(source.pathOrUri).inputStream()
            } ?: error("Cannot read source file")

            input.use { inStream ->
                if (destIsSaf) {
                    val destDir = DocumentFile.fromTreeUri(context, Uri.parse(destDirPathOrUri))
                        ?: error("Cannot access destination SAF folder")
                    val created = destDir.createFile(source.mimeType, source.name)
                        ?: error("Cannot create destination file")
                    context.contentResolver.openOutputStream(created.uri)?.use { out ->
                        inStream.copyTo(out)
                    } ?: error("Cannot write destination file")
                } else {
                    val destFile = File(destDirPathOrUri, source.name)
                    destFile.outputStream().use { out ->
                        inStream.copyTo(out)
                    }
                }
            }

            if (isMove) {
                deleteNode(source).getOrThrow()
            }
            Unit
        }
    }

    fun openNodeExternally(node: FileNode): Result<Unit> = runCatching {
        val uri: Uri = if (node.isSafDocument) {
            Uri.parse(node.pathOrUri)
        } else {
            val file = File(node.pathOrUri)
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, node.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Open ${node.name} with").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun isTextEditable(name: String, mimeType: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("txt", "md", "json", "log", "csv", "xml", "kt", "py", "js", "ini", "cfg") ||
            mimeType.startsWith("text/")
    }

    private fun guessMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext.isEmpty()) return "application/octet-stream"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "md", "log", "ini", "cfg" -> "text/plain"
            "json" -> "application/json"
            else -> "application/octet-stream"
        }
    }
}
