package com.example.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class SystemStatus(
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val wifiConnected: Boolean = false,
    val wifiEnabled: Boolean = false,
    val wifiSignalLevel: Int = 0, // 0..4
    val mobileConnected: Boolean = false,
    val volumePercent: Int = 70,
    val ringVolumePercent: Int = 70,
    val isMuted: Boolean = false,
    val bluetoothEnabled: Boolean = false,
    val currentTimeMillis: Long = System.currentTimeMillis(),
    val storageUsedBytes: Long = 0L,
    val storageTotalBytes: Long = 0L,
    val ramUsedBytes: Long = 0L,
    val ramTotalBytes: Long = 0L,
    val isDefaultLauncher: Boolean = false,
    val supportsFreeformWindows: Boolean = false
)
