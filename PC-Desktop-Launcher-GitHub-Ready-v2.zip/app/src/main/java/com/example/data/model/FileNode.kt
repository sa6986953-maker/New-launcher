package com.example.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class FileNode(
    val id: String,
    val name: String,
    val pathOrUri: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val mimeType: String,
    val isSafDocument: Boolean,
    val canWrite: Boolean = true
)

@Immutable
data class SafMount(
    val id: String,
    val treeUri: String,
    val displayName: String,
    val addedAt: Long
)

enum class ExplorerRootSection(val label: String, val folderName: String) {
    THIS_PC("This PC", ""),
    DESKTOP("Desktop", "Desktop"),
    DOCUMENTS("Documents", "Documents"),
    DOWNLOADS("Downloads", "Downloads"),
    PICTURES("Pictures", "Pictures"),
    MUSIC("Music", "Music"),
    VIDEOS("Videos", "Videos")
}

data class FileClipboard(
    val node: FileNode,
    val isCut: Boolean
)
