package com.example.data.model

import androidx.compose.runtime.Immutable

enum class WindowType {
    FILE_EXPLORER,
    PC_SETTINGS,
    RECYCLE_BIN,
    DESKTOP_FOLDER,
    NOTEPAD,
    TASK_MONITOR,
    GALLERY,
    PRIVATE_VAULT,
    EXTERNAL_APP_HOST
}

@Immutable
data class DesktopWindow(
    val id: String,
    val type: WindowType,
    val title: String,
    val subtitle: String? = null,
    val folderId: String? = null,
    val initialPath: String? = null,
    val fileUriOrPath: String? = null,
    val appPackage: String? = null,
    val appActivity: String? = null,
    val xOffsetDp: Float = 24f,
    val yOffsetDp: Float = 24f,
    val widthDp: Float = 620f,
    val heightDp: Float = 460f,
    val isMinimized: Boolean = false,
    val isMaximized: Boolean = false,
    val zIndex: Int = 1
)
