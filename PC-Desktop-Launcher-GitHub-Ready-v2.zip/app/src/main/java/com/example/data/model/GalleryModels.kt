package com.example.data.model

import androidx.compose.runtime.Immutable

enum class MediaType {
    PHOTO,
    VIDEO
}

enum class GallerySortOrder(val label: String) {
    NEWEST("Newest First"),
    OLDEST("Oldest First"),
    NAME_ASC("Name (A–Z)"),
    SIZE_DESC("Largest First")
}

@Immutable
data class GalleryAlbum(
    val id: String,
    val name: String,
    val isPrivate: Boolean,
    val createdAt: Long
)

@Immutable
data class GalleryMediaItem(
    val id: String,
    val albumId: String,
    val displayName: String,
    val mediaType: MediaType,
    val filePath: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long = 0L,
    val addedAt: Long = System.currentTimeMillis(),
    val isPrivate: Boolean = false
)

@Immutable
data class HiddenAppInfo(
    val componentKey: String,
    val packageName: String,
    val activityName: String,
    val label: String,
    val hiddenAt: Long
)
