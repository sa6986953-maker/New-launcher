package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopItemType
import com.example.data.model.GalleryAlbum
import com.example.data.model.GalleryMediaItem
import com.example.data.model.HiddenAppInfo
import com.example.data.model.MediaType
import com.example.data.model.RecycleBinItem
import com.example.data.model.SafMount

@Entity(tableName = "desktop_items")
data class DesktopItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String,
    val targetPackage: String? = null,
    val targetActivity: String? = null,
    val targetPath: String? = null,
    val gridCol: Int = 0,
    val gridRow: Int = 0,
    val parentFolderId: String? = null,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): DesktopItem = DesktopItem(
        id = id,
        title = title,
        type = DesktopItemType.entries.firstOrNull { it.name == type } ?: DesktopItemType.FILE,
        targetPackage = targetPackage,
        targetActivity = targetActivity,
        targetPath = targetPath,
        gridCol = gridCol,
        gridRow = gridRow,
        parentFolderId = parentFolderId,
        sortOrder = sortOrder,
        createdAt = createdAt
    )

    companion object {
        fun fromDomain(item: DesktopItem): DesktopItemEntity = DesktopItemEntity(
            id = item.id,
            title = item.title,
            type = item.type.name,
            targetPackage = item.targetPackage,
            targetActivity = item.targetActivity,
            targetPath = item.targetPath,
            gridCol = item.gridCol,
            gridRow = item.gridRow,
            parentFolderId = item.parentFolderId,
            sortOrder = item.sortOrder,
            createdAt = item.createdAt
        )
    }
}

@Entity(tableName = "recycle_bin_items")
data class RecycleBinEntity(
    @PrimaryKey val id: String,
    val originalItemId: String,
    val title: String,
    val type: String,
    val targetPackage: String? = null,
    val targetActivity: String? = null,
    val targetPath: String? = null,
    val originalLocation: String = "Desktop",
    val deletedAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): RecycleBinItem = RecycleBinItem(
        id = id,
        originalItemId = originalItemId,
        title = title,
        type = DesktopItemType.entries.firstOrNull { it.name == type } ?: DesktopItemType.FILE,
        targetPackage = targetPackage,
        targetActivity = targetActivity,
        targetPath = targetPath,
        originalLocation = originalLocation,
        deletedAt = deletedAt
    )
}

@Entity(tableName = "pinned_apps")
data class PinnedAppEntity(
    @PrimaryKey val componentKey: String,
    val packageName: String,
    val activityName: String,
    val label: String,
    val pinnedToTaskbar: Boolean = false,
    val pinnedToStart: Boolean = true,
    val sortOrder: Int = 0
)

@Entity(tableName = "recent_apps")
data class RecentAppEntity(
    @PrimaryKey val componentKey: String,
    val packageName: String,
    val activityName: String,
    val lastLaunchedAt: Long
)

@Entity(tableName = "saf_mounts")
data class SafMountEntity(
    @PrimaryKey val id: String,
    val treeUri: String,
    val displayName: String,
    val addedAt: Long
) {
    fun toDomain(): SafMount = SafMount(
        id = id,
        treeUri = treeUri,
        displayName = displayName,
        addedAt = addedAt
    )
}

@Entity(tableName = "saved_themes")
data class SavedThemeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val themeJson: String,
    val createdAt: Long
) {
    fun toDomain(): com.example.data.model.SavedThemeProfile =
        com.example.data.model.SavedThemeProfile(
            id = id,
            name = name,
            themeJson = themeJson,
            createdAt = createdAt
        )
}

@Entity(tableName = "hidden_apps")
data class HiddenAppEntity(
    @PrimaryKey val componentKey: String,
    val packageName: String,
    val activityName: String,
    val label: String,
    val hiddenAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): HiddenAppInfo = HiddenAppInfo(
        componentKey = componentKey,
        packageName = packageName,
        activityName = activityName,
        label = label,
        hiddenAt = hiddenAt
    )
}

@Entity(tableName = "gallery_albums")
data class GalleryAlbumEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isPrivate: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): GalleryAlbum = GalleryAlbum(
        id = id,
        name = name,
        isPrivate = isPrivate,
        createdAt = createdAt
    )
}

@Entity(tableName = "gallery_media")
data class GalleryMediaEntity(
    @PrimaryKey val id: String,
    val albumId: String,
    val displayName: String,
    val mediaType: String,
    val filePath: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long = 0L,
    val addedAt: Long = System.currentTimeMillis(),
    val isPrivate: Boolean = false
) {
    fun toDomain(): GalleryMediaItem = GalleryMediaItem(
        id = id,
        albumId = albumId,
        displayName = displayName,
        mediaType = MediaType.entries.firstOrNull { it.name == mediaType } ?: MediaType.PHOTO,
        filePath = filePath,
        mimeType = mimeType,
        sizeBytes = sizeBytes,
        durationMs = durationMs,
        addedAt = addedAt,
        isPrivate = isPrivate
    )
}
