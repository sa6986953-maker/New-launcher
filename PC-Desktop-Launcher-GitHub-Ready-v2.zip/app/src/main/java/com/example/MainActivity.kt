package com.example

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.OrientationMode
import com.example.ui.PcDesktopScreen
import com.example.ui.viewmodel.LauncherViewModel

class MainActivity : FragmentActivity() {

    private val launcherViewModel: LauncherViewModel by viewModels()

    private val homeRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        launcherViewModel.refreshSystemStatus()
        if (result.resultCode != RESULT_OK) {
            if (!launcherViewModel.systemStatus.value.isDefaultLauncher) {
                launcherViewModel.openDefaultHomeSettings()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureDisplayCutoutAndSystemWindows()

        // Default to landscape laptop mode immediately unless user chose otherwise
        applyOrientation(launcherViewModel.settings.value.orientationMode)
        applyImmersiveMode(launcherViewModel.settings.value.fullScreenImmersive)

        setContent {
            val settings by launcherViewModel.settings.collectAsStateWithLifecycle()

            LaunchedEffect(settings.orientationMode) {
                applyOrientation(settings.orientationMode)
            }

            LaunchedEffect(settings.fullScreenImmersive) {
                applyImmersiveMode(settings.fullScreenImmersive)
            }

            PcDesktopScreen(
                viewModel = launcherViewModel,
                onRequestDefaultHome = { requestDefaultHomeLauncher() },
                onExitLauncher = {
                    if (!launcherViewModel.systemStatus.value.isDefaultLauncher) {
                        finish()
                    } else {
                        launcherViewModel.openDefaultHomeSettings()
                    }
                }
            )
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyImmersiveMode(launcherViewModel.settings.value.fullScreenImmersive)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            launcherViewModel.onHomePressed()
        }
    }

    override fun onResume() {
        super.onResume()
        launcherViewModel.refreshSystemStatus()
        applyImmersiveMode(launcherViewModel.settings.value.fullScreenImmersive)
    }

    private fun configureDisplayCutoutAndSystemWindows() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = lp
        }
    }

    private fun applyImmersiveMode(enabled: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (enabled) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun applyOrientation(mode: OrientationMode) {
        val target = when (mode) {
            OrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            OrientationMode.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            OrientationMode.AUTO -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (requestedOrientation != target) {
            requestedOrientation = target
        }
    }

    private fun requestDefaultHomeLauncher() {
        val roleIntent = launcherViewModel.createRequestHomeRoleIntent()
        if (roleIntent != null) {
            runCatching {
                homeRoleLauncher.launch(roleIntent)
            }.onFailure {
                launcherViewModel.openDefaultHomeSettings()
            }
        } else {
            launcherViewModel.openDefaultHomeSettings()
        }
    }
}
