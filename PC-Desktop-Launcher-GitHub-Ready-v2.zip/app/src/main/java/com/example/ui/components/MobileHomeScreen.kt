package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherMode
import com.example.data.model.PcSettingsState
import com.example.data.model.SystemStatus
import com.example.data.model.VaultAccessMethod
import com.example.data.model.WindowType
import com.example.ui.theme.FolderAmber
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MobileHomeScreen(
    installedApps: List<InstalledApp>,
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    var searchQuery by remember { mutableStateOf("") }
    var clockTapTimes by remember { mutableStateOf<List<Long>>(emptyList()) }

    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) installedApps
        else installedApps.filter {
            it.label.contains(searchQuery, ignoreCase = true) ||
                it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }
    val secretCommandMatched = remember(searchQuery, settings.vaultSecretPhrase) {
        val trimmed = searchQuery.trim()
        trimmed.isNotEmpty() && trimmed.equals(settings.vaultSecretPhrase.trim(), ignoreCase = true)
    }

    val nowDate = remember(systemStatus.currentTimeMillis) { Date(systemStatus.currentTimeMillis) }
    val timeStr = remember(systemStatus.currentTimeMillis) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(nowDate)
    }
    val dateStr = remember(systemStatus.currentTimeMillis) {
        SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(nowDate)
    }

    val insetMod = if (settings.fullScreenImmersive) {
        Modifier
    } else {
        Modifier.windowInsetsPadding(WindowInsets.statusBars).windowInsetsPadding(WindowInsets.navigationBars)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .then(insetMod)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("mobile_home_screen")
    ) {
        // Top Mobile Mode Header & Desktop Switch Pill
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable {
                        val now = System.currentTimeMillis()
                        val recent = (clockTapTimes + now).filter { now - it <= 1200L }
                        clockTapTimes = recent
                        if (settings.vaultAccessMethod == VaultAccessMethod.CLOCK_TRIPLE_TAP && recent.size >= 3) {
                            clockTapTimes = emptyList()
                            viewModel.triggerDiscreetVaultAccess()
                        }
                    }
                    .padding(4.dp)
            ) {
                Text(
                    text = timeStr,
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = JetBrainsMonoFamily
                )
                Text(
                    text = dateStr,
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0x660F172A),
                    modifier = Modifier.border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (systemStatus.wifiConnected) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                            contentDescription = "Network",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Icon(
                            imageVector = if (systemStatus.isCharging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryFull,
                            contentDescription = "Battery",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Text("${systemStatus.batteryPercent}%", color = Color.White, style = MaterialTheme.typography.labelSmall, fontFamily = JetBrainsMonoFamily)
                    }
                }

                IconButton(
                    onClick = { viewModel.lockDesktop() },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x660F172A))
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = "Lock Launcher", tint = Color.White, modifier = Modifier.size(18.dp))
                }

                Button(
                    onClick = { viewModel.setLauncherMode(LauncherMode.DESKTOP) },
                    modifier = Modifier.testTag("mobile_to_desktop_switch")
                ) {
                    Icon(Icons.Rounded.DesktopWindows, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Desktop Mode")
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search apps in Normal Mobile Mode", color = Color.White.copy(alpha = 0.7f)) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = Color.White) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Rounded.Clear, contentDescription = "Clear", tint = Color.White)
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = Color(0x660F172A),
                unfocusedContainerColor = Color(0x550F172A),
                focusedBorderColor = pcPalette.accent,
                unfocusedBorderColor = Color(0x44FFFFFF)
            ),
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().testTag("mobile_search_input")
        )

        if (secretCommandMatched) {
            Spacer(Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = pcPalette.flyoutSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable {
                        searchQuery = ""
                        viewModel.triggerDiscreetVaultAccess()
                    }
                    .testTag("mobile_secret_vault_result")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(12.dp)) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = pcPalette.accent)
                    Spacer(Modifier.width(10.dp))
                    Text("Open Protected Space", style = MaterialTheme.typography.titleSmall)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // App Drawer Grid
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0x660B132B),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(20.dp))
        ) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 84.dp),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredApps, key = { it.componentKey }) { app ->
                    var showMenu by remember { mutableStateOf(false) }
                    Box {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .combinedClickable(
                                    onClick = { viewModel.openAppInDesktopOrMobileMode(app, forceDirectLaunch = true) },
                                    onLongClick = { showMenu = true }
                                )
                                .padding(vertical = 8.dp, horizontal = 4.dp)
                                .testTag("mobile_app_${app.packageName}")
                        ) {
                            AppPackageIcon(
                                packageName = app.packageName,
                                activityName = app.activityName,
                                contentDescription = app.label,
                                viewModel = viewModel,
                                size = 48.dp
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = app.label,
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Open in Mobile Mode") },
                                onClick = {
                                    showMenu = false
                                    viewModel.openAppInDesktopOrMobileMode(app, forceDirectLaunch = true)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Hide App (Private Vault)") },
                                leadingIcon = { Icon(Icons.Rounded.VisibilityOff, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    viewModel.hideApp(app)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("App Info") },
                                leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    viewModel.openAppInfo(app.packageName)
                                }
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Bottom Mobile Quick Dock
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color(0x880B132B),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(22.dp))
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
            ) {
                MobileDockButton(
                    icon = Icons.Rounded.Folder,
                    label = "Files",
                    tint = FolderAmber,
                    onClick = {
                        viewModel.setLauncherMode(LauncherMode.DESKTOP)
                        viewModel.openWindow(WindowType.FILE_EXPLORER, "This PC")
                    }
                )
                MobileDockButton(
                    icon = Icons.Rounded.PhotoLibrary,
                    label = "Gallery",
                    tint = Color(0xFFEC4899),
                    onClick = {
                        viewModel.setLauncherMode(LauncherMode.DESKTOP)
                        viewModel.openWindow(WindowType.GALLERY, "Gallery")
                    }
                )
                MobileDockButton(
                    icon = Icons.Rounded.Settings,
                    label = "PC Settings",
                    tint = Color(0xFF60A5FA),
                    onClick = {
                        viewModel.setLauncherMode(LauncherMode.DESKTOP)
                        viewModel.openWindow(WindowType.PC_SETTINGS, "PC Settings")
                    }
                )
                MobileDockButton(
                    icon = Icons.Rounded.DesktopWindows,
                    label = "Desktop",
                    tint = pcPalette.accent,
                    onClick = { viewModel.setLauncherMode(LauncherMode.DESKTOP) }
                )
            }
        }
    }
}

@Composable
private fun MobileDockButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}
