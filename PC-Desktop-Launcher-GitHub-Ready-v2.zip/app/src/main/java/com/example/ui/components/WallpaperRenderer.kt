package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.WallpaperFitOption
import com.example.data.model.WallpaperPreset
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WallpaperSurface(
    wallpaperId: String,
    customUri: String?,
    backgroundArgb: Long,
    fitOption: WallpaperFitOption = WallpaperFitOption.CROP,
    dimAlpha: Float = 0f,
    modifier: Modifier = Modifier
) {
    val bgColor = Color(backgroundArgb.toInt())
    val contentScale = when (fitOption) {
        WallpaperFitOption.CROP -> ContentScale.Crop
        WallpaperFitOption.FIT -> ContentScale.Fit
        WallpaperFitOption.STRETCH -> ContentScale.FillBounds
        WallpaperFitOption.CENTER -> ContentScale.Inside
    }

    Box(modifier = modifier.fillMaxSize().background(bgColor)) {
        if (!customUri.isNullOrBlank()) {
            AsyncImage(
                model = Uri.parse(customUri),
                contentDescription = "Custom Wallpaper",
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            when (wallpaperId) {
                WallpaperPreset.BLOOM.id -> Image(
                    painter = painterResource(id = R.drawable.img_wallpaper_bloom),
                    contentDescription = "Luminous Bloom",
                    contentScale = contentScale,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.ABSTRACT_PRISM.id -> Image(
                    painter = painterResource(id = R.drawable.img_wallpaper_prism),
                    contentDescription = "Iridescent Prism",
                    contentScale = contentScale,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.ALPINE_LAKE.id -> Image(
                    painter = painterResource(id = R.drawable.img_wallpaper_alpine),
                    contentDescription = "Alpine Blue Hour",
                    contentScale = contentScale,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.AURORA.id -> Image(
                    painter = painterResource(id = R.drawable.img_wallpaper_aurora),
                    contentDescription = "Northern Aurora",
                    contentScale = contentScale,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.SUNSET.id -> Image(
                    painter = painterResource(id = R.drawable.img_wallpaper_sunset),
                    contentDescription = "Dusk Dunes",
                    contentScale = contentScale,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.SUNRISE.id -> Image(
                    painter = painterResource(id = R.drawable.img_wallpaper_sunrise),
                    contentDescription = "Pearl Sunrise",
                    contentScale = contentScale,
                    modifier = Modifier.fillMaxSize()
                )

                WallpaperPreset.LUMINOUS_RIBBON.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFFE0F2FE), Color(0xFFBAE6FD), Color(0xFFDBEAFE))
                        )
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xAA38BDF8), Color(0x0038BDF8)),
                            center = Offset(size.width * 0.65f, size.height * 0.45f),
                            radius = size.minDimension * 0.7f
                        ),
                        center = Offset(size.width * 0.65f, size.height * 0.45f),
                        radius = size.minDimension * 0.7f
                    )
                    val path = Path().apply {
                        moveTo(0f, size.height * 0.75f)
                        cubicTo(
                            size.width * 0.3f, size.height * 0.25f,
                            size.width * 0.65f, size.height * 0.85f,
                            size.width, size.height * 0.3f
                        )
                        lineTo(size.width, size.height)
                        lineTo(0f, size.height)
                        close()
                    }
                    drawPath(
                        path = path,
                        brush = Brush.linearGradient(listOf(Color(0x880284C7), Color(0x557DD3FC)))
                    )
                }

                WallpaperPreset.FLUENT_WAVES.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF061A38), Color(0xFF0A3264), Color(0xFF092347))
                        )
                    )
                    val wave1 = Path().apply {
                        moveTo(0f, size.height * 0.62f)
                        cubicTo(size.width * 0.28f, size.height * 0.35f, size.width * 0.68f, size.height * 0.82f, size.width, size.height * 0.46f)
                        lineTo(size.width, size.height)
                        lineTo(0f, size.height)
                        close()
                    }
                    drawPath(wave1, brush = Brush.linearGradient(listOf(Color(0x7738BDF8), Color(0x440078D4))))
                    val wave2 = Path().apply {
                        moveTo(0f, size.height * 0.78f)
                        cubicTo(size.width * 0.35f, size.height * 0.55f, size.width * 0.72f, size.height * 0.92f, size.width, size.height * 0.68f)
                        lineTo(size.width, size.height)
                        lineTo(0f, size.height)
                        close()
                    }
                    drawPath(wave2, brush = Brush.linearGradient(listOf(Color(0x6660A5FA), Color(0x331D4ED8))))
                }

                WallpaperPreset.CLASSIC_TEAL.id -> Box(
                    modifier = Modifier.fillMaxSize().background(Color(0xFF008080))
                )

                WallpaperPreset.MIDNIGHT_MESH.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF050811)),
                            center = Offset(size.width * 0.5f, size.height * 0.4f),
                            radius = size.maxDimension * 0.8f
                        )
                    )
                }

                WallpaperPreset.OBSIDIAN_GRID.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(Color(0xFF090D16))
                    val step = (size.minDimension / 12f).coerceAtLeast(32f)
                    var x = 0f
                    while (x < size.width) {
                        drawLine(Color(0x1438BDF8), Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                        x += step
                    }
                    var y = 0f
                    while (y < size.height) {
                        drawLine(Color(0x1438BDF8), Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                        y += step
                    }
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0x2838BDF8), Color.Transparent),
                            center = Offset(size.width * 0.7f, size.height * 0.35f),
                            radius = size.minDimension * 0.65f
                        ),
                        center = Offset(size.width * 0.7f, size.height * 0.35f),
                        radius = size.minDimension * 0.65f
                    )
                }

                WallpaperPreset.SLATE_HORIZON.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF090D16))
                        )
                    )
                    drawLine(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color(0x5594A3B8), Color.Transparent)
                        ),
                        start = Offset(0f, size.height * 0.58f),
                        end = Offset(size.width, size.height * 0.58f),
                        strokeWidth = 2f
                    )
                }

                WallpaperPreset.GRAPHITE_RADIAL.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(Color(0xFF111318))
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF2B303C), Color(0xFF171A21), Color(0xFF0C0E12)),
                            center = Offset(size.width * 0.5f, size.height * 0.5f),
                            radius = size.maxDimension * 0.6f
                        )
                    )
                }

                WallpaperPreset.SILK_RIBBONS.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF140C2E), Color(0xFF2B1055), Color(0xFF0B132B))
                        )
                    )
                    val p1 = Path().apply {
                        moveTo(0f, size.height * 0.35f)
                        cubicTo(size.width * 0.35f, size.height * 0.1f, size.width * 0.65f, size.height * 0.7f, size.width, size.height * 0.25f)
                        lineTo(size.width, size.height * 0.58f)
                        cubicTo(size.width * 0.62f, size.height * 0.92f, size.width * 0.3f, size.height * 0.35f, 0f, size.height * 0.65f)
                        close()
                    }
                    drawPath(p1, brush = Brush.linearGradient(listOf(Color(0x99EC4899), Color(0x888B5CF6), Color(0x7706B6D4))))
                }

                WallpaperPreset.COSMIC_ORBS.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(listOf(Color(0xFF070B1E), Color(0xFF141B38)))
                    )
                    drawCircle(
                        brush = Brush.radialGradient(listOf(Color(0xAA06B6D4), Color.Transparent)),
                        center = Offset(size.width * 0.28f, size.height * 0.35f),
                        radius = size.minDimension * 0.42f
                    )
                    drawCircle(
                        brush = Brush.radialGradient(listOf(Color(0xAA8B5CF6), Color.Transparent)),
                        center = Offset(size.width * 0.72f, size.height * 0.58f),
                        radius = size.minDimension * 0.48f
                    )
                    drawCircle(
                        brush = Brush.radialGradient(listOf(Color(0x66EC4899), Color.Transparent)),
                        center = Offset(size.width * 0.54f, size.height * 0.28f),
                        radius = size.minDimension * 0.3f
                    )
                }

                WallpaperPreset.CRYSTAL_FACETS.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(Brush.linearGradient(listOf(Color(0xFF0B1120), Color(0xFF172554))))
                    val poly1 = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(size.width * 0.55f, size.height * 0.32f)
                        lineTo(size.width * 0.22f, size.height * 0.85f)
                        close()
                    }
                    val poly2 = Path().apply {
                        moveTo(size.width, 0f)
                        lineTo(size.width * 0.48f, size.height * 0.42f)
                        lineTo(size.width, size.height * 0.75f)
                        close()
                    }
                    drawPath(poly1, Color(0x3338BDF8))
                    drawPath(poly2, Color(0x286366F1))
                }

                WallpaperPreset.OCEAN_GLASS.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF0284C7), Color(0xFF0B3B6F), Color(0xFF08203E))
                        )
                    )
                }

                WallpaperPreset.EMERALD_MIST.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF022C22), Color(0xFF065F46), Color(0xFF0F172A))
                        )
                    )
                }

                WallpaperPreset.ROYAL_DUSK.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF1E1B4B), Color(0xFF4C1D95), Color(0xFF0F172A))
                        )
                    )
                }

                WallpaperPreset.COPPER_DAWN.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF451A03), Color(0xFFB45309), Color(0xFF1E293B))
                        )
                    )
                }

                WallpaperPreset.AMOLED_PURE.id -> Box(
                    modifier = Modifier.fillMaxSize().background(Color(0xFF000000))
                )

                WallpaperPreset.AMOLED_CONSTELLATION.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(Color(0xFF000000))
                    val stars = listOf(
                        0.12f to 0.18f, 0.24f to 0.42f, 0.37f to 0.14f, 0.49f to 0.62f,
                        0.63f to 0.22f, 0.76f to 0.48f, 0.88f to 0.19f, 0.18f to 0.78f,
                        0.71f to 0.81f, 0.42f to 0.36f, 0.58f to 0.74f, 0.84f to 0.67f
                    )
                    stars.forEachIndexed { idx, (fx, fy) ->
                        val p = Offset(size.width * fx, size.height * fy)
                        drawCircle(
                            color = if (idx % 3 == 0) Color(0xCC38BDF8) else Color(0xAAFFFFFF),
                            radius = if (idx % 4 == 0) 2.6f else 1.6f,
                            center = p
                        )
                        if (idx > 0 && idx % 3 == 0) {
                            val prev = stars[idx - 1]
                            drawLine(
                                color = Color(0x2838BDF8),
                                start = Offset(size.width * prev.first, size.height * prev.second),
                                end = p,
                                strokeWidth = 1f
                            )
                        }
                    }
                }

                WallpaperPreset.AMOLED_NEON_RING.id -> Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(Color(0xFF000000))
                    val center = Offset(size.width * 0.5f, size.height * 0.5f)
                    val radius = size.minDimension * 0.34f
                    drawCircle(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFF06B6D4),
                                Color(0xFF3B82F6),
                                Color(0xFF8B5CF6),
                                Color(0xFFEC4899),
                                Color(0xFF06B6D4)
                            ),
                            center = center
                        ),
                        center = center,
                        radius = radius,
                        style = Stroke(width = (size.minDimension * 0.03f).coerceAtLeast(6f))
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0x2206B6D4), Color.Transparent),
                            center = center,
                            radius = radius * 1.45f
                        ),
                        center = center,
                        radius = radius * 1.45f
                    )
                }

                WallpaperPreset.SOLID_COLOR.id -> {
                    // Already filled with bgColor
                }

                else -> {
                    // Graceful geometric fallback
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFF0B3B6F), Color(0xFF08203E), Color(0xFF0F172A))
                            )
                        )
                    }
                }
            }
        }

        if (dimAlpha > 0.01f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = dimAlpha))
            )
        }
    }
}
