package com.example.ui.components

import android.provider.Settings
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.BatteryStd
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MonitorHeart
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.WebAsset
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PinnedAppEntity
import com.example.data.model.DesktopThemePreset
import com.example.data.model.DesktopWindow
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherNotification
import com.example.data.model.OrientationMode
import com.example.data.model.PcSettingsState
import com.example.data.model.SystemStatus
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarStyle
import com.example.data.model.VaultAccessMethod
import com.example.data.model.WindowType
import com.example.ui.theme.FolderAmber
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WindowsTaskbar(
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    pinnedApps: List<PinnedAppEntity>,
    installedApps: List<InstalledApp>,
    openWindows: List<DesktopWindow>,
    activeWindowId: String?,
    startMenuOpen: Boolean,
    unreadNotificationCount: Int,
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    val taskbarPinned = remember(pinnedApps) { pinnedApps.filter { it.pinnedToTaskbar } }
    val thicknessDp = settings.effectiveTaskbarThicknessDp().dp
    val iconSize = (settings.taskbarSize.iconDp * (settings.effectiveTaskbarThicknessDp() / 52f).coerceIn(0.85f, 1.25f)).dp
    val iconSpacing = settings.taskbarIconSpacingDp.dp

    val isVertical = settings.taskbarPosition == TaskbarPosition.LEFT || settings.taskbarPosition == TaskbarPosition.RIGHT
    val isMacFloating = settings.themePreset == DesktopThemePreset.MACOS_INSPIRED && !isVertical

    val effectiveAlpha = when (settings.taskbarStyle) {
        TaskbarStyle.TRANSPARENT -> settings.taskbarTransparency.coerceAtMost(0.55f)
        TaskbarStyle.BLURRED -> settings.taskbarTransparency.coerceIn(0.65f, 0.92f)
        TaskbarStyle.SOLID -> 1.0f
        TaskbarStyle.CUSTOM -> settings.taskbarTransparency
    }
    val barBg = pcPalette.taskbarBase.copy(alpha = effectiveAlpha)

    val insetModifier = if (settings.fullScreenImmersive) {
        Modifier
    } else {
        when (settings.taskbarPosition) {
            TaskbarPosition.BOTTOM -> Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            TaskbarPosition.TOP -> Modifier.windowInsetsPadding(WindowInsets.statusBars)
            TaskbarPosition.LEFT, TaskbarPosition.RIGHT -> Modifier.windowInsetsPadding(WindowInsets.navigationBars)
        }
    }

    val containerShape = if (isMacFloating) RoundedCornerShape(20.dp) else RoundedCornerShape(0.dp)
    val outerMargin = if (isMacFloating) Modifier.padding(horizontal = 16.dp, vertical = 6.dp) else Modifier

    val surfaceModifier = modifier
        .then(outerMargin)
        .clip(containerShape)
        .background(
            if (settings.taskbarStyle == TaskbarStyle.BLURRED && !settings.batterySaverMode) {
                Brush.verticalGradient(
                    listOf(barBg.copy(alpha = (effectiveAlpha + 0.06f).coerceAtMost(1f)), barBg)
                )
            } else {
                Brush.verticalGradient(listOf(barBg, barBg))
            }
        )
        .then(insetModifier)
        .border(0.6.dp, pcPalette.windowBorder, containerShape)

    if (isVertical) {
        // Vertical Taskbar (Left or Right Dock)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = surfaceModifier
                .width(thicknessDp + 8.dp)
                .fillMaxHeight()
                .padding(vertical = 8.dp)
        ) {
            TaskbarActionTile(
                isActive = startMenuOpen,
                isFocused = startMenuOpen,
                isVertical = true,
                onClick = { viewModel.toggleStartMenu(focusSearch = false) },
                modifier = Modifier.testTag("start_button")
            ) {
                WindowsLogoIcon(size = iconSize)
            }

            if (settings.showTaskbarSearch) {
                Spacer(Modifier.height(iconSpacing))
                TaskbarActionTile(
                    isActive = false,
                    isFocused = false,
                    isVertical = true,
                    onClick = { viewModel.toggleStartMenu(focusSearch = true) },
                    modifier = Modifier.testTag("taskbar_search_button")
                ) {
                    Icon(Icons.Rounded.Search, contentDescription = "Search", modifier = Modifier.size(iconSize))
                }
            }

            Spacer(Modifier.height(6.dp))
            HorizontalDivider(color = pcPalette.windowBorder, modifier = Modifier.padding(horizontal = 8.dp))
            Spacer(Modifier.height(6.dp))

            // Pinned & Running Windows vertical scroll
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(iconSpacing),
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
            ) {
                if (openWindows.none { it.type == WindowType.FILE_EXPLORER }) {
                    TaskbarActionTile(
                        isActive = false,
                        isFocused = false,
                        isVertical = true,
                        onClick = { viewModel.openWindow(WindowType.FILE_EXPLORER, "This PC") },
                        modifier = Modifier.testTag("taskbar_explorer_pin")
                    ) {
                        Icon(Icons.Rounded.Folder, contentDescription = "File Explorer", tint = FolderAmber, modifier = Modifier.size(iconSize))
                    }
                }

                taskbarPinned.forEach { pin ->
                    TaskbarActionTile(
                        isActive = false,
                        isFocused = false,
                        isVertical = true,
                        onClick = { viewModel.launchPackageShortcut(pin.packageName, pin.activityName, pin.label) },
                        modifier = Modifier.testTag("taskbar_pin_${pin.packageName}")
                    ) {
                        AppPackageIcon(pin.packageName, pin.activityName, pin.label, viewModel, size = iconSize)
                    }
                }

                openWindows.forEach { win ->
                    val isFocused = !win.isMinimized && win.id == activeWindowId
                    TaskbarActionTile(
                        isActive = true,
                        isFocused = isFocused,
                        isVertical = true,
                        onClick = { viewModel.toggleMinimizeFromTaskbar(win.id) },
                        modifier = Modifier.testTag("taskbar_window_${win.type.name}")
                    ) {
                        Icon(
                            imageVector = windowTypeIcon(win.type),
                            contentDescription = win.title,
                            tint = windowTypeTint(win.type, pcPalette.accent),
                            modifier = Modifier.size(iconSize)
                        )
                    }
                }
            }

            HorizontalDivider(color = pcPalette.windowBorder, modifier = Modifier.padding(horizontal = 8.dp))
            Spacer(Modifier.height(6.dp))

            // Vertical System Tray
            IconButton(
                onClick = { viewModel.toggleLauncherMode() },
                modifier = Modifier.size(40.dp).testTag("taskbar_mode_switch")
            ) {
                Icon(
                    imageVector = Icons.Rounded.PhoneAndroid,
                    contentDescription = "Switch to Normal Mobile Mode",
                    modifier = Modifier.size(18.dp)
                )
            }
            NotificationTrayButton(
                unreadCount = unreadNotificationCount,
                showBadge = settings.showTaskbarNotificationBadge,
                onClick = { viewModel.toggleNotificationCenter() }
            )
            IconButton(
                onClick = { viewModel.toggleQuickSettings() },
                modifier = Modifier.size(40.dp).testTag("system_tray_button")
            ) {
                Icon(
                    imageVector = if (systemStatus.wifiConnected) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                    contentDescription = "Quick Settings",
                    modifier = Modifier.size(18.dp)
                )
            }
            val timeStr = remember(systemStatus.currentTimeMillis) {
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(systemStatus.currentTimeMillis))
            }
            var clockTapTimes by remember { mutableStateOf<List<Long>>(emptyList()) }
            Text(
                text = timeStr,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                        val now = System.currentTimeMillis()
                        val recent = (clockTapTimes + now).filter { now - it <= 1200L }
                        clockTapTimes = recent
                        if (settings.vaultAccessMethod == VaultAccessMethod.CLOCK_TRIPLE_TAP && recent.size >= 3) {
                            clockTapTimes = emptyList()
                            viewModel.triggerDiscreetVaultAccess()
                        } else {
                            viewModel.toggleCalendarFlyout()
                        }
                    }
                    .padding(horizontal = 4.dp, vertical = 4.dp)
                    .testTag("taskbar_clock_button")
            )
        }
        return
    }

    // Horizontal Taskbar (Bottom or Top)
    BoxWithConstraints(
        modifier = surfaceModifier.fillMaxWidth()
    ) {
        val isWide = maxWidth >= 520.dp

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .height(thicknessDp)
                .padding(horizontal = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(iconSpacing),
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState())
            ) {
                TaskbarActionTile(
                    isActive = startMenuOpen,
                    isFocused = startMenuOpen,
                    onClick = { viewModel.toggleStartMenu(focusSearch = false) },
                    modifier = Modifier.testTag("start_button")
                ) {
                    WindowsLogoIcon(size = iconSize)
                }

                if (settings.showTaskbarSearch) {
                    if (isWide) {
                        Surface(
                            shape = RoundedCornerShape(pcPalette.cardCornerDp.coerceAtLeast(16.dp)),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                            modifier = Modifier
                                .height((settings.effectiveTaskbarThicknessDp() - 14).coerceAtLeast(28).dp)
                                .widthIn(min = 130.dp, max = 200.dp)
                                .clip(RoundedCornerShape(pcPalette.cardCornerDp.coerceAtLeast(16.dp)))
                                .clickable { viewModel.toggleStartMenu(focusSearch = true) }
                                .testTag("taskbar_search_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = "Search",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Search",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    } else {
                        TaskbarActionTile(
                            isActive = false,
                            isFocused = false,
                            onClick = { viewModel.toggleStartMenu(focusSearch = true) },
                            modifier = Modifier.testTag("taskbar_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(iconSize)
                            )
                        }
                    }
                }

                if (openWindows.none { it.type == WindowType.FILE_EXPLORER }) {
                    TaskbarActionTile(
                        isActive = false,
                        isFocused = false,
                        onClick = { viewModel.openWindow(WindowType.FILE_EXPLORER, "This PC") },
                        modifier = Modifier.testTag("taskbar_explorer_pin")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Folder,
                            contentDescription = "File Explorer",
                            tint = FolderAmber,
                            modifier = Modifier.size(iconSize)
                        )
                    }
                }

                taskbarPinned.forEach { pin ->
                    var showMenu by remember { mutableStateOf(false) }
                    Box {
                        TaskbarActionTile(
                            isActive = false,
                            isFocused = false,
                            onClick = {
                                viewModel.launchPackageShortcut(pin.packageName, pin.activityName, pin.label)
                            },
                            onLongClick = { showMenu = true },
                            modifier = Modifier.testTag("taskbar_pin_${pin.packageName}")
                        ) {
                            AppPackageIcon(
                                packageName = pin.packageName,
                                activityName = pin.activityName,
                                contentDescription = pin.label,
                                viewModel = viewModel,
                                size = iconSize
                            )
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Open ${pin.label}") },
                                onClick = {
                                    showMenu = false
                                    viewModel.launchPackageShortcut(pin.packageName, pin.activityName, pin.label)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Unpin from Taskbar") },
                                leadingIcon = { Icon(Icons.Rounded.PushPin, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    val app = installedApps.firstOrNull { it.componentKey == pin.componentKey }
                                        ?: InstalledApp(pin.packageName, pin.activityName, pin.label)
                                    viewModel.togglePinToTaskbar(app)
                                }
                            )
                        }
                    }
                }

                openWindows.forEach { win ->
                    var showWinMenu by remember { mutableStateOf(false) }
                    val isFocused = !win.isMinimized && win.id == activeWindowId
                    Box {
                        TaskbarActionTile(
                            isActive = true,
                            isFocused = isFocused,
                            onClick = { viewModel.toggleMinimizeFromTaskbar(win.id) },
                            onLongClick = { showWinMenu = true },
                            modifier = Modifier.testTag("taskbar_window_${win.type.name}")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = windowTypeIcon(win.type),
                                    contentDescription = win.title,
                                    tint = windowTypeTint(win.type, pcPalette.accent),
                                    modifier = Modifier.size(iconSize)
                                )
                                if (isWide) {
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = win.title,
                                        style = MaterialTheme.typography.labelMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.widthIn(max = 96.dp)
                                    )
                                }
                            }
                        }
                        DropdownMenu(expanded = showWinMenu, onDismissRequest = { showWinMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (win.isMinimized) "Restore" else "Minimize") },
                                onClick = {
                                    showWinMenu = false
                                    viewModel.toggleMinimizeFromTaskbar(win.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Close Window") },
                                leadingIcon = { Icon(Icons.Rounded.Close, contentDescription = null) },
                                onClick = {
                                    showWinMenu = false
                                    viewModel.closeWindow(win.id)
                                }
                            )
                        }
                    }
                }
            }

            // System Tray & Notification Area
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(pcPalette.cardCornerDp),
                    color = pcPalette.windowCard.copy(alpha = 0.72f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                        .clickable { viewModel.toggleLauncherMode() }
                        .testTag("taskbar_mode_switch")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PhoneAndroid,
                            contentDescription = "Switch to Normal Mobile Mode",
                            tint = pcPalette.accent,
                            modifier = Modifier.size(15.dp)
                        )
                        if (isWide) {
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "Mobile",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                        .clickable { viewModel.toggleQuickSettings() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("system_tray_button")
                ) {
                    Icon(
                        imageVector = when {
                            systemStatus.wifiConnected -> Icons.Rounded.Wifi
                            systemStatus.mobileConnected -> Icons.Rounded.SignalCellularAlt
                            else -> Icons.Rounded.WifiOff
                        },
                        contentDescription = "Network Status",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                    Icon(
                        imageVector = if (systemStatus.isMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = "Sound Volume",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when {
                                systemStatus.isCharging -> Icons.Rounded.BatteryChargingFull
                                systemStatus.batteryPercent >= 90 -> Icons.Rounded.BatteryFull
                                else -> Icons.Rounded.BatteryStd
                            },
                            contentDescription = "Battery ${systemStatus.batteryPercent}%",
                            tint = if (systemStatus.batteryPercent <= 15 && !systemStatus.isCharging) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        if (isWide) {
                            Spacer(Modifier.width(2.dp))
                            Text(
                                text = "${systemStatus.batteryPercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily
                            )
                        }
                    }
                }

                val dateObj = remember(systemStatus.currentTimeMillis) { Date(systemStatus.currentTimeMillis) }
                val timeStr = remember(systemStatus.currentTimeMillis) {
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(dateObj)
                }
                val dateStr = remember(systemStatus.currentTimeMillis) {
                    SimpleDateFormat("M/d/yy", Locale.getDefault()).format(dateObj)
                }
                var clockTapTimes by remember { mutableStateOf<List<Long>>(emptyList()) }

                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier
                        .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                        .clickable {
                            val now = System.currentTimeMillis()
                            val recent = (clockTapTimes + now).filter { now - it <= 1200L }
                            clockTapTimes = recent
                            if (settings.vaultAccessMethod == VaultAccessMethod.CLOCK_TRIPLE_TAP && recent.size >= 3) {
                                clockTapTimes = emptyList()
                                viewModel.triggerDiscreetVaultAccess()
                            } else {
                                viewModel.toggleCalendarFlyout()
                            }
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("taskbar_clock_button")
                ) {
                    Text(
                        text = timeStr,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = JetBrainsMonoFamily
                    )
                    if (settings.showTaskbarDate && settings.effectiveTaskbarThicknessDp() >= 44) {
                        Text(
                            text = dateStr,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = JetBrainsMonoFamily
                        )
                    }
                }

                NotificationTrayButton(
                    unreadCount = unreadNotificationCount,
                    showBadge = settings.showTaskbarNotificationBadge,
                    onClick = { viewModel.toggleNotificationCenter() }
                )
            }
        }
    }
}

@Composable
private fun NotificationTrayButton(
    unreadCount: Int,
    showBadge: Boolean,
    onClick: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(pcPalette.cardCornerDp))
            .clickable(onClick = onClick)
            .testTag("taskbar_notifications_button")
    ) {
        Icon(
            imageVector = if (unreadCount > 0) Icons.Rounded.Notifications else Icons.Rounded.NotificationsNone,
            contentDescription = "Notifications",
            modifier = Modifier.size(18.dp)
        )
        if (showBadge && unreadCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 6.dp, end = 6.dp)
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(pcPalette.accent)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TaskbarActionTile(
    isActive: Boolean,
    isFocused: Boolean,
    isVertical: Boolean = false,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .then(
                if (isVertical) Modifier.width(42.dp).height(42.dp)
                else Modifier.height(40.dp).widthIn(min = 42.dp)
            )
            .clip(RoundedCornerShape(pcPalette.cardCornerDp))
            .background(if (isFocused) pcPalette.hoverHighlight else Color.Transparent)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(horizontal = if (isVertical) 4.dp else 7.dp)
    ) {
        content()
        if (isActive) {
            Box(
                modifier = Modifier
                    .align(if (isVertical) Alignment.CenterStart else Alignment.BottomCenter)
                    .padding(
                        start = if (isVertical) 2.dp else 0.dp,
                        bottom = if (isVertical) 0.dp else 2.dp
                    )
                    .width(if (isVertical) 3.dp else if (isFocused) 18.dp else 8.dp)
                    .height(if (isVertical) (if (isFocused) 18.dp else 8.dp) else 3.dp)
                    .clip(CircleShape)
                    .background(
                        if (isFocused) pcPalette.accent
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
            )
        }
    }
}

@Composable
fun QuickSettingsFlyout(
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    Surface(
        shape = RoundedCornerShape(pcPalette.windowCornerDp),
        color = pcPalette.flyoutSurface,
        tonalElevation = 12.dp,
        shadowElevation = 16.dp,
        modifier = modifier
            .widthIn(min = 290.dp, max = 360.dp)
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.windowCornerDp))
            .testTag("quick_settings_flyout")
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Quick Settings", style = MaterialTheme.typography.titleMedium)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                QuickTileButton(
                    icon = if (systemStatus.wifiConnected) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                    label = if (systemStatus.wifiConnected) "Wi-Fi On" else "Wi-Fi",
                    active = systemStatus.wifiConnected || systemStatus.wifiEnabled,
                    onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_WIFI_SETTINGS) },
                    modifier = Modifier.weight(1f)
                )
                QuickTileButton(
                    icon = Icons.Rounded.Bluetooth,
                    label = if (systemStatus.bluetoothEnabled) "BT On" else "Bluetooth",
                    active = systemStatus.bluetoothEnabled,
                    onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_BLUETOOTH_SETTINGS) },
                    modifier = Modifier.weight(1f)
                )
                QuickTileButton(
                    icon = Icons.Rounded.BrightnessMedium,
                    label = "Display",
                    active = false,
                    onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_DISPLAY_SETTINGS) },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                QuickTileButton(
                    icon = if (settings.fullScreenImmersive) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                    label = if (settings.fullScreenImmersive) "Full Screen" else "Windowed",
                    active = settings.fullScreenImmersive,
                    onClick = { viewModel.setFullScreenImmersive(!settings.fullScreenImmersive) },
                    modifier = Modifier.weight(1f)
                )
                QuickTileButton(
                    icon = Icons.Rounded.ScreenRotation,
                    label = if (settings.orientationMode == OrientationMode.LANDSCAPE) "Landscape" else "Portrait",
                    active = settings.orientationMode == OrientationMode.LANDSCAPE,
                    onClick = { viewModel.toggleOrientationQuick() },
                    modifier = Modifier.weight(1f)
                )
                QuickTileButton(
                    icon = Icons.Rounded.PhoneAndroid,
                    label = "Mobile Mode",
                    active = false,
                    onClick = { viewModel.toggleLauncherMode() },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.toggleMute() }) {
                    Icon(
                        imageVector = if (systemStatus.isMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = "Mute Toggle"
                    )
                }
                Slider(
                    value = systemStatus.volumePercent / 100f,
                    onValueChange = { frac -> viewModel.setMediaVolumePercent((frac * 100).toInt()) },
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${systemStatus.volumePercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = JetBrainsMonoFamily,
                    modifier = Modifier.width(38.dp),
                    textAlign = TextAlign.End
                )
            }

            HorizontalDivider(color = pcPalette.windowBorder)

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (systemStatus.isCharging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryFull,
                        contentDescription = null,
                        tint = pcPalette.accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "${systemStatus.batteryPercent}%${if (systemStatus.isCharging) " Charging" else ""}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = { viewModel.lockDesktop() }) {
                        Icon(Icons.Rounded.Lock, contentDescription = "Lock PC")
                    }
                    IconButton(onClick = onRequestDefaultHome) {
                        Icon(Icons.Rounded.Home, contentDescription = "Default Home Launcher")
                    }
                    IconButton(onClick = { viewModel.openWindow(WindowType.PC_SETTINGS, "PC Settings") }) {
                        Icon(Icons.Rounded.Settings, contentDescription = "PC Settings")
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickTileButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    Surface(
        shape = RoundedCornerShape(pcPalette.cardCornerDp),
        color = if (active) pcPalette.accent else pcPalette.windowCard,
        modifier = modifier
            .height(58.dp)
            .clip(RoundedCornerShape(pcPalette.cardCornerDp))
            .clickable(onClick = onClick)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(19.dp)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun NotificationCenterFlyout(
    notifications: List<LauncherNotification>,
    onDismiss: (String) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    Surface(
        shape = RoundedCornerShape(pcPalette.windowCornerDp),
        color = pcPalette.flyoutSurface,
        tonalElevation = 12.dp,
        shadowElevation = 16.dp,
        modifier = modifier
            .widthIn(min = 290.dp, max = 360.dp)
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.windowCornerDp))
            .testTag("notification_center_flyout")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Notifications", style = MaterialTheme.typography.titleMedium)
                if (notifications.isNotEmpty()) {
                    TextButton(onClick = onClearAll) {
                        Text("Clear all")
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            if (notifications.isEmpty()) {
                Text(
                    text = "No new desktop notifications.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(230.dp)
                ) {
                    items(notifications, key = { it.id }) { notif ->
                        Surface(
                            shape = RoundedCornerShape(pcPalette.cardCornerDp),
                            color = pcPalette.windowCard,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
                        ) {
                            Row(
                                verticalAlignment = Alignment.Top,
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(notif.title, style = MaterialTheme.typography.titleSmall)
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = notif.message,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { onDismiss(notif.id) }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Dismiss", modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CalendarFlyout(
    currentTimeMillis: Long,
    onMonthHeaderLongPress: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    val cal = remember(currentTimeMillis) {
        Calendar.getInstance().apply { timeInMillis = currentTimeMillis }
    }
    val todayDay = cal.get(Calendar.DAY_OF_MONTH)
    val monthHeader = remember(currentTimeMillis) {
        SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date(currentTimeMillis))
    }
    val monthTitle = remember(currentTimeMillis) {
        SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(currentTimeMillis))
    }

    val firstDayCal = remember(currentTimeMillis) {
        (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
    }
    val offsetDays = firstDayCal.get(Calendar.DAY_OF_WEEK) - 1
    val daysInMonth = firstDayCal.getActualMaximum(Calendar.DAY_OF_MONTH)

    Surface(
        shape = RoundedCornerShape(pcPalette.windowCornerDp),
        color = pcPalette.flyoutSurface,
        tonalElevation = 12.dp,
        shadowElevation = 16.dp,
        modifier = modifier
            .widthIn(min = 280.dp, max = 330.dp)
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.windowCornerDp))
            .testTag("calendar_flyout")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = monthHeader,
                style = MaterialTheme.typography.titleSmall,
                color = pcPalette.accent,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = monthTitle,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .combinedClickable(
                        onClick = {},
                        onLongClick = onMonthHeaderLongPress
                    )
                    .padding(vertical = 2.dp)
                    .testTag("calendar_month_title")
            )
            Spacer(Modifier.height(10.dp))

            val weekdays = listOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa")
            Row(modifier = Modifier.fillMaxWidth()) {
                weekdays.forEach { d ->
                    Text(
                        text = d,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(Modifier.height(6.dp))

            val totalCells = offsetDays + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - offsetDays + 1
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .weight(1f)
                                .height(30.dp)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(
                                    if (dayNum == todayDay) pcPalette.accent else Color.Transparent
                                )
                        ) {
                            if (dayNum in 1..daysInMonth) {
                                Text(
                                    text = dayNum.toString(),
                                    fontSize = 12.sp,
                                    color = if (dayNum == todayDay) {
                                        MaterialTheme.colorScheme.onPrimary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    },
                                    fontWeight = if (dayNum == todayDay) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

fun windowTypeIcon(type: WindowType): ImageVector = when (type) {
    WindowType.FILE_EXPLORER -> Icons.Rounded.Folder
    WindowType.PC_SETTINGS -> Icons.Rounded.Settings
    WindowType.RECYCLE_BIN -> Icons.Rounded.DeleteOutline
    WindowType.DESKTOP_FOLDER -> Icons.Rounded.Folder
    WindowType.NOTEPAD -> Icons.Rounded.Description
    WindowType.TASK_MONITOR -> Icons.Rounded.MonitorHeart
    WindowType.GALLERY -> Icons.Rounded.PhotoLibrary
    WindowType.PRIVATE_VAULT -> Icons.Rounded.Lock
    WindowType.EXTERNAL_APP_HOST -> Icons.Rounded.WebAsset
}

fun windowTypeTint(type: WindowType, accent: Color): Color = when (type) {
    WindowType.FILE_EXPLORER, WindowType.DESKTOP_FOLDER -> FolderAmber
    WindowType.RECYCLE_BIN -> Color(0xFF38BDF8)
    WindowType.TASK_MONITOR -> Color(0xFF10B981)
    WindowType.PC_SETTINGS -> Color(0xFF94A3B8)
    WindowType.GALLERY -> Color(0xFFEC4899)
    WindowType.PRIVATE_VAULT -> Color(0xFFF59E0B)
    WindowType.NOTEPAD, WindowType.EXTERNAL_APP_HOST -> accent
}
