package com.example.ui.windows

import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AddToHomeScreen
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.DisplaySettings
import androidx.compose.material.icons.rounded.Dock
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.R
import com.example.data.model.AnimationEffectStyle
import com.example.data.model.AnimationSpeed
import com.example.data.model.CornerStyle
import com.example.data.model.DesktopThemePreset
import com.example.data.model.FontStyleOption
import com.example.data.model.IconPackStyle
import com.example.data.model.IconSizeOption
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherMode
import com.example.data.model.LauncherNotification
import com.example.data.model.OrientationMode
import com.example.data.model.PcSettingsState
import com.example.data.model.SavedThemeProfile
import com.example.data.model.ScreenLayoutDensity
import com.example.data.model.SystemStatus
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarSizeOption
import com.example.data.model.TaskbarStyle
import com.example.data.model.ThemeMode
import com.example.data.model.VaultAccessMethod
import com.example.data.model.WallpaperCategory
import com.example.data.model.WallpaperFitOption
import com.example.data.model.WallpaperPreset
import com.example.data.model.WindowAppearance
import com.example.data.model.WindowType
import com.example.ui.components.AppPackageIcon
import com.example.ui.components.PinSetupWizardDialog
import com.example.ui.components.TextInputDialog
import com.example.ui.components.WallpaperSurface
import com.example.ui.components.formatBytes
import com.example.ui.theme.AccentPreset
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.LauncherViewModel

private enum class SettingsTab(val label: String, val icon: ImageVector) {
    PERSONALIZATION("Personalization", Icons.Rounded.Palette),
    DISPLAY("Display", Icons.Rounded.DisplaySettings),
    DESKTOP("Desktop", Icons.Rounded.DesktopWindows),
    TASKBAR("Taskbar", Icons.Rounded.Dock),
    THEMES("Themes", Icons.Rounded.Style),
    ICONS("Icons", Icons.Rounded.GridView),
    WALLPAPER("Wallpaper", Icons.Rounded.Image),
    APPLICATIONS("Applications", Icons.Rounded.Apps),
    PERFORMANCE("Performance", Icons.Rounded.Speed),
    SOUND("Sound", Icons.AutoMirrored.Rounded.VolumeUp),
    NOTIFICATIONS("Notifications", Icons.Rounded.Notifications),
    SECURITY("Security & Privacy", Icons.Rounded.Lock),
    ABOUT("About Launcher", Icons.Rounded.Info)
}

private val customColorSwatches = listOf(
    0xFF0078D4L to "Azure",
    0xFF06B6D4L to "Cyan",
    0xFF8B5CF6L to "Violet",
    0xFF10B981L to "Emerald",
    0xFFF59E0BL to "Amber",
    0xFFEC4899L to "Rose",
    0xFFEF4444L to "Crimson",
    0xFF64748BL to "Slate"
)

private val desktopBgSwatches = listOf(
    0xFF0A192FL to "Midnight Navy",
    0xFF008080L to "Classic Teal",
    0xFF111827L to "Carbon Black",
    0xFF1E1B4BL to "Deep Indigo",
    0xFF064E3BL to "Forest Pine",
    0xFF31102FL to "Plum Dusk",
    0xFFD4D0C8L to "Classic Silver",
    0xFFE2E8F0L to "Soft Mist"
)

@Composable
fun PcSettingsWindow(
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    installedApps: List<InstalledApp>,
    savedThemes: List<SavedThemeProfile>,
    notifications: List<LauncherNotification>,
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    val hasPinConfigured by viewModel.hasPinConfigured.collectAsStateWithLifecycle()
    val latestBackupRecoveryKey by viewModel.latestBackupRecoveryKey.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(SettingsTab.PERSONALIZATION) }
    var appPickerSlot by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showSaveThemeDialog by remember { mutableStateOf(false) }
    var showPinSetupWizard by remember { mutableStateOf(false) }
    var appSearchQuery by remember { mutableStateOf("") }
    var wallpaperCategoryFilter by remember { mutableStateOf<WallpaperCategory?>(null) }
    var wallpaperTargetIsLock by remember { mutableStateOf(false) }
    var previewWallpaperPreset by remember { mutableStateOf<WallpaperPreset?>(null) }
    var secretPhraseDraft by remember(settings.vaultSecretPhrase) { mutableStateOf(settings.vaultSecretPhrase) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            if (wallpaperTargetIsLock) {
                viewModel.setCustomLockWallpaperUri(uri.toString())
                viewModel.showMessage("Custom lock screen wallpaper applied")
            } else {
                viewModel.setCustomWallpaperUri(uri.toString())
                viewModel.showMessage("Custom desktop wallpaper applied")
            }
        }
    }

    val exportThemeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) viewModel.exportThemeToUri(uri)
    }

    val importThemeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importThemeFromUri(uri)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val wideLayout = maxWidth >= 480.dp

        Column(modifier = Modifier.fillMaxSize()) {
            if (!wideLayout) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    SettingsTab.entries.forEach { tab ->
                        FilterChip(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            label = { Text(tab.label) },
                            leadingIcon = { Icon(tab.icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier.testTag("settings_tab_${tab.name}")
                        )
                    }
                }
                HorizontalDivider(color = pcPalette.windowBorder)
            }

            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (wideLayout) {
                    LazyColumn(
                        contentPadding = PaddingValues(8.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier
                            .width(186.dp)
                            .fillMaxHeight()
                            .background(pcPalette.windowHeader.copy(alpha = 0.35f))
                            .testTag("settings_sidebar_list")
                    ) {
                        items(SettingsTab.entries) { tab ->
                            val selected = activeTab == tab
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                                    .background(if (selected) pcPalette.accent.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { activeTab = tab }
                                    .padding(horizontal = 10.dp, vertical = 9.dp)
                                    .testTag("settings_tab_${tab.name}")
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.label,
                                    tint = if (selected) pcPalette.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(pcPalette.windowBorder))
                }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .testTag("settings_content_list")
                ) {
                    when (activeTab) {
                        SettingsTab.PERSONALIZATION -> {
                            item {
                                Text("Theme Mode", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    ThemeMode.entries.forEach { mode ->
                                        FilterChip(
                                            selected = settings.themeMode == mode,
                                            onClick = { viewModel.updateThemeMode(mode) },
                                            label = { Text(mode.label) },
                                            modifier = Modifier.testTag("theme_mode_${mode.name}")
                                        )
                                    }
                                }
                            }
                            item {
                                Text("Window Appearance & Corners", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    WindowAppearance.entries.forEach { app ->
                                        FilterChip(
                                            selected = settings.windowAppearance == app,
                                            onClick = { viewModel.setWindowAppearance(app) },
                                            label = { Text(app.label) }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    CornerStyle.entries.forEach { corner ->
                                        FilterChip(
                                            selected = settings.cornerStyle == corner,
                                            onClick = { viewModel.setCornerStyle(corner) },
                                            label = { Text(corner.label) }
                                        )
                                    }
                                }
                            }
                            item {
                                Text("Font Style", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    FontStyleOption.entries.forEach { font ->
                                        FilterChip(
                                            selected = settings.fontStyle == font,
                                            onClick = { viewModel.setFontStyle(font) },
                                            label = { Text(font.label) }
                                        )
                                    }
                                }
                            }
                            item {
                                Text("Accent Color", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    AccentPreset.entries.forEach { preset ->
                                        val selected = settings.customAccentArgb == null && settings.accentKey == preset.key
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(if (pcPalette.isDark) preset.dark else preset.light)
                                                .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                                                .clickable { viewModel.updateAccentKey(preset.key) }
                                        )
                                    }
                                    customColorSwatches.forEach { (argb, _) ->
                                        val selected = settings.customAccentArgb == argb
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(Color(argb.toInt()))
                                                .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                                                .clickable { viewModel.setCustomAccentColor(argb) }
                                        )
                                    }
                                }
                            }
                        }

                        SettingsTab.DISPLAY -> {
                            item {
                                Text("Full-Screen & Orientation", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Immersive Full-Screen Mode",
                                        subtitle = "Hide Android status and navigation bars so the desktop fills the entire display.",
                                        checked = settings.fullScreenImmersive,
                                        onCheckedChange = { viewModel.setFullScreenImmersive(it) },
                                        testTag = "toggle_fullscreen"
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    Text("Screen Orientation", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Spacer(Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                        OrientationMode.entries.forEach { mode ->
                                            FilterChip(
                                                selected = settings.orientationMode == mode,
                                                onClick = { viewModel.setOrientationMode(mode) },
                                                label = { Text(mode.label) },
                                                modifier = Modifier.testTag("orientation_${mode.name}")
                                            )
                                        }
                                    }
                                }
                            }
                            item {
                                Text("Desktop Scaling & UI Size", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                SettingsCard {
                                    Text("UI Scale: ${(settings.desktopScale * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
                                    Slider(
                                        value = settings.desktopScale,
                                        onValueChange = { viewModel.setDesktopScale(it) },
                                        valueRange = 0.80f..1.25f
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text("Screen Layout Preset", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                        ScreenLayoutDensity.entries.forEach { layout ->
                                            FilterChip(
                                                selected = settings.screenLayout == layout,
                                                onClick = { viewModel.setScreenLayout(layout) },
                                                label = { Text(layout.label) }
                                            )
                                        }
                                    }
                                }
                            }
                            item {
                                OutlinedButton(onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_DISPLAY_SETTINGS) }) {
                                    Text("Open Android Hardware Display Settings")
                                }
                            }
                        }

                        SettingsTab.DESKTOP -> {
                            item {
                                Text("Dual App Opening Mode", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                SettingsCard {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                        LauncherMode.entries.forEach { mode ->
                                            FilterChip(
                                                selected = settings.launcherMode == mode,
                                                onClick = { viewModel.setLauncherMode(mode) },
                                                label = { Text(mode.label) },
                                                leadingIcon = {
                                                    Icon(
                                                        imageVector = if (mode == LauncherMode.DESKTOP) Icons.Rounded.DesktopWindows else Icons.Rounded.PhoneAndroid,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                },
                                                modifier = Modifier.testTag("settings_launcher_mode_${mode.name}")
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    ToggleSettingRow(
                                        title = "Auto-Launch Windowed Apps",
                                        subtitle = "Also start Android app activity immediately after opening its Desktop Host Window.",
                                        checked = settings.autoLaunchAppInDesktopMode,
                                        onCheckedChange = { viewModel.setAutoLaunchAppInDesktopMode(it) }
                                    )
                                }
                            }
                            item {
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Auto-Arrange Desktop Grid",
                                        subtitle = "Automatically align desktop icons into neat columns.",
                                        checked = settings.autoArrangeGrid,
                                        onCheckedChange = { viewModel.setAutoArrangeGrid(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Desktop Clock Widget",
                                        subtitle = "Display live clock and date widget on desktop.",
                                        checked = settings.showDesktopClock,
                                        onCheckedChange = { viewModel.setShowDesktopClock(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Show File Extensions",
                                        subtitle = "Show .txt and .md file suffixes on desktop icons.",
                                        checked = settings.showFileExtensions,
                                        onCheckedChange = { viewModel.setShowFileExtensions(it) }
                                    )
                                }
                            }
                            item {
                                Text("Desktop Background Color", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    desktopBgSwatches.forEach { (argb, label) ->
                                        val selected = settings.desktopBackgroundArgb == argb
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color(argb.toInt()))
                                                    .border(
                                                        width = if (selected) 2.5.dp else 1.dp,
                                                        color = if (selected) pcPalette.accent else pcPalette.windowBorder,
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable {
                                                        viewModel.setDesktopBackgroundColor(argb)
                                                        viewModel.updateWallpaperPreset(WallpaperPreset.SOLID_COLOR.id)
                                                    }
                                            )
                                            Text(label, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                            item {
                                OutlinedButton(onClick = { viewModel.resetDefaultDesktopIcons() }) {
                                    Text("Restore Default Desktop Shortcuts")
                                }
                            }
                        }

                        SettingsTab.TASKBAR -> {
                            item {
                                Text("Taskbar Position", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    TaskbarPosition.entries.forEach { pos ->
                                        FilterChip(
                                            selected = settings.taskbarPosition == pos,
                                            onClick = { viewModel.updateTaskbarPosition(pos) },
                                            label = { Text(pos.label) },
                                            modifier = Modifier.testTag("taskbar_pos_${pos.name}")
                                        )
                                    }
                                }
                            }
                            item {
                                Text("Taskbar Visual Style", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    TaskbarStyle.entries.forEach { st ->
                                        FilterChip(
                                            selected = settings.taskbarStyle == st,
                                            onClick = { viewModel.setTaskbarStyle(st) },
                                            label = { Text(st.label) }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("Custom Taskbar Color", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    FilterChip(
                                        selected = settings.customTaskbarArgb == null,
                                        onClick = { viewModel.setCustomTaskbarColor(null) },
                                        label = { Text("Theme Default") }
                                    )
                                    customColorSwatches.forEach { (argb, _) ->
                                        val selected = settings.customTaskbarArgb == argb
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(Color(argb.toInt()))
                                                .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                                                .clickable { viewModel.setCustomTaskbarColor(argb) }
                                        )
                                    }
                                }
                            }
                            item {
                                SettingsCard {
                                    Text("Taskbar Height / Thickness (${settings.effectiveTaskbarThicknessDp()} dp)", style = MaterialTheme.typography.bodyMedium)
                                    Slider(
                                        value = settings.effectiveTaskbarThicknessDp().toFloat(),
                                        onValueChange = { viewModel.setTaskbarHeightOverride(it.toInt()) },
                                        valueRange = 36f..76f
                                    )
                                    Text("Icon Spacing (${settings.taskbarIconSpacingDp} dp)", style = MaterialTheme.typography.bodyMedium)
                                    Slider(
                                        value = settings.taskbarIconSpacingDp.toFloat(),
                                        onValueChange = { viewModel.setTaskbarIconSpacing(it.toInt()) },
                                        valueRange = 0f..16f
                                    )
                                    Text("Taskbar Transparency (${(settings.taskbarTransparency * 100).toInt()}%)", style = MaterialTheme.typography.bodyMedium)
                                    Slider(
                                        value = settings.taskbarTransparency,
                                        onValueChange = { viewModel.updateTaskbarTransparency(it) },
                                        valueRange = 0.25f..1.0f
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow("Show Search Button", "Include search shortcut in taskbar.", settings.showTaskbarSearch) { viewModel.setShowTaskbarSearch(it) }
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow("Show Date under Clock", "Display date alongside clock.", settings.showTaskbarDate) { viewModel.setShowTaskbarDate(it) }
                                }
                            }
                        }

                        SettingsTab.THEMES -> {
                            item {
                                Text("Desktop Theme Presets", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DesktopThemePreset.entries.forEach { preset ->
                                        val selected = settings.themePreset == preset
                                        Surface(
                                            shape = RoundedCornerShape(pcPalette.cardCornerDp),
                                            color = if (selected) pcPalette.accent.copy(alpha = 0.16f) else pcPalette.windowCard,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .border(
                                                    width = if (selected) 1.5.dp else 1.dp,
                                                    color = if (selected) pcPalette.accent else pcPalette.windowBorder,
                                                    shape = RoundedCornerShape(pcPalette.cardCornerDp)
                                                )
                                                .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                                                .clickable { viewModel.applyThemePreset(preset) }
                                                .testTag("preset_${preset.name}")
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(12.dp)) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(preset.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                                    Text(preset.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                if (selected) {
                                                    Icon(Icons.Rounded.CheckCircle, contentDescription = "Active", tint = pcPalette.accent)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Text("Custom User Themes & Backup", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    Button(onClick = { showSaveThemeDialog = true }) {
                                        Icon(Icons.Rounded.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Save Current Theme")
                                    }
                                    OutlinedButton(onClick = { exportThemeLauncher.launch("pc_desktop_theme.pcdtheme.json") }) {
                                        Icon(Icons.Rounded.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Export JSON")
                                    }
                                    OutlinedButton(onClick = { importThemeLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Import JSON")
                                    }
                                    OutlinedButton(onClick = { viewModel.resetAllSettingsToDefaults() }) {
                                        Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Reset Defaults")
                                    }
                                }
                            }
                            if (savedThemes.isNotEmpty()) {
                                item {
                                    Text("Saved Profiles (${savedThemes.size})", style = MaterialTheme.typography.titleSmall)
                                }
                                items(savedThemes, key = { it.id }) { profile ->
                                    SettingsCard {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(profile.name, style = MaterialTheme.typography.titleSmall)
                                                Text("Saved custom desktop style", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            TextButton(onClick = { viewModel.applySavedTheme(profile) }) { Text("Apply") }
                                            IconButton(onClick = { viewModel.deleteSavedTheme(profile.id) }) {
                                                Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        SettingsTab.ICONS -> {
                            item {
                                Text("Icon Pack Style", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    IconPackStyle.entries.forEach { pack ->
                                        FilterChip(
                                            selected = settings.iconPack == pack,
                                            onClick = { viewModel.setIconPack(pack) },
                                            label = { Text(pack.label) }
                                        )
                                    }
                                }
                            }
                            item {
                                Text("Desktop Icon Size", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconSizeOption.entries.forEach { opt ->
                                        FilterChip(
                                            selected = settings.iconSize == opt,
                                            onClick = { viewModel.updateIconSize(opt) },
                                            label = { Text(opt.label) }
                                        )
                                    }
                                }
                            }
                            item {
                                SettingsCard {
                                    Text("Icon Scaling (${(settings.iconScale * 100).toInt()}%)", style = MaterialTheme.typography.bodyMedium)
                                    Slider(
                                        value = settings.iconScale,
                                        onValueChange = { viewModel.setIconScale(it) },
                                        valueRange = 0.75f..1.35f
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Icon Label Background Pill",
                                        subtitle = "Add readable contrast scrim behind desktop icon titles.",
                                        checked = settings.showDesktopIconScrim,
                                        onCheckedChange = { viewModel.setShowDesktopIconScrim(it) }
                                    )
                                }
                            }
                        }

                        SettingsTab.WALLPAPER -> {
                            item {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Wallpaper Gallery (${WallpaperPreset.entries.size})", style = MaterialTheme.typography.titleMedium)
                                    OutlinedButton(onClick = {
                                        photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    }) {
                                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(if (wallpaperTargetIsLock) "Pick Lock Photo" else "Pick Desktop Photo")
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(
                                        selected = !wallpaperTargetIsLock,
                                        onClick = { wallpaperTargetIsLock = false },
                                        label = { Text("Desktop Target") },
                                        leadingIcon = { Icon(Icons.Rounded.DesktopWindows, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                        modifier = Modifier.testTag("wallpaper_target_desktop")
                                    )
                                    FilterChip(
                                        selected = wallpaperTargetIsLock,
                                        onClick = { wallpaperTargetIsLock = true },
                                        label = { Text("Lock Screen Target") },
                                        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                        modifier = Modifier.testTag("wallpaper_target_lock")
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    FilterChip(
                                        selected = wallpaperCategoryFilter == null,
                                        onClick = { wallpaperCategoryFilter = null },
                                        label = { Text("All (${WallpaperPreset.entries.size})") }
                                    )
                                    WallpaperCategory.entries.forEach { cat ->
                                        FilterChip(
                                            selected = wallpaperCategoryFilter == cat,
                                            onClick = { wallpaperCategoryFilter = cat },
                                            label = { Text(cat.label) }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                val shownPresets = remember(wallpaperCategoryFilter) {
                                    if (wallpaperCategoryFilter == null) WallpaperPreset.entries
                                    else WallpaperPreset.entries.filter { it.category == wallpaperCategoryFilter }
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    shownPresets.chunked(2).forEach { pair ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                            pair.forEach { preset ->
                                                val selected = if (wallpaperTargetIsLock) {
                                                    settings.customLockWallpaperUri == null && settings.lockWallpaperId == preset.id
                                                } else {
                                                    settings.customWallpaperUri == null && settings.wallpaperId == preset.id
                                                }
                                                WallpaperTile(
                                                    preset = preset,
                                                    selected = selected,
                                                    bgColorArgb = settings.desktopBackgroundArgb,
                                                    onClick = { previewWallpaperPreset = preset },
                                                    modifier = Modifier.weight(1f).testTag("wallpaper_tile_${preset.id}")
                                                )
                                            }
                                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                            item {
                                Text("Wallpaper Fit & Dimming", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    WallpaperFitOption.entries.forEach { fit ->
                                        FilterChip(
                                            selected = settings.wallpaperFit == fit,
                                            onClick = { viewModel.setWallpaperFit(fit) },
                                            label = { Text(fit.label) }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                SettingsCard {
                                    Text("Wallpaper Dimming (${(settings.wallpaperDimAlpha * 100).toInt()}%)", style = MaterialTheme.typography.bodyMedium)
                                    Slider(
                                        value = settings.wallpaperDimAlpha,
                                        onValueChange = { viewModel.setWallpaperDimAlpha(it) },
                                        valueRange = 0f..0.7f
                                    )
                                }
                            }
                        }

                        SettingsTab.APPLICATIONS -> {
                            item {
                                Text("Default App Shortcuts", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                val slots = listOf(
                                    Triple("browser", "Web Browser", settings.defaultBrowserPackage),
                                    Triple("files", "External Files App", settings.defaultFilesPackage),
                                    Triple("gallery", "Photos / Gallery", settings.defaultGalleryPackage),
                                    Triple("music", "Music Player", settings.defaultMusicPackage)
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    slots.forEach { (slotKey, slotTitle, currentPkg) ->
                                        val matched = installedApps.firstOrNull { it.packageName == currentPkg }
                                        SettingsCard {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                if (matched != null) {
                                                    AppPackageIcon(matched.packageName, matched.activityName, matched.label, viewModel, size = 28.dp)
                                                    Spacer(Modifier.width(10.dp))
                                                }
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(slotTitle, style = MaterialTheme.typography.titleSmall)
                                                    Text(matched?.label ?: "Not assigned", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                OutlinedButton(onClick = { appPickerSlot = slotKey to slotTitle }) { Text("Choose") }
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Request Freeform Window Bounds",
                                        subtitle = if (systemStatus.supportsFreeformWindows) "Device supports Android freeform multi-window." else "Standard Android launch on this device.",
                                        checked = settings.preferFreeformLaunch,
                                        onCheckedChange = { viewModel.setPreferFreeformLaunch(it) }
                                    )
                                }
                            }
                            item {
                                Text("Installed Android Apps (${installedApps.size})", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = appSearchQuery,
                                    onValueChange = { appSearchQuery = it },
                                    placeholder = { Text("Filter installed apps") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            val filteredInstalled = installedApps.filter {
                                appSearchQuery.isBlank() || it.label.contains(appSearchQuery, ignoreCase = true)
                            }
                            items(filteredInstalled, key = { it.componentKey }) { app ->
                                SettingsCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        AppPackageIcon(app.packageName, app.activityName, app.label, viewModel, size = 32.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(app.label, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        IconButton(onClick = { viewModel.addAppToDesktop(app) }) {
                                            Icon(Icons.Rounded.AddToHomeScreen, contentDescription = "Add to Desktop")
                                        }
                                        IconButton(onClick = { viewModel.togglePinToTaskbar(app) }) {
                                            Icon(Icons.Rounded.PushPin, contentDescription = "Pin to Taskbar")
                                        }
                                        IconButton(onClick = { viewModel.hideApp(app) }) {
                                            Icon(Icons.Rounded.VisibilityOff, contentDescription = "Hide App")
                                        }
                                        IconButton(onClick = { viewModel.openAppInfo(app.packageName) }) {
                                            Icon(Icons.Rounded.Info, contentDescription = "App Info")
                                        }
                                    }
                                }
                            }
                        }

                        SettingsTab.PERFORMANCE -> {
                            item {
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Enable UI Animations",
                                        subtitle = "Smooth transitions for Start Menu, Flyouts, and Desktop.",
                                        checked = settings.animationsEnabled,
                                        onCheckedChange = { viewModel.setAnimationsEnabled(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Battery Saver Desktop Mode",
                                        subtitle = "Reduces transparency layers and disables animations to save battery.",
                                        checked = settings.batterySaverMode,
                                        onCheckedChange = { viewModel.setBatterySaverMode(it) }
                                    )
                                }
                            }
                            item {
                                Text("Animation Speed & Effect", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    AnimationSpeed.entries.forEach { spd ->
                                        FilterChip(
                                            selected = settings.animationSpeed == spd,
                                            onClick = { viewModel.updateAnimationSpeed(spd) },
                                            label = { Text(spd.label) },
                                            enabled = settings.animationsEnabled
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                    AnimationEffectStyle.entries.forEach { eff ->
                                        FilterChip(
                                            selected = settings.animationEffect == eff,
                                            onClick = { viewModel.setAnimationEffect(eff) },
                                            label = { Text(eff.label) },
                                            enabled = settings.animationsEnabled
                                        )
                                    }
                                }
                            }
                            item {
                                val ramFrac = if (systemStatus.ramTotalBytes > 0) (systemStatus.ramUsedBytes.toFloat() / systemStatus.ramTotalBytes.toFloat()).coerceIn(0f, 1f) else 0f
                                SettingsCard {
                                    Text("System Memory (RAM)", style = MaterialTheme.typography.titleSmall)
                                    Spacer(Modifier.height(6.dp))
                                    LinearProgressIndicator(progress = { ramFrac }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(4.dp))
                                    Text("${formatBytes(systemStatus.ramUsedBytes)} / ${formatBytes(systemStatus.ramTotalBytes)}", style = MaterialTheme.typography.labelSmall, fontFamily = JetBrainsMonoFamily)
                                    Spacer(Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { viewModel.clearIconCache() }) { Text("Clear Icon Cache") }
                                        Button(onClick = { viewModel.openWindow(WindowType.TASK_MONITOR, "Task Manager") }) { Text("Open Task Manager") }
                                    }
                                }
                            }
                        }

                        SettingsTab.SOUND -> {
                            item {
                                SettingsCard {
                                    Text("Media Volume (${systemStatus.volumePercent}%)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Slider(
                                        value = systemStatus.volumePercent / 100f,
                                        onValueChange = { viewModel.setMediaVolumePercent((it * 100).toInt()) }
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text("Notification Volume (${systemStatus.ringVolumePercent}%)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Slider(
                                        value = systemStatus.ringVolumePercent / 100f,
                                        onValueChange = { viewModel.setRingVolumePercent((it * 100).toInt()) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Desktop Haptic Feedback",
                                        subtitle = "Tactile vibration when dragging icons or opening context menus.",
                                        checked = settings.hapticFeedbackEnabled,
                                        onCheckedChange = { viewModel.setHapticFeedbackEnabled(it) }
                                    )
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { viewModel.toggleMute() }) {
                                        Text(if (systemStatus.isMuted) "Unmute Media" else "Mute Media")
                                    }
                                    OutlinedButton(onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_SOUND_SETTINGS) }) {
                                        Text("Android Sound Settings")
                                    }
                                }
                            }
                        }

                        SettingsTab.NOTIFICATIONS -> {
                            item {
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Taskbar Notification Indicator",
                                        subtitle = "Show unread notification badge on the taskbar tray.",
                                        checked = settings.showTaskbarNotificationBadge,
                                        onCheckedChange = { viewModel.setShowTaskbarNotificationBadge(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Desktop Status Toasts",
                                        subtitle = "Show subtle pill notifications for launcher actions.",
                                        checked = settings.showToastNotifications,
                                        onCheckedChange = { viewModel.setShowToastNotifications(it) }
                                    )
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { viewModel.toggleNotificationCenter() }) {
                                        Text("Open Notification Center (${notifications.size})")
                                    }
                                    OutlinedButton(onClick = { viewModel.clearAllNotifications() }) {
                                        Text("Clear All")
                                    }
                                }
                            }
                        }

                        SettingsTab.SECURITY -> {
                            item {
                                Text("Launcher PIN & Owner Recovery", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                SettingsCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.Shield,
                                            contentDescription = null,
                                            tint = if (hasPinConfigured) SuccessGreen else pcPalette.accent,
                                            modifier = Modifier.size(26.dp)
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (hasPinConfigured) "PIN / Password Protection Active" else "No PIN Configured Yet",
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text(
                                                text = "Stored locally via AndroidKeyStore + salted PBKDF2-HMAC-SHA256.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                        Button(
                                            onClick = { showPinSetupWizard = true },
                                            modifier = Modifier.testTag("security_setup_pin_button")
                                        ) {
                                            Icon(Icons.Rounded.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(if (hasPinConfigured) "Change PIN & Recovery" else "Set PIN & Recovery")
                                        }
                                        OutlinedButton(
                                            onClick = { viewModel.lockDesktop() },
                                            modifier = Modifier.testTag("security_lock_now_button")
                                        ) {
                                            Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Lock Desktop Now")
                                        }
                                        if (hasPinConfigured) {
                                            OutlinedButton(onClick = { viewModel.clearSecurityPin() }) {
                                                Text("Remove PIN")
                                            }
                                        }
                                    }
                                    if (!latestBackupRecoveryKey.isNullOrBlank()) {
                                        Spacer(Modifier.height(10.dp))
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = pcPalette.accent.copy(alpha = 0.14f),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(10.dp)) {
                                                Text(
                                                    text = "Latest Backup Key: $latestBackupRecoveryKey",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontFamily = JetBrainsMonoFamily,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                TextButton(onClick = { viewModel.dismissRecoveryKeyBanner() }) { Text("Hide") }
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Text("Desktop Lock Screen", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Enable Launcher Lock Screen on Launch",
                                        subtitle = "Show the desktop lock screen cover when launching PC Desktop Launcher.",
                                        checked = settings.lockScreenEnabled,
                                        onCheckedChange = { viewModel.setLockScreenEnabled(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Show Seconds on Lock Clock",
                                        subtitle = "Display HH:mm:ss format on the lock screen.",
                                        checked = settings.lockScreenShowClockSeconds,
                                        onCheckedChange = { viewModel.setLockScreenShowClockSeconds(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Fingerprint / Biometric Unlock",
                                        subtitle = if (viewModel.canUseBiometrics()) "Biometric hardware available." else "No biometric hardware enrolled on device.",
                                        checked = settings.lockScreenBiometricEnabled,
                                        onCheckedChange = { viewModel.setLockScreenBiometricEnabled(it) }
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(onClick = {
                                        wallpaperTargetIsLock = true
                                        activeTab = SettingsTab.WALLPAPER
                                    }) {
                                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Customize Lock Screen Wallpaper")
                                    }
                                }
                            }
                            item {
                                Text("Discreet Private Vault Access", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                SettingsCard {
                                    Text(
                                        text = "Hidden apps and private gallery access remain invisible from regular buttons. Choose your discreet entry trigger:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        VaultAccessMethod.entries.forEach { method ->
                                            val selected = settings.vaultAccessMethod == method
                                            Surface(
                                                shape = RoundedCornerShape(pcPalette.cardCornerDp),
                                                color = if (selected) pcPalette.accent.copy(alpha = 0.14f) else Color.Transparent,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .border(
                                                        width = if (selected) 1.5.dp else 1.dp,
                                                        color = if (selected) pcPalette.accent else pcPalette.windowBorder,
                                                        shape = RoundedCornerShape(pcPalette.cardCornerDp)
                                                    )
                                                    .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                                                    .clickable { viewModel.setVaultAccessMethod(method) }
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp)) {
                                                    Text(method.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                                    Text(method.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                        }
                                    }
                                    if (settings.vaultAccessMethod == VaultAccessMethod.START_SECRET_PHRASE) {
                                        Spacer(Modifier.height(10.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedTextField(
                                                value = secretPhraseDraft,
                                                onValueChange = { secretPhraseDraft = it },
                                                label = { Text("Secret Command") },
                                                singleLine = true,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Button(onClick = { viewModel.setVaultSecretPhrase(secretPhraseDraft) }) {
                                                Text("Save")
                                            }
                                        }
                                    }
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Biometric Unlock for Private Vault",
                                        subtitle = "Allow Android BiometricPrompt alongside your PIN.",
                                        checked = settings.vaultBiometricEnabled,
                                        onCheckedChange = { viewModel.setVaultBiometricEnabled(it) }
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = { viewModel.triggerDiscreetVaultAccess() },
                                        modifier = Modifier.testTag("settings_open_vault_button")
                                    ) {
                                        Icon(Icons.Rounded.Fingerprint, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Authenticate & Open Private Vault")
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = "Note: Hiding apps removes them from PC Desktop Launcher's drawer, desktop, and searches without uninstalling or deleting app data. Android Settings > Apps and other launchers still show installed packages.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        SettingsTab.ABOUT -> {
                            item {
                                SettingsCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (systemStatus.isDefaultLauncher) Icons.Rounded.CheckCircle else Icons.Rounded.Home,
                                            contentDescription = null,
                                            tint = if (systemStatus.isDefaultLauncher) SuccessGreen else pcPalette.accent,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Spacer(Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (systemStatus.isDefaultLauncher) "Default Android Home Launcher Active" else "Not Default Home Launcher",
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text("Registered with CATEGORY_HOME & CATEGORY_DEFAULT.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Button(
                                        onClick = onRequestDefaultHome,
                                        modifier = Modifier.testTag("settings_set_default_home")
                                    ) {
                                        Text(if (systemStatus.isDefaultLauncher) "Change Default Home App" else "Set as Default Home Launcher")
                                    }
                                }
                            }
                            item {
                                SettingsCard {
                                    SpecRow("Application", "PC Desktop Launcher")
                                    SpecRow("Version", "${BuildConfig.VERSION_NAME} (Code ${BuildConfig.VERSION_CODE})")
                                    SpecRow("Package ID", BuildConfig.APPLICATION_ID)
                                    SpecRow("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
                                    SpecRow("Android OS", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                                    SpecRow("Total RAM", formatBytes(systemStatus.ramTotalBytes))
                                    SpecRow("Internal Storage", formatBytes(systemStatus.storageTotalBytes))
                                    SpecRow("Freeform Support", if (systemStatus.supportsFreeformWindows) "Advertised" else "Standard Activity")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSaveThemeDialog) {
        TextInputDialog(
            title = "Save Custom Desktop Theme",
            label = "Theme name",
            initialValue = "My Custom PC",
            confirmLabel = "Save",
            onDismiss = { showSaveThemeDialog = false },
            onConfirm = { name ->
                showSaveThemeDialog = false
                viewModel.saveCurrentAsCustomTheme(name)
            }
        )
    }

    appPickerSlot?.let { (slotKey, slotTitle) ->
        AlertDialog(
            onDismissRequest = { appPickerSlot = null },
            title = { Text("Choose $slotTitle") },
            text = {
                LazyColumn(modifier = Modifier.height(280.dp)) {
                    item {
                        TextButton(onClick = { viewModel.setDefaultShortcut(slotKey, null); appPickerSlot = null }) {
                            Text("Clear Assignment")
                        }
                    }
                    items(installedApps, key = { it.componentKey }) { app ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.setDefaultShortcut(slotKey, app.packageName)
                                    appPickerSlot = null
                                }
                                .padding(vertical = 8.dp, horizontal = 6.dp)
                        ) {
                            AppPackageIcon(app.packageName, app.activityName, app.label, viewModel, size = 28.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(app.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { appPickerSlot = null }) { Text("Close") }
            }
        )
    }

    if (showPinSetupWizard) {
        PinSetupWizardDialog(
            viewModel = viewModel,
            onDismiss = { showPinSetupWizard = false }
        )
    }

    previewWallpaperPreset?.let { preset ->
        AlertDialog(
            onDismissRequest = { previewWallpaperPreset = null },
            title = { Text("${preset.title} (${preset.category.label})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
                    ) {
                        WallpaperSurface(
                            wallpaperId = preset.id,
                            customUri = null,
                            backgroundArgb = settings.desktopBackgroundArgb,
                            fitOption = settings.wallpaperFit,
                            dimAlpha = settings.wallpaperDimAlpha
                        )
                    }
                    Text(
                        text = "Live preview with your active fit (${settings.wallpaperFit.label}) & dimming (${(settings.wallpaperDimAlpha * 100).toInt()}%).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            viewModel.updateWallpaperPreset(preset.id)
                            viewModel.showMessage("Desktop wallpaper updated")
                            previewWallpaperPreset = null
                        },
                        modifier = Modifier.testTag("wallpaper_apply_desktop")
                    ) {
                        Text("Desktop")
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.updateLockWallpaperPreset(preset.id)
                            viewModel.showMessage("Lock screen wallpaper updated")
                            previewWallpaperPreset = null
                        },
                        modifier = Modifier.testTag("wallpaper_apply_lock")
                    ) {
                        Text("Lock")
                    }
                    Button(
                        onClick = {
                            viewModel.updateWallpaperPreset(preset.id)
                            viewModel.updateLockWallpaperPreset(preset.id)
                            viewModel.showMessage("Applied to Desktop & Lock Screen")
                            previewWallpaperPreset = null
                        },
                        modifier = Modifier.testTag("wallpaper_apply_both")
                    ) {
                        Text("Both")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { previewWallpaperPreset = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    val pcPalette = LocalPcPalette.current
    Surface(
        shape = RoundedCornerShape(pcPalette.cardCornerDp),
        color = pcPalette.windowCard,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            content()
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontFamily = JetBrainsMonoFamily)
    }
}

@Composable
private fun ToggleSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    testTag: String? = null,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier
        )
    }
}

@Composable
private fun WallpaperTile(
    preset: WallpaperPreset,
    selected: Boolean,
    bgColorArgb: Long,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(pcPalette.cardCornerDp))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) pcPalette.accent else pcPalette.windowBorder,
                shape = RoundedCornerShape(pcPalette.cardCornerDp)
            )
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(72.dp)) {
            WallpaperSurface(
                wallpaperId = preset.id,
                customUri = null,
                backgroundArgb = bgColorArgb
            )
        }
        Column(modifier = Modifier.padding(8.dp)) {
            Text(
                text = preset.title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = preset.category.label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
