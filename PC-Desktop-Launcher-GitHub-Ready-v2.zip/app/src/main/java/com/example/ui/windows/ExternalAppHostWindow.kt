package com.example.ui.windows

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DesktopWindow
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherMode
import com.example.data.model.PcSettingsState
import com.example.data.model.SystemStatus
import com.example.ui.components.AppPackageIcon
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel

@Composable
fun ExternalAppHostWindow(
    window: DesktopWindow,
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    installedApps: List<InstalledApp>,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current
    val pkg = window.appPackage.orEmpty()
    val act = window.appActivity.orEmpty()
    val matchedApp = remember(installedApps, pkg, act) {
        installedApps.firstOrNull { it.packageName == pkg && (act.isEmpty() || it.activityName == act) }
            ?: installedApps.firstOrNull { it.packageName == pkg }
    }

    Column(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(18.dp)
            .testTag("external_app_host_window")
    ) {
        Surface(
            shape = RoundedCornerShape(pcPalette.cardCornerDp),
            color = pcPalette.windowCard,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(16.dp)
            ) {
                AppPackageIcon(
                    packageName = pkg,
                    activityName = act,
                    contentDescription = window.title,
                    viewModel = viewModel,
                    size = 56.dp
                )
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = window.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = pkg,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFamily,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = if (systemStatus.supportsFreeformWindows) {
                            "Freeform Desktop Windowing supported by this Android device"
                        } else {
                            "Managed Desktop App Task Window (Standard Android Activity)"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = pcPalette.accent
                    )
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    viewModel.launchAppDirectly(
                        packageName = pkg,
                        activityName = act,
                        label = window.title,
                        preferFreeform = settings.preferFreeformLaunch
                    )
                },
                modifier = Modifier.weight(1f).testTag("external_app_launch_button")
            ) {
                Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (systemStatus.supportsFreeformWindows) "Open Freeform Window" else "Open App")
            }

            OutlinedButton(
                onClick = {
                    viewModel.launchAppDirectly(
                        packageName = pkg,
                        activityName = act,
                        label = window.title,
                        preferFreeform = false
                    )
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Rounded.Fullscreen, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Full-Screen App")
            }
        }

        Surface(
            shape = RoundedCornerShape(pcPalette.cardCornerDp),
            color = pcPalette.windowHeader.copy(alpha = 0.45f),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.DesktopWindows, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Android Desktop Windowing Note", style = MaterialTheme.typography.titleSmall)
                }
                Text(
                    text = if (systemStatus.supportsFreeformWindows) {
                        "Your device advertises Android freeform multi-window support. Launching from here requests floating desktop bounds via Android ActivityOptions, while keeping this task pinned in your PC taskbar for quick switching."
                    } else {
                        "Android security isolates third-party app activities from embedding directly inside a launcher view. On devices without OEM freeform mode enabled, opening the app launches its real Android interface, and pressing Home brings you straight back to this desktop window."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalDivider(color = pcPalette.windowBorder)

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (matchedApp != null) {
                OutlinedButton(
                    onClick = { viewModel.togglePinToTaskbar(matchedApp) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.PushPin, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Pin Taskbar")
                }
                OutlinedButton(
                    onClick = { viewModel.hideApp(matchedApp) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.VisibilityOff, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Hide App")
                }
            }
            OutlinedButton(
                onClick = { viewModel.openAppInfo(pkg) },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Rounded.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("App Info")
            }
        }

        OutlinedButton(
            onClick = { viewModel.setLauncherMode(LauncherMode.MOBILE) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Rounded.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("Switch Launcher to Normal Mobile Mode")
        }
    }
}
