package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.movableContentOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AnimationEffectStyle
import com.example.data.model.LauncherMode
import com.example.data.model.TaskbarPosition
import com.example.data.model.ThemeMode
import com.example.data.model.VaultAccessMethod
import com.example.data.model.WindowType
import com.example.ui.components.CalendarFlyout
import com.example.ui.components.DesktopLockScreen
import com.example.ui.components.DesktopWorkspace
import com.example.ui.components.MobileHomeScreen
import com.example.ui.components.NotificationCenterFlyout
import com.example.ui.components.QuickSettingsFlyout
import com.example.ui.components.SecurityAuthDialog
import com.example.ui.components.WallpaperLayer
import com.example.ui.components.WindowFrame
import com.example.ui.components.WindowsStartMenu
import com.example.ui.components.WindowsTaskbar
import com.example.ui.theme.LocalPcPalette
import com.example.ui.theme.PcLauncherTheme
import com.example.ui.viewmodel.AuthPurpose
import com.example.ui.viewmodel.LauncherViewModel
import com.example.ui.windows.DesktopFolderWindow
import com.example.ui.windows.ExternalAppHostWindow
import com.example.ui.windows.FileExplorerWindow
import com.example.ui.windows.GalleryWindow
import com.example.ui.windows.NotepadWindow
import com.example.ui.windows.PcSettingsWindow
import com.example.ui.windows.PrivateVaultWindow
import com.example.ui.windows.RecycleBinWindow
import com.example.ui.windows.TaskMonitorWindow
import kotlinx.coroutines.delay

@Composable
fun PcDesktopScreen(
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit,
    onExitLauncher: () -> Unit
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val installedApps by viewModel.visibleInstalledApps.collectAsStateWithLifecycle()
    val pinnedApps by viewModel.pinnedApps.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val systemStatus by viewModel.systemStatus.collectAsStateWithLifecycle()
    val openWindows by viewModel.openWindows.collectAsStateWithLifecycle()
    val activeWindowId by viewModel.activeWindowId.collectAsStateWithLifecycle()
    val startMenuOpen by viewModel.startMenuOpen.collectAsStateWithLifecycle()
    val quickSettingsOpen by viewModel.quickSettingsOpen.collectAsStateWithLifecycle()
    val calendarFlyoutOpen by viewModel.calendarFlyoutOpen.collectAsStateWithLifecycle()
    val notificationCenterOpen by viewModel.notificationCenterOpen.collectAsStateWithLifecycle()
    val powerMenuOpen by viewModel.powerMenuOpen.collectAsStateWithLifecycle()
    val movingItemId by viewModel.movingDesktopItemId.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val isDesktopLocked by viewModel.isDesktopLocked.collectAsStateWithLifecycle()
    val lockErrorMessage by viewModel.lockErrorMessage.collectAsStateWithLifecycle()
    val hasPinConfigured by viewModel.hasPinConfigured.collectAsStateWithLifecycle()
    val authGate by viewModel.authGate.collectAsStateWithLifecycle()

    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            delay(2600L)
            viewModel.clearStatusMessage()
        }
    }

    val isDark = when (settings.themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val unreadCount = remember(notifications) { notifications.count { it.isUnread } }
    val hasAnyOverlay = startMenuOpen || quickSettingsOpen || calendarFlyoutOpen || notificationCenterOpen || powerMenuOpen
    val hasVisibleWindow = openWindows.any { !it.isMinimized }

    BackHandler(enabled = isDesktopLocked || authGate != null || hasAnyOverlay || movingItemId != null || hasVisibleWindow || systemStatus.isDefaultLauncher) {
        when {
            isDesktopLocked -> { /* Stay on Lock Screen until unlocked */ }
            authGate != null -> viewModel.dismissAuthGate()
            settings.launcherMode == LauncherMode.MOBILE -> { /* Stay on Mobile Home if default launcher */ }
            hasAnyOverlay -> viewModel.closeAllFlyouts()
            movingItemId != null -> viewModel.cancelMovingDesktopItem()
            hasVisibleWindow -> viewModel.closeTopActiveWindowIfAny()
            else -> { /* Stay on Desktop when acting as Android Home launcher */ }
        }
    }

    val baseDensity = LocalDensity.current
    val scaledDensity = remember(baseDensity, settings.desktopScale) {
        Density(
            density = (baseDensity.density * settings.desktopScale).coerceAtLeast(1f),
            fontScale = baseDensity.fontScale
        )
    }

    val latestRequestDefaultHome by rememberUpdatedState(onRequestDefaultHome)
    val latestExitLauncher by rememberUpdatedState(onExitLauncher)

    CompositionLocalProvider(LocalDensity provides scaledDensity) {
        PcLauncherTheme(
            darkTheme = isDark,
            settings = settings
        ) {
            val pcPalette = LocalPcPalette.current
            val pos = settings.taskbarPosition

            val workspaceSlot = remember(viewModel) {
                movableContentOf<Modifier> { workspaceMod ->
                    WorkspaceSlot(
                        viewModel = viewModel,
                        onRequestDefaultHome = { latestRequestDefaultHome() },
                        onExitLauncher = { latestExitLauncher() },
                        modifier = workspaceMod
                    )
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                WallpaperLayer(settings = settings)

                if (settings.launcherMode == LauncherMode.MOBILE) {
                    MobileHomeScreen(
                        installedApps = installedApps,
                        settings = settings,
                        systemStatus = systemStatus,
                        viewModel = viewModel
                    )

                    androidx.compose.animation.AnimatedVisibility(
                        visible = statusMessage != null,
                        enter = fadeIn(tween(150)),
                        exit = fadeOut(tween(200)),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 12.dp)
                    ) {
                        statusMessage?.let { msg ->
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = pcPalette.flyoutSurface,
                                tonalElevation = 10.dp,
                                shadowElevation = 8.dp
                            ) {
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                } else {
                    when (pos) {
                        TaskbarPosition.BOTTOM, TaskbarPosition.TOP -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                if (pos == TaskbarPosition.TOP) {
                                    WindowsTaskbar(
                                        settings = settings,
                                        systemStatus = systemStatus,
                                        pinnedApps = pinnedApps,
                                        installedApps = installedApps,
                                        openWindows = openWindows,
                                        activeWindowId = activeWindowId,
                                        startMenuOpen = startMenuOpen,
                                        unreadNotificationCount = unreadCount,
                                        viewModel = viewModel
                                    )
                                }
                                workspaceSlot(Modifier.weight(1f).fillMaxWidth())
                                if (pos == TaskbarPosition.BOTTOM) {
                                    WindowsTaskbar(
                                        settings = settings,
                                        systemStatus = systemStatus,
                                        pinnedApps = pinnedApps,
                                        installedApps = installedApps,
                                        openWindows = openWindows,
                                        activeWindowId = activeWindowId,
                                        startMenuOpen = startMenuOpen,
                                        unreadNotificationCount = unreadCount,
                                        viewModel = viewModel
                                    )
                                }
                            }
                        }
                        TaskbarPosition.LEFT, TaskbarPosition.RIGHT -> {
                            Row(modifier = Modifier.fillMaxSize()) {
                                if (pos == TaskbarPosition.LEFT) {
                                    WindowsTaskbar(
                                        settings = settings,
                                        systemStatus = systemStatus,
                                        pinnedApps = pinnedApps,
                                        installedApps = installedApps,
                                        openWindows = openWindows,
                                        activeWindowId = activeWindowId,
                                        startMenuOpen = startMenuOpen,
                                        unreadNotificationCount = unreadCount,
                                        viewModel = viewModel
                                    )
                                }
                                workspaceSlot(Modifier.weight(1f).fillMaxHeight())
                                if (pos == TaskbarPosition.RIGHT) {
                                    WindowsTaskbar(
                                        settings = settings,
                                        systemStatus = systemStatus,
                                        pinnedApps = pinnedApps,
                                        installedApps = installedApps,
                                        openWindows = openWindows,
                                        activeWindowId = activeWindowId,
                                        startMenuOpen = startMenuOpen,
                                        unreadNotificationCount = unreadCount,
                                        viewModel = viewModel
                                    )
                                }
                            }
                        }
                    }
                }

                // Professional Desktop Lock Screen Overlay
                androidx.compose.animation.AnimatedVisibility(
                    visible = isDesktopLocked,
                    enter = fadeIn(tween(240)),
                    exit = fadeOut(tween(220))
                ) {
                    DesktopLockScreen(
                        settings = settings,
                        systemStatus = systemStatus,
                        hasPinConfigured = hasPinConfigured,
                        errorMessage = lockErrorMessage,
                        viewModel = viewModel
                    )
                }

                // Auth Gate Modal for Private Vault or Private Gallery
                authGate?.let { gate ->
                    val bioAllowed = when (gate.purpose) {
                        AuthPurpose.PRIVATE_VAULT -> settings.vaultBiometricEnabled
                        AuthPurpose.PRIVATE_GALLERY -> settings.vaultBiometricEnabled
                    }
                    SecurityAuthDialog(
                        authGate = gate,
                        biometricAllowed = bioAllowed,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

@Composable
private fun WorkspaceSlot(
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit,
    onExitLauncher: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val desktopItems by viewModel.desktopItems.collectAsStateWithLifecycle()
    val recycleBinItems by viewModel.recycleBinItems.collectAsStateWithLifecycle()
    val installedApps by viewModel.visibleInstalledApps.collectAsStateWithLifecycle()
    val hiddenApps by viewModel.hiddenApps.collectAsStateWithLifecycle()
    val galleryAlbums by viewModel.galleryAlbums.collectAsStateWithLifecycle()
    val galleryMedia by viewModel.galleryMedia.collectAsStateWithLifecycle()
    val galleryPrivateUnlocked by viewModel.galleryPrivateUnlocked.collectAsStateWithLifecycle()
    val hasPinConfigured by viewModel.hasPinConfigured.collectAsStateWithLifecycle()
    val pinnedApps by viewModel.pinnedApps.collectAsStateWithLifecycle()
    val recentApps by viewModel.recentInstalledApps.collectAsStateWithLifecycle()
    val safMounts by viewModel.safMounts.collectAsStateWithLifecycle()
    val savedThemes by viewModel.savedThemes.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val systemStatus by viewModel.systemStatus.collectAsStateWithLifecycle()
    val openWindows by viewModel.openWindows.collectAsStateWithLifecycle()
    val activeWindowId by viewModel.activeWindowId.collectAsStateWithLifecycle()
    val startMenuOpen by viewModel.startMenuOpen.collectAsStateWithLifecycle()
    val startMenuFocusSearch by viewModel.startMenuFocusSearch.collectAsStateWithLifecycle()
    val quickSettingsOpen by viewModel.quickSettingsOpen.collectAsStateWithLifecycle()
    val calendarFlyoutOpen by viewModel.calendarFlyoutOpen.collectAsStateWithLifecycle()
    val notificationCenterOpen by viewModel.notificationCenterOpen.collectAsStateWithLifecycle()
    val powerMenuOpen by viewModel.powerMenuOpen.collectAsStateWithLifecycle()
    val movingItemId by viewModel.movingDesktopItemId.collectAsStateWithLifecycle()
    val explorerState by viewModel.explorerState.collectAsStateWithLifecycle()
    val notepadSessions by viewModel.notepadSessions.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    var showDefaultHomeBanner by remember { mutableStateOf(true) }

    val pos = settings.taskbarPosition
    val hasAnyOverlay = startMenuOpen || quickSettingsOpen || calendarFlyoutOpen || notificationCenterOpen || powerMenuOpen
    val animDuration = if (settings.animationsEnabled && settings.animationEffect != AnimationEffectStyle.REDUCED) {
        settings.animationSpeed.durationMs
    } else 0

    val nonImmersiveMod = if (settings.fullScreenImmersive) {
        Modifier
    } else {
        when (pos) {
            TaskbarPosition.BOTTOM -> Modifier.windowInsetsPadding(WindowInsets.statusBars)
            TaskbarPosition.TOP -> Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            TaskbarPosition.LEFT, TaskbarPosition.RIGHT -> Modifier
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
        }
    }

    Box(modifier = modifier.then(nonImmersiveMod)) {
        DesktopWorkspace(
            desktopItems = desktopItems,
            installedApps = installedApps,
            recycleBinCount = recycleBinItems.size,
            settings = settings,
            systemStatus = systemStatus,
            movingItemId = movingItemId,
            showDefaultHomeBanner = showDefaultHomeBanner,
            onDismissDefaultHomeBanner = { showDefaultHomeBanner = false },
            onRequestDefaultHome = onRequestDefaultHome,
            viewModel = viewModel
        )

        val sortedWindows = remember(openWindows) {
            openWindows.filterNot { it.isMinimized }.sortedBy { it.zIndex }
        }
        sortedWindows.forEach { win ->
            WindowFrame(
                window = win,
                isActive = win.id == activeWindowId,
                onFocus = { viewModel.focusWindow(win.id) },
                onMinimize = { viewModel.minimizeWindow(win.id) },
                onToggleMaximize = { viewModel.toggleMaximizeWindow(win.id) },
                onClose = { viewModel.closeWindow(win.id) },
                onMove = { dx, dy -> viewModel.moveWindow(win.id, dx, dy) },
                onResize = { dw, dh -> viewModel.resizeWindow(win.id, dw, dh) }
            ) {
                when (win.type) {
                    WindowType.FILE_EXPLORER -> FileExplorerWindow(
                        explorerState = explorerState,
                        safMounts = safMounts,
                        systemStatus = systemStatus,
                        viewModel = viewModel
                    )
                    WindowType.PC_SETTINGS -> PcSettingsWindow(
                        settings = settings,
                        systemStatus = systemStatus,
                        installedApps = installedApps,
                        savedThemes = savedThemes,
                        notifications = notifications,
                        viewModel = viewModel,
                        onRequestDefaultHome = onRequestDefaultHome
                    )
                    WindowType.RECYCLE_BIN -> RecycleBinWindow(
                        items = recycleBinItems,
                        viewModel = viewModel
                    )
                    WindowType.DESKTOP_FOLDER -> DesktopFolderWindow(
                        folderId = win.folderId.orEmpty(),
                        desktopItems = desktopItems,
                        recycleBinCount = recycleBinItems.size,
                        viewModel = viewModel
                    )
                    WindowType.NOTEPAD -> NotepadWindow(
                        session = notepadSessions[win.id],
                        viewModel = viewModel
                    )
                    WindowType.TASK_MONITOR -> TaskMonitorWindow(
                        systemStatus = systemStatus,
                        openWindows = openWindows,
                        viewModel = viewModel
                    )
                    WindowType.GALLERY -> GalleryWindow(
                        albums = galleryAlbums,
                        mediaItems = galleryMedia,
                        privateUnlocked = galleryPrivateUnlocked,
                        viewModel = viewModel
                    )
                    WindowType.PRIVATE_VAULT -> PrivateVaultWindow(
                        hiddenApps = hiddenApps,
                        visibleApps = installedApps,
                        settings = settings,
                        hasPinConfigured = hasPinConfigured,
                        viewModel = viewModel
                    )
                    WindowType.EXTERNAL_APP_HOST -> ExternalAppHostWindow(
                        window = win,
                        settings = settings,
                        systemStatus = systemStatus,
                        installedApps = installedApps,
                        viewModel = viewModel
                    )
                }
            }
        }

        if (hasAnyOverlay) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { viewModel.closeAllFlyouts() }
                    )
            )
        }

        val startAlignment = when (pos) {
            TaskbarPosition.BOTTOM -> Alignment.BottomStart
            TaskbarPosition.TOP -> Alignment.TopStart
            TaskbarPosition.LEFT -> Alignment.TopStart
            TaskbarPosition.RIGHT -> Alignment.TopEnd
        }
        val trayAlignment = when (pos) {
            TaskbarPosition.BOTTOM -> Alignment.BottomEnd
            TaskbarPosition.TOP -> Alignment.TopEnd
            TaskbarPosition.LEFT -> Alignment.BottomStart
            TaskbarPosition.RIGHT -> Alignment.BottomEnd
        }

        val startEnter = when (settings.animationEffect) {
            AnimationEffectStyle.FADE, AnimationEffectStyle.REDUCED -> fadeIn(tween(animDuration))
            AnimationEffectStyle.SPRING -> fadeIn(tween(animDuration)) + scaleIn(tween(animDuration), initialScale = 0.94f)
            AnimationEffectStyle.SLIDE -> fadeIn(tween(animDuration)) + when (pos) {
                TaskbarPosition.TOP -> slideInVertically(tween(animDuration)) { -it / 4 }
                TaskbarPosition.BOTTOM -> slideInVertically(tween(animDuration)) { it / 4 }
                TaskbarPosition.LEFT -> slideInHorizontally(tween(animDuration)) { -it / 4 }
                TaskbarPosition.RIGHT -> slideInHorizontally(tween(animDuration)) { it / 4 }
            }
        }
        val startExit = when (settings.animationEffect) {
            AnimationEffectStyle.FADE, AnimationEffectStyle.REDUCED -> fadeOut(tween(animDuration))
            AnimationEffectStyle.SPRING -> fadeOut(tween(animDuration)) + scaleOut(tween(animDuration), targetScale = 0.96f)
            AnimationEffectStyle.SLIDE -> fadeOut(tween(animDuration)) + when (pos) {
                TaskbarPosition.TOP -> slideOutVertically(tween(animDuration)) { -it / 4 }
                TaskbarPosition.BOTTOM -> slideOutVertically(tween(animDuration)) { it / 4 }
                TaskbarPosition.LEFT -> slideOutHorizontally(tween(animDuration)) { -it / 4 }
                TaskbarPosition.RIGHT -> slideOutHorizontally(tween(animDuration)) { it / 4 }
            }
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = startMenuOpen,
            enter = startEnter,
            exit = startExit,
            modifier = Modifier
                .align(startAlignment)
                .imePadding()
                .padding(10.dp)
        ) {
            WindowsStartMenu(
                installedApps = installedApps,
                pinnedApps = pinnedApps,
                recentApps = recentApps,
                settings = settings,
                focusSearchOnOpen = startMenuFocusSearch,
                powerMenuOpen = powerMenuOpen,
                viewModel = viewModel,
                onRequestDefaultHome = onRequestDefaultHome,
                onExitLauncher = onExitLauncher
            )
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = quickSettingsOpen,
            enter = fadeIn(tween(animDuration)),
            exit = fadeOut(tween(animDuration)),
            modifier = Modifier
                .align(trayAlignment)
                .padding(10.dp)
        ) {
            QuickSettingsFlyout(
                settings = settings,
                systemStatus = systemStatus,
                viewModel = viewModel,
                onRequestDefaultHome = onRequestDefaultHome
            )
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = calendarFlyoutOpen,
            enter = fadeIn(tween(animDuration)),
            exit = fadeOut(tween(animDuration)),
            modifier = Modifier
                .align(trayAlignment)
                .padding(10.dp)
        ) {
            CalendarFlyout(
                currentTimeMillis = systemStatus.currentTimeMillis,
                onMonthHeaderLongPress = {
                    if (settings.vaultAccessMethod == VaultAccessMethod.CALENDAR_HEADER_HOLD) {
                        viewModel.triggerDiscreetVaultAccess()
                    }
                }
            )
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = notificationCenterOpen,
            enter = fadeIn(tween(animDuration)),
            exit = fadeOut(tween(animDuration)),
            modifier = Modifier
                .align(trayAlignment)
                .padding(10.dp)
        ) {
            NotificationCenterFlyout(
                notifications = notifications,
                onDismiss = { viewModel.dismissNotification(it) },
                onClearAll = { viewModel.clearAllNotifications() }
            )
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = statusMessage != null,
            enter = fadeIn(tween(150)),
            exit = fadeOut(tween(200)),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 12.dp)
        ) {
            statusMessage?.let { msg ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = pcPalette.flyoutSurface,
                    tonalElevation = 10.dp,
                    shadowElevation = 8.dp
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}
