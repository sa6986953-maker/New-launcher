package com.example.ui.windows

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.RestoreFromTrash
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopWindow
import com.example.data.model.RecycleBinItem
import com.example.data.model.SystemStatus
import com.example.ui.components.DesktopItemIcon
import com.example.ui.components.TextInputDialog
import com.example.ui.components.formatBytes
import com.example.ui.components.formatTimestamp
import com.example.ui.components.windowTypeIcon
import com.example.ui.components.windowTypeTint
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel
import com.example.ui.viewmodel.NotepadState

@Composable
fun RecycleBinWindow(
    items: List<RecycleBinItem>,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(pcPalette.windowHeader.copy(alpha = 0.55f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text("${items.size} item(s) in Recycle Bin", style = MaterialTheme.typography.bodySmall)
            Button(
                onClick = { viewModel.emptyRecycleBin() },
                enabled = items.isNotEmpty(),
                modifier = Modifier.testTag("empty_recycle_bin_button")
            ) {
                Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Empty Recycle Bin")
            }
        }
        HorizontalDivider(color = pcPalette.windowBorder)

        if (items.isEmpty()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize().padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(56.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text("Recycle Bin is empty", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Deleted desktop shortcuts and folders appear here so you can restore them anytime.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(items, key = { it.id }) { binItem ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = pcPalette.windowCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(binItem.title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "From ${binItem.originalLocation} • Deleted ${formatTimestamp(binItem.deletedAt)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.restoreFromRecycleBin(binItem) }) {
                                Icon(Icons.Rounded.RestoreFromTrash, contentDescription = "Restore", tint = pcPalette.accent)
                            }
                            IconButton(onClick = { viewModel.deletePermanentlyFromRecycleBin(binItem.id) }) {
                                Icon(Icons.Rounded.DeleteForever, contentDescription = "Delete Permanently", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DesktopFolderWindow(
    folderId: String,
    desktopItems: List<DesktopItem>,
    recycleBinCount: Int,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current
    val children = remember(desktopItems, folderId) {
        desktopItems.filter { it.parentFolderId == folderId }
    }
    var showNewFolder by remember { mutableStateOf(false) }
    var showNewNote by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .background(pcPalette.windowHeader.copy(alpha = 0.55f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            OutlinedButton(onClick = { showNewFolder = true }) {
                Icon(Icons.Rounded.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("New Folder")
            }
            OutlinedButton(onClick = { showNewNote = true }) {
                Icon(Icons.Rounded.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("New Note")
            }
        }
        HorizontalDivider(color = pcPalette.windowBorder)

        if (children.isEmpty()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize().padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.FolderOpen,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(52.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text("Folder is empty", style = MaterialTheme.typography.titleSmall)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 96.dp),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(children, key = { it.id }) { child ->
                    var showMenu by remember { mutableStateOf(false) }
                    Box {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(pcPalette.windowCard.copy(alpha = 0.55f))
                                .combinedClickable(
                                    onClick = { viewModel.openDesktopItem(child) },
                                    onLongClick = { showMenu = true }
                                )
                                .padding(10.dp)
                        ) {
                            DesktopItemIcon(
                                item = child,
                                recycleBinCount = recycleBinCount,
                                viewModel = viewModel,
                                size = 40.dp,
                                iconPack = pcPalette.iconPack
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = child.title,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Open") },
                                onClick = { showMenu = false; viewModel.openDesktopItem(child) }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete to Recycle Bin") },
                                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null) },
                                onClick = { showMenu = false; viewModel.moveDesktopItemToRecycleBin(child) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNewFolder) {
        TextInputDialog(
            title = "New Subfolder",
            label = "Name",
            initialValue = "Subfolder",
            confirmLabel = "Create",
            onDismiss = { showNewFolder = false },
            onConfirm = { name ->
                showNewFolder = false
                viewModel.createDesktopFolder(name, parentFolderId = folderId)
            }
        )
    }

    if (showNewNote) {
        TextInputDialog(
            title = "New Note",
            label = "File name",
            initialValue = "Note.txt",
            confirmLabel = "Create",
            onDismiss = { showNewNote = false },
            onConfirm = { name ->
                showNewNote = false
                viewModel.createDesktopTextFile(name, parentFolderId = folderId)
            }
        )
    }
}

@Composable
fun NotepadWindow(
    session: NotepadState?,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current
    if (session == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Document unavailable")
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(pcPalette.windowHeader.copy(alpha = 0.55f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = if (session.isDirty) "${session.title} • Unsaved changes" else "${session.title} • Saved",
                style = MaterialTheme.typography.labelMedium,
                color = if (session.isDirty) pcPalette.accent else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = { viewModel.saveNotepad(session.windowId) },
                enabled = session.isDirty
            ) {
                Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Save")
            }
        }
        HorizontalDivider(color = pcPalette.windowBorder)

        BasicTextField(
            value = session.content,
            onValueChange = { viewModel.updateNotepadContent(session.windowId, it) },
            textStyle = TextStyle(
                color = MaterialTheme.colorScheme.onSurface,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 13.sp,
                lineHeight = 20.sp
            ),
            cursorBrush = SolidColor(pcPalette.accent),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(14.dp)
        )

        HorizontalDivider(color = pcPalette.windowBorder)
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Lines: ${session.content.lines().size}  |  Characters: ${session.content.length}",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = JetBrainsMonoFamily,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "UTF-8",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = JetBrainsMonoFamily,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun TaskMonitorWindow(
    systemStatus: SystemStatus,
    openWindows: List<DesktopWindow>,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current
    val ramFrac = if (systemStatus.ramTotalBytes > 0) {
        (systemStatus.ramUsedBytes.toFloat() / systemStatus.ramTotalBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f
    val storageFrac = if (systemStatus.storageTotalBytes > 0) {
        (systemStatus.storageUsedBytes.toFloat() / systemStatus.storageTotalBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text("Hardware Performance", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = pcPalette.windowCard,
                    modifier = Modifier.weight(1f).border(1.dp, pcPalette.windowBorder, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Memory, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Memory (RAM)", style = MaterialTheme.typography.titleSmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { ramFrac }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "${formatBytes(systemStatus.ramUsedBytes)} / ${formatBytes(systemStatus.ramTotalBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFamily
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = pcPalette.windowCard,
                    modifier = Modifier.weight(1f).border(1.dp, pcPalette.windowBorder, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Storage, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Disk Storage", style = MaterialTheme.typography.titleSmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { storageFrac }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "${formatBytes(systemStatus.storageUsedBytes)} / ${formatBytes(systemStatus.storageTotalBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFamily
                        )
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = pcPalette.windowCard,
                modifier = Modifier.fillMaxWidth().border(1.dp, pcPalette.windowBorder, RoundedCornerShape(12.dp))
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(12.dp)) {
                    Icon(Icons.Rounded.BatteryChargingFull, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Battery: ${systemStatus.batteryPercent}% ${if (systemStatus.isCharging) "(Charging)" else "(Discharging)"}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        item {
            Text("Active Launcher Windows (${openWindows.size})", style = MaterialTheme.typography.titleMedium)
        }

        items(openWindows, key = { it.id }) { win ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = pcPalette.windowCard,
                modifier = Modifier.fillMaxWidth().border(1.dp, pcPalette.windowBorder, RoundedCornerShape(10.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = windowTypeIcon(win.type),
                        contentDescription = null,
                        tint = windowTypeTint(win.type, pcPalette.accent),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(win.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Text(
                            text = if (win.isMinimized) "Minimized" else if (win.isMaximized) "Maximized" else "Windowed",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { viewModel.focusWindow(win.id) }) { Text("Focus") }
                    TextButton(onClick = { viewModel.closeWindow(win.id) }) {
                        Text("End Task", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}
