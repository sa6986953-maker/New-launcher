package com.example.ui.windows

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.HiddenAppInfo
import com.example.data.model.InstalledApp
import com.example.data.model.PcSettingsState
import com.example.data.model.WindowType
import com.example.ui.components.AppPackageIcon
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel

@Composable
fun PrivateVaultWindow(
    hiddenApps: List<HiddenAppInfo>,
    visibleApps: List<InstalledApp>,
    settings: PcSettingsState,
    hasPinConfigured: Boolean,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current
    var showAddAppDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().testTag("private_vault_window")) {
        // Header Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(pcPalette.windowHeader.copy(alpha = 0.6f))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("Private Vault (${hiddenApps.size} hidden)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "Entry: ${settings.vaultAccessMethod.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showAddAppDialog = true }, modifier = Modifier.testTag("vault_hide_app_button")) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Hide App")
                }
                Button(onClick = { viewModel.lockVaultSession() }, modifier = Modifier.testTag("vault_lock_button")) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Lock")
                }
            }
        }
        HorizontalDivider(color = pcPalette.windowBorder)

        LazyColumn(
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (!hasPinConfigured) {
                item {
                    Surface(
                        shape = RoundedCornerShape(pcPalette.cardCornerDp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Text(
                                text = "No PIN configured yet. Set a PIN & Recovery Key in PC Settings → Security to lock this Private Vault.",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { viewModel.openWindow(WindowType.PC_SETTINGS, "PC Settings") }) {
                                Text("Set PIN")
                            }
                        }
                    }
                }
            }

            item {
                Surface(
                    shape = RoundedCornerShape(pcPalette.cardCornerDp),
                    color = pcPalette.windowCard,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Private Gallery Safe", style = MaterialTheme.typography.titleSmall)
                            Text("Protected photos & videos imported into app-private storage.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(onClick = {
                            viewModel.requestPrivateGalleryAccess()
                            viewModel.openWindow(WindowType.GALLERY, "Gallery")
                        }) {
                            Text("Open Gallery")
                        }
                    }
                }
            }

            item {
                Text("Hidden Apps", style = MaterialTheme.typography.titleMedium)
            }

            if (hiddenApps.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(pcPalette.cardCornerDp),
                        color = pcPalette.windowCard,
                        modifier = Modifier.fillMaxWidth().border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(Icons.Rounded.VisibilityOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("No apps are currently hidden", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "Use \"Hide App\" above or long-press any app on the Desktop / Start Menu / App Drawer to move it here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(hiddenApps, key = { it.componentKey }) { app ->
                    Surface(
                        shape = RoundedCornerShape(pcPalette.cardCornerDp),
                        color = pcPalette.windowCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
                            .testTag("hidden_app_row_${app.packageName}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            AppPackageIcon(
                                packageName = app.packageName,
                                activityName = app.activityName,
                                contentDescription = app.label,
                                viewModel = viewModel,
                                size = 34.dp
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(app.label, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = {
                                viewModel.launchAppDirectly(app.packageName, app.activityName, app.label)
                            }) {
                                Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = "Launch ${app.label}", tint = pcPalette.accent)
                            }
                            TextButton(
                                onClick = { viewModel.unhideApp(app.componentKey) },
                                modifier = Modifier.testTag("unhide_app_${app.packageName}")
                            ) {
                                Icon(Icons.Rounded.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Unhide")
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Android Privacy Note: Hidden apps are removed from PC Desktop Launcher's app drawer, Start Menu, search, and desktop grid without uninstalling or erasing their data. Android System Settings and other third-party launchers still display installed system packages.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (showAddAppDialog) {
        var filter by remember { mutableStateOf("") }
        val filtered = remember(visibleApps, filter) {
            if (filter.isBlank()) visibleApps
            else visibleApps.filter { it.label.contains(filter, ignoreCase = true) || it.packageName.contains(filter, ignoreCase = true) }
        }
        AlertDialog(
            onDismissRequest = { showAddAppDialog = false },
            title = { Text("Hide an Installed App") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = filter,
                        onValueChange = { filter = it },
                        label = { Text("Search apps") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(filtered, key = { it.componentKey }) { app ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        viewModel.hideApp(app)
                                        showAddAppDialog = false
                                    }
                                    .padding(vertical = 8.dp, horizontal = 6.dp)
                            ) {
                                AppPackageIcon(app.packageName, app.activityName, app.label, viewModel, size = 28.dp)
                                Spacer(Modifier.width(10.dp))
                                Text(app.label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Icon(Icons.Rounded.VisibilityOff, contentDescription = "Hide", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddAppDialog = false }) { Text("Close") }
            }
        )
    }
}
