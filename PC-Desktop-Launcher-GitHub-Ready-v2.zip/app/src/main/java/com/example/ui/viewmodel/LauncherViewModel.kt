package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LauncherDatabase
import com.example.data.local.PinnedAppEntity
import com.example.data.local.SavedThemeEntity
import com.example.data.local.SettingsDataStore
import com.example.data.model.AnimationEffectStyle
import com.example.data.model.AnimationSpeed
import com.example.data.model.CornerStyle
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopItemType
import com.example.data.model.DesktopThemePreset
import com.example.data.model.DesktopWindow
import com.example.data.model.ExplorerRootSection
import com.example.data.model.FileClipboard
import com.example.data.model.FileNode
import com.example.data.model.FontStyleOption
import com.example.data.model.GalleryAlbum
import com.example.data.model.GalleryMediaItem
import com.example.data.model.HiddenAppInfo
import com.example.data.model.IconPackStyle
import com.example.data.model.IconSizeOption
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherMode
import com.example.data.model.LauncherNotification
import com.example.data.model.OrientationMode
import com.example.data.model.PcSettingsState
import com.example.data.model.RecycleBinItem
import com.example.data.model.SafMount
import com.example.data.model.SavedThemeProfile
import com.example.data.model.ScreenLayoutDensity
import com.example.data.model.SystemStatus
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarSizeOption
import com.example.data.model.TaskbarStyle
import com.example.data.model.ThemeMode
import com.example.data.model.VaultAccessMethod
import com.example.data.model.WallpaperFitOption
import com.example.data.model.WindowAppearance
import com.example.data.model.WindowType
import com.example.data.repository.AppRepository
import com.example.data.repository.DesktopRepository
import com.example.data.repository.FileExplorerRepository
import com.example.data.repository.GalleryRepository
import com.example.data.repository.SystemMonitorRepository
import com.example.data.security.SecurityVaultManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class ExplorerUiState(
    val currentLocationLabel: String = "This PC",
    val currentPathOrUri: String? = null,
    val currentIsSaf: Boolean = false,
    val breadcrumbs: List<Pair<String, String?>> = listOf("This PC" to null),
    val files: List<FileNode> = emptyList(),
    val searchQuery: String = "",
    val isGridView: Boolean = false,
    val isLoading: Boolean = false,
    val clipboard: FileClipboard? = null
)

data class NotepadState(
    val windowId: String,
    val title: String,
    val pathOrUri: String,
    val isSaf: Boolean,
    val content: String,
    val isDirty: Boolean = false
)

enum class AuthPurpose(val title: String, val subtitle: String) {
    PRIVATE_VAULT("Private Vault", "Authenticate to access hidden apps and protected space."),
    PRIVATE_GALLERY("Private Safe Album", "Authenticate to unlock private photos and videos.")
}

data class AuthGateState(
    val purpose: AuthPurpose,
    val error: String? = null
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val db = LauncherDatabase.getInstance(application)
    private val dao = db.launcherDao()
    private val settingsStore = SettingsDataStore(application)

    val appRepository = AppRepository(application, dao)
    private val desktopRepository = DesktopRepository(dao)
    val fileRepository = FileExplorerRepository(application, dao)
    val galleryRepository = GalleryRepository(application, dao)
    val systemMonitor = SystemMonitorRepository(application)
    val securityVault = SecurityVaultManager(application)

    val settings: StateFlow<PcSettingsState> = settingsStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, PcSettingsState())

    val hiddenApps: StateFlow<List<HiddenAppInfo>> = desktopRepository.hiddenApps
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val hiddenComponentKeys: StateFlow<Set<String>> = hiddenApps
        .map { list -> list.map { it.componentKey }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val installedApps: StateFlow<List<InstalledApp>> = appRepository.installedApps

    val visibleInstalledApps: StateFlow<List<InstalledApp>> = combine(
        appRepository.installedApps,
        hiddenComponentKeys
    ) { apps, hidden ->
        if (hidden.isEmpty()) apps else apps.filterNot { it.componentKey in hidden }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val desktopItems: StateFlow<List<DesktopItem>> = combine(
        desktopRepository.desktopItems,
        hiddenComponentKeys
    ) { items, hidden ->
        if (hidden.isEmpty()) items
        else items.filterNot { item ->
            item.type == DesktopItemType.APP_SHORTCUT &&
                item.targetPackage != null &&
                item.targetActivity != null &&
                "${item.targetPackage}/${item.targetActivity}" in hidden
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recycleBinItems: StateFlow<List<RecycleBinItem>> = desktopRepository.recycleBinItems
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val pinnedApps: StateFlow<List<PinnedAppEntity>> = combine(
        desktopRepository.pinnedApps,
        hiddenComponentKeys
    ) { pins, hidden ->
        if (hidden.isEmpty()) pins else pins.filterNot { it.componentKey in hidden }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentInstalledApps: StateFlow<List<InstalledApp>> = combine(
        desktopRepository.recentApps,
        visibleInstalledApps
    ) { recents, installed ->
        val byKey = installed.associateBy { it.componentKey }
        recents.mapNotNull { recent ->
            byKey[recent.componentKey]?.copy(lastLaunchTime = recent.lastLaunchedAt)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val galleryAlbums: StateFlow<List<GalleryAlbum>> = galleryRepository.albums
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val galleryMedia: StateFlow<List<GalleryMediaItem>> = galleryRepository.mediaItems
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val safMounts: StateFlow<List<SafMount>> = fileRepository.safMounts
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val savedThemes: StateFlow<List<SavedThemeProfile>> = dao.observeSavedThemes()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val systemStatus: StateFlow<SystemStatus> = systemMonitor.status

    private val _openWindows = MutableStateFlow<List<DesktopWindow>>(emptyList())
    val openWindows: StateFlow<List<DesktopWindow>> = _openWindows.asStateFlow()

    private val _activeWindowId = MutableStateFlow<String?>(null)
    val activeWindowId: StateFlow<String?> = _activeWindowId.asStateFlow()

    private val _startMenuOpen = MutableStateFlow(false)
    val startMenuOpen: StateFlow<Boolean> = _startMenuOpen.asStateFlow()

    private val _startMenuFocusSearch = MutableStateFlow(false)
    val startMenuFocusSearch: StateFlow<Boolean> = _startMenuFocusSearch.asStateFlow()

    private val _quickSettingsOpen = MutableStateFlow(false)
    val quickSettingsOpen: StateFlow<Boolean> = _quickSettingsOpen.asStateFlow()

    private val _calendarFlyoutOpen = MutableStateFlow(false)
    val calendarFlyoutOpen: StateFlow<Boolean> = _calendarFlyoutOpen.asStateFlow()

    private val _notificationCenterOpen = MutableStateFlow(false)
    val notificationCenterOpen: StateFlow<Boolean> = _notificationCenterOpen.asStateFlow()

    private val _powerMenuOpen = MutableStateFlow(false)
    val powerMenuOpen: StateFlow<Boolean> = _powerMenuOpen.asStateFlow()

    private val _movingDesktopItemId = MutableStateFlow<String?>(null)
    val movingDesktopItemId: StateFlow<String?> = _movingDesktopItemId.asStateFlow()

    private val _explorerState = MutableStateFlow(ExplorerUiState())
    val explorerState: StateFlow<ExplorerUiState> = _explorerState.asStateFlow()

    private val _notepadSessions = MutableStateFlow<Map<String, NotepadState>>(emptyMap())
    val notepadSessions: StateFlow<Map<String, NotepadState>> = _notepadSessions.asStateFlow()

    // Lock Screen, Private Vault & Security State
    private val _isDesktopLocked = MutableStateFlow(false)
    val isDesktopLocked: StateFlow<Boolean> = _isDesktopLocked.asStateFlow()

    private val _lockErrorMessage = MutableStateFlow<String?>(null)
    val lockErrorMessage: StateFlow<String?> = _lockErrorMessage.asStateFlow()

    private val _hasPinConfigured = MutableStateFlow(securityVault.hasPinConfigured())
    val hasPinConfigured: StateFlow<Boolean> = _hasPinConfigured.asStateFlow()

    private val _securityQuestion = MutableStateFlow(securityVault.getRecoveryQuestion())
    val securityQuestion: StateFlow<String?> = _securityQuestion.asStateFlow()

    private val _latestBackupRecoveryKey = MutableStateFlow<String?>(null)
    val latestBackupRecoveryKey: StateFlow<String?> = _latestBackupRecoveryKey.asStateFlow()

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private val _galleryPrivateUnlocked = MutableStateFlow(false)
    val galleryPrivateUnlocked: StateFlow<Boolean> = _galleryPrivateUnlocked.asStateFlow()

    private val _authGate = MutableStateFlow<AuthGateState?>(null)
    val authGate: StateFlow<AuthGateState?> = _authGate.asStateFlow()

    private val _notifications = MutableStateFlow(
        listOf(
            LauncherNotification(
                id = "welcome_notif",
                title = "PC Desktop Environment Ready",
                message = "Dual Desktop & Mobile modes, Private Gallery, and Desktop Lock Screen are active.",
                isUnread = true
            )
        )
    )
    val notifications: StateFlow<List<LauncherNotification>> = _notifications.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var nextZIndex = 10

    init {
        appRepository.startObservingPackages()
        systemMonitor.startMonitoring()

        viewModelScope.launch {
            fileRepository.ensureWorkspaceSeeded()
            galleryRepository.ensureSeeded()
            appRepository.refreshInstalledApps()
            val apps = appRepository.installedApps.first { it.isNotEmpty() || true }
            desktopRepository.ensureSeeded(apps)

            val initialSettings = settingsStore.settingsFlow.first()
            if (initialSettings.lockScreenEnabled) {
                _isDesktopLocked.value = true
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        appRepository.stopObservingPackages()
        systemMonitor.stopMonitoring()
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        if (settings.value.showToastNotifications) {
            _statusMessage.value = msg
        }
    }

    private fun pushNotification(title: String, message: String) {
        _notifications.update { list ->
            (listOf(LauncherNotification(UUID.randomUUID().toString(), title, message)) + list).take(25)
        }
    }

    fun markAllNotificationsRead() {
        _notifications.update { list -> list.map { it.copy(isUnread = false) } }
    }

    fun dismissNotification(id: String) {
        _notifications.update { list -> list.filterNot { it.id == id } }
    }

    fun clearAllNotifications() {
        _notifications.value = emptyList()
    }

    fun refreshSystemStatus() {
        systemMonitor.refreshAll()
    }

    fun refreshDesktopAndApps() {
        viewModelScope.launch {
            appRepository.refreshInstalledApps()
            systemMonitor.refreshAll()
            showMessage("Desktop and installed apps refreshed")
        }
    }

    fun onHomePressed() {
        closeAllFlyouts()
        _movingDesktopItemId.value = null
    }

    fun closeAllFlyouts() {
        _startMenuOpen.value = false
        _startMenuFocusSearch.value = false
        _quickSettingsOpen.value = false
        _calendarFlyoutOpen.value = false
        _notificationCenterOpen.value = false
        _powerMenuOpen.value = false
    }

    fun toggleStartMenu(focusSearch: Boolean = false) {
        val next = if (focusSearch && _startMenuOpen.value && !_startMenuFocusSearch.value) true else !_startMenuOpen.value
        _quickSettingsOpen.value = false
        _calendarFlyoutOpen.value = false
        _notificationCenterOpen.value = false
        _powerMenuOpen.value = false
        _startMenuFocusSearch.value = focusSearch && next
        _startMenuOpen.value = next
    }

    fun toggleQuickSettings() {
        val next = !_quickSettingsOpen.value
        _startMenuOpen.value = false
        _calendarFlyoutOpen.value = false
        _notificationCenterOpen.value = false
        _powerMenuOpen.value = false
        _quickSettingsOpen.value = next
        if (next) systemMonitor.refreshAll()
    }

    fun toggleCalendarFlyout() {
        val next = !_calendarFlyoutOpen.value
        _startMenuOpen.value = false
        _quickSettingsOpen.value = false
        _notificationCenterOpen.value = false
        _powerMenuOpen.value = false
        _calendarFlyoutOpen.value = next
    }

    fun toggleNotificationCenter() {
        val next = !_notificationCenterOpen.value
        _startMenuOpen.value = false
        _quickSettingsOpen.value = false
        _calendarFlyoutOpen.value = false
        _powerMenuOpen.value = false
        _notificationCenterOpen.value = next
        if (next) markAllNotificationsRead()
    }

    fun togglePowerMenu() {
        _powerMenuOpen.value = !_powerMenuOpen.value
    }

    // ---- Dual Mode (Desktop vs Normal Mobile Mode) ----
    fun setLauncherMode(mode: LauncherMode) {
        closeAllFlyouts()
        updateSettings { it.copy(launcherMode = mode) }
        showMessage("Switched to ${mode.label}")
    }

    fun toggleLauncherMode() {
        val next = if (settings.value.launcherMode == LauncherMode.DESKTOP) {
            LauncherMode.MOBILE
        } else {
            LauncherMode.DESKTOP
        }
        setLauncherMode(next)
    }

    fun canUseBiometrics(): Boolean = securityVault.canUseBiometrics()

    // ---- Desktop Lock Screen & Security Vault ----
    fun lockDesktop() {
        closeAllFlyouts()
        _lockErrorMessage.value = null
        _isDesktopLocked.value = true
    }

    fun attemptUnlockDesktopWithPin(pin: String): Boolean {
        if (!securityVault.hasPinConfigured()) {
            _lockErrorMessage.value = null
            _isDesktopLocked.value = false
            return true
        }
        return if (securityVault.verifyPin(pin)) {
            _lockErrorMessage.value = null
            _isDesktopLocked.value = false
            true
        } else {
            _lockErrorMessage.value = "Incorrect PIN or password. Please try again."
            false
        }
    }

    fun attemptUnlockDesktopWithBiometric(activity: FragmentActivity) {
        if (!settings.value.lockScreenBiometricEnabled) {
            _lockErrorMessage.value = "Fingerprint unlock is disabled in PC Settings."
            return
        }
        securityVault.authenticateWithBiometric(
            activity = activity,
            title = "Unlock PC Desktop",
            subtitle = "Verify your identity to return to your workspace",
            onSuccess = {
                _lockErrorMessage.value = null
                _isDesktopLocked.value = false
            },
            onError = { err ->
                _lockErrorMessage.value = err
            }
        )
    }

    fun triggerDiscreetVaultAccess() {
        closeAllFlyouts()
        if (!securityVault.hasPinConfigured()) {
            _isVaultUnlocked.value = true
            openWindow(WindowType.PRIVATE_VAULT, "Private Vault")
            return
        }
        if (_isVaultUnlocked.value) {
            openWindow(WindowType.PRIVATE_VAULT, "Private Vault")
        } else {
            _authGate.value = AuthGateState(AuthPurpose.PRIVATE_VAULT)
        }
    }

    fun requestPrivateGalleryAccess() {
        if (!securityVault.hasPinConfigured()) {
            _galleryPrivateUnlocked.value = true
            return
        }
        if (!_galleryPrivateUnlocked.value) {
            _authGate.value = AuthGateState(AuthPurpose.PRIVATE_GALLERY)
        }
    }

    fun lockPrivateGallery() {
        _galleryPrivateUnlocked.value = false
    }

    fun dismissAuthGate() {
        _authGate.value = null
    }

    fun submitAuthGatePin(pin: String): Boolean {
        val gate = _authGate.value ?: return false
        return if (!securityVault.hasPinConfigured() || securityVault.verifyPin(pin)) {
            onAuthGateSucceeded(gate.purpose)
            true
        } else {
            _authGate.value = gate.copy(error = "Incorrect PIN or password.")
            false
        }
    }

    fun submitAuthGateBiometric(activity: FragmentActivity) {
        val gate = _authGate.value ?: return
        if (!settings.value.vaultBiometricEnabled) {
            _authGate.value = gate.copy(error = "Biometric unlock is disabled for Private Vault.")
            return
        }
        securityVault.authenticateWithBiometric(
            activity = activity,
            title = gate.purpose.title,
            subtitle = gate.purpose.subtitle,
            onSuccess = { onAuthGateSucceeded(gate.purpose) },
            onError = { msg -> _authGate.value = gate.copy(error = msg) }
        )
    }

    private fun onAuthGateSucceeded(purpose: AuthPurpose) {
        _authGate.value = null
        when (purpose) {
            AuthPurpose.PRIVATE_VAULT -> {
                _isVaultUnlocked.value = true
                openWindow(WindowType.PRIVATE_VAULT, "Private Vault")
            }
            AuthPurpose.PRIVATE_GALLERY -> {
                _galleryPrivateUnlocked.value = true
            }
        }
    }

    fun setupPinAndRecovery(pin: String, question: String, answer: String): Result<String> {
        return runCatching {
            val code = securityVault.setupPinAndRecovery(pin, question, answer)
            _hasPinConfigured.value = true
            _securityQuestion.value = securityVault.getRecoveryQuestion()
            _latestBackupRecoveryKey.value = code
            showMessage("Security PIN & recovery key saved")
            pushNotification("Security Enabled", "PIN/password protection and backup recovery key configured.")
            code
        }
    }

    fun dismissRecoveryKeyBanner() {
        _latestBackupRecoveryKey.value = null
    }

    fun verifyRecoveryCredential(input: String, isBackupKey: Boolean): Boolean {
        val ok = if (isBackupKey) {
            securityVault.verifyBackupKey(input)
        } else {
            securityVault.verifyRecoveryAnswer(input)
        }
        if (ok) {
            _isDesktopLocked.value = false
            _lockErrorMessage.value = null
            _authGate.value?.let { onAuthGateSucceeded(it.purpose) }
        }
        return ok
    }

    fun resetPinAfterRecovery(newPin: String): Result<Unit> {
        return runCatching {
            securityVault.updatePin(newPin)
            _hasPinConfigured.value = true
            showMessage("PIN updated successfully")
        }
    }

    fun clearSecurityPin() {
        securityVault.clearSecurityConfig()
        _hasPinConfigured.value = false
        _securityQuestion.value = null
        _latestBackupRecoveryKey.value = null
        _isDesktopLocked.value = false
        _authGate.value = null
        showMessage("Launcher PIN removed")
    }

    fun lockVaultSession() {
        _isVaultUnlocked.value = false
        _galleryPrivateUnlocked.value = false
        _openWindows.value.filter { it.type == WindowType.PRIVATE_VAULT }.forEach {
            closeWindow(it.id)
        }
        showMessage("Private Vault locked")
    }

    // ---- App Hiding (Private Apps) ----
    fun hideApp(app: InstalledApp) {
        viewModelScope.launch {
            desktopRepository.hideApp(app)
            // Also close any open External App Host window for that package
            _openWindows.value.filter { it.type == WindowType.EXTERNAL_APP_HOST && it.appPackage == app.packageName }
                .forEach { closeWindow(it.id) }
            showMessage("${app.label} moved to Private Vault")
        }
    }

    fun unhideApp(componentKey: String) {
        viewModelScope.launch {
            desktopRepository.unhideApp(componentKey)
            showMessage("App restored to Launcher & App Drawer")
        }
    }

    // ---- App Launching & Icons ----
    suspend fun loadAppIcon(packageName: String, activityName: String): ImageBitmap? =
        appRepository.loadAppIcon(packageName, activityName)

    fun clearIconCache() {
        appRepository.clearIconCache()
        showMessage("App icon cache cleared to free memory")
    }

    fun launchInstalledApp(app: InstalledApp) {
        openAppInDesktopOrMobileMode(app)
    }

    fun openAppInDesktopOrMobileMode(app: InstalledApp, forceDirectLaunch: Boolean = false) {
        closeAllFlyouts()
        if (forceDirectLaunch || settings.value.launcherMode == LauncherMode.MOBILE) {
            launchAppDirectly(app.packageName, app.activityName, app.label, preferFreeform = false)
            return
        }

        // Desktop Mode: open or focus a Desktop App Host window, plus freeform launch when enabled
        val existing = _openWindows.value.firstOrNull {
            it.type == WindowType.EXTERNAL_APP_HOST && it.appPackage == app.packageName
        }
        if (existing != null) {
            focusWindow(existing.id)
        } else {
            val count = _openWindows.value.size
            val winId = "win_APP_${UUID.randomUUID().toString().take(6)}"
            val win = DesktopWindow(
                id = winId,
                type = WindowType.EXTERNAL_APP_HOST,
                title = app.label,
                subtitle = app.packageName,
                appPackage = app.packageName,
                appActivity = app.activityName,
                xOffsetDp = 36f + (count % 5) * 20f,
                yOffsetDp = 18f + (count % 4) * 16f,
                widthDp = 560f,
                heightDp = 360f,
                zIndex = ++nextZIndex
            )
            _openWindows.update { it + win }
            _activeWindowId.value = winId
        }

        if (settings.value.autoLaunchAppInDesktopMode) {
            launchAppDirectly(
                app.packageName,
                app.activityName,
                app.label,
                preferFreeform = settings.value.preferFreeformLaunch
            )
        }
    }

    fun launchAppDirectly(
        packageName: String,
        activityName: String,
        label: String,
        preferFreeform: Boolean = settings.value.preferFreeformLaunch
    ) {
        closeAllFlyouts()
        viewModelScope.launch {
            val ok = appRepository.launchApp(
                packageName = packageName,
                activityName = activityName,
                preferFreeform = preferFreeform
            )
            if (!ok) {
                showMessage("Unable to open $label")
            }
        }
    }

    fun launchPackageShortcut(packageName: String, activityName: String?, fallbackLabel: String) {
        closeAllFlyouts()
        val matched = installedApps.value.firstOrNull {
            it.packageName == packageName && (activityName == null || it.activityName == activityName)
        } ?: installedApps.value.firstOrNull { it.packageName == packageName }

        if (matched != null) {
            openAppInDesktopOrMobileMode(matched)
        } else if (activityName != null) {
            launchAppDirectly(packageName, activityName, fallbackLabel)
        } else {
            showMessage("$fallbackLabel is no longer installed")
        }
    }

    fun openAppInfo(packageName: String) {
        closeAllFlyouts()
        appRepository.openAppInfo(packageName)
    }

    fun openDefaultHomeSettings() {
        closeAllFlyouts()
        appRepository.openDefaultHomeSettings()
    }

    fun createRequestHomeRoleIntent(): Intent? = appRepository.createRequestHomeRoleIntent()

    fun openAndroidSystemSettings(action: String) {
        closeAllFlyouts()
        val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        val ok = runCatching {
            getApplication<Application>().startActivity(intent)
            true
        }.getOrDefault(false)
        if (!ok) {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            runCatching { getApplication<Application>().startActivity(fallback) }
        }
    }

    // ---- Desktop Icons & Recycle Bin ----
    fun openDesktopItem(item: DesktopItem) {
        closeAllFlyouts()
        if (_movingDesktopItemId.value != null) {
            _movingDesktopItemId.value = null
            return
        }
        when (item.type) {
            DesktopItemType.THIS_PC -> openWindow(WindowType.FILE_EXPLORER, "This PC")
            DesktopItemType.PC_SETTINGS -> openWindow(WindowType.PC_SETTINGS, "PC Settings")
            DesktopItemType.RECYCLE_BIN -> openWindow(WindowType.RECYCLE_BIN, "Recycle Bin")
            DesktopItemType.TASK_MONITOR -> openWindow(WindowType.TASK_MONITOR, "Task Manager")
            DesktopItemType.GALLERY -> openWindow(WindowType.GALLERY, "Gallery")
            DesktopItemType.FOLDER -> openWindow(WindowType.DESKTOP_FOLDER, item.title, folderId = item.id)
            DesktopItemType.FILE -> {
                val rel = item.targetPath ?: return
                val file = fileRepository.resolveRelativeWorkspaceFile(rel)
                if (file.exists()) {
                    openNotepadWindow(file.name, file.absolutePath, isSaf = false)
                } else {
                    openWindow(WindowType.FILE_EXPLORER, "File Explorer")
                }
            }
            DesktopItemType.APP_SHORTCUT -> {
                val pkg = item.targetPackage ?: return
                launchPackageShortcut(pkg, item.targetActivity, item.title)
            }
        }
    }

    fun startMovingDesktopItem(itemId: String) {
        _movingDesktopItemId.value = itemId
        showMessage("Tap any desktop cell to place icon")
    }

    fun cancelMovingDesktopItem() {
        _movingDesktopItemId.value = null
    }

    fun moveDesktopItemToGrid(itemId: String, col: Int, row: Int) {
        viewModelScope.launch {
            desktopRepository.moveDesktopItemToGrid(itemId, col, row)
            _movingDesktopItemId.value = null
        }
    }

    fun createDesktopFolder(name: String, parentFolderId: String? = null) {
        viewModelScope.launch {
            desktopRepository.createDesktopFolder(name, parentFolderId)
        }
    }

    fun createDesktopTextFile(name: String, parentFolderId: String? = null) {
        viewModelScope.launch {
            val clean = name.trim().ifEmpty { "New Note" }.let { if (it.contains('.')) it else "$it.txt" }
            val docsDir = fileRepository.getSectionPath(ExplorerRootSection.DOCUMENTS)
            fileRepository.createTextFile(docsDir, clean, "", isSaf = false).onSuccess { absPath ->
                val relPath = "Documents/${File(absPath).name}"
                desktopRepository.createDesktopFileShortcut(File(absPath).name, relPath, parentFolderId)
                openNotepadWindow(File(absPath).name, absPath, isSaf = false)
            }.onFailure {
                showMessage("Failed to create file: ${it.message}")
            }
        }
    }

    fun addAppToDesktop(app: InstalledApp) {
        viewModelScope.launch {
            desktopRepository.addAppShortcutToDesktop(app)
            showMessage("Added ${app.label} to Desktop")
        }
    }

    fun renameDesktopItem(id: String, newTitle: String) {
        viewModelScope.launch {
            desktopRepository.renameDesktopItem(id, newTitle)
        }
    }

    fun autoArrangeDesktop(maxRows: Int = 5, sortByName: Boolean = false) {
        viewModelScope.launch {
            desktopRepository.autoArrangeDesktop(maxRows, sortByName)
            showMessage(if (sortByName) "Desktop icons sorted" else "Desktop icons arranged")
        }
    }

    fun moveDesktopItemToRecycleBin(item: DesktopItem) {
        viewModelScope.launch {
            desktopRepository.moveToRecycleBin(item)
            showMessage("Moved \"${item.title}\" to Recycle Bin")
        }
    }

    fun restoreFromRecycleBin(item: RecycleBinItem) {
        viewModelScope.launch {
            desktopRepository.restoreFromRecycleBin(item)
            showMessage("Restored \"${item.title}\" to Desktop")
        }
    }

    fun deletePermanentlyFromRecycleBin(id: String) {
        viewModelScope.launch {
            desktopRepository.deletePermanentlyFromRecycleBin(id)
        }
    }

    fun emptyRecycleBin() {
        viewModelScope.launch {
            desktopRepository.emptyRecycleBin()
            showMessage("Recycle Bin emptied")
        }
    }

    fun resetDefaultDesktopIcons() {
        viewModelScope.launch {
            desktopRepository.resetDefaultDesktop(installedApps.value)
            showMessage("Default desktop shortcuts restored")
        }
    }

    fun togglePinToStart(app: InstalledApp) {
        viewModelScope.launch {
            desktopRepository.togglePinToStart(app)
        }
    }

    fun togglePinToTaskbar(app: InstalledApp) {
        viewModelScope.launch {
            desktopRepository.togglePinToTaskbar(app)
        }
    }

    // ---- Gallery Operations ----
    fun createGalleryAlbum(name: String, isPrivate: Boolean) {
        viewModelScope.launch {
            galleryRepository.createAlbum(name, isPrivate)
            showMessage("Album \"$name\" created")
        }
    }

    fun renameGalleryAlbum(albumId: String, newName: String) {
        viewModelScope.launch {
            galleryRepository.renameAlbum(albumId, newName)
            showMessage("Album renamed")
        }
    }

    fun deleteGalleryAlbum(albumId: String) {
        viewModelScope.launch {
            galleryRepository.deleteAlbum(albumId)
            showMessage("Album removed (items moved safely)")
        }
    }

    fun importGalleryUris(uris: List<Uri>, targetAlbumId: String, markPrivate: Boolean = false) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            galleryRepository.importMediaUris(uris, targetAlbumId, markPrivate)
                .onSuccess { items ->
                    showMessage("Imported ${items.size} item(s) to Gallery")
                }
                .onFailure {
                    showMessage("Import failed: ${it.message}")
                }
        }
    }

    fun moveMediaToAlbum(mediaId: String, targetAlbumId: String) {
        viewModelScope.launch {
            galleryRepository.moveMediaToAlbum(mediaId, targetAlbumId)
            showMessage("Moved item to album")
        }
    }

    fun setMediaPrivate(mediaId: String, makePrivate: Boolean) {
        viewModelScope.launch {
            galleryRepository.setMediaPrivate(mediaId, makePrivate)
            showMessage(if (makePrivate) "Moved to Private Safe" else "Restored from Private Safe")
        }
    }

    fun renameGalleryMedia(mediaId: String, newName: String) {
        viewModelScope.launch {
            galleryRepository.renameMedia(mediaId, newName)
        }
    }

    fun deleteGalleryMedia(mediaId: String) {
        viewModelScope.launch {
            galleryRepository.deleteMedia(mediaId)
            showMessage("Deleted from PC Gallery")
        }
    }

    fun exportGalleryMediaToUri(item: GalleryMediaItem, destUri: Uri) {
        viewModelScope.launch {
            galleryRepository.exportMediaToUri(item, destUri)
                .onSuccess { showMessage("Exported \"${item.displayName}\"") }
                .onFailure { showMessage("Export failed: ${it.message}") }
        }
    }

    // ---- Window Management ----
    fun openWindow(
        type: WindowType,
        title: String,
        folderId: String? = null,
        initialSection: ExplorerRootSection? = null
    ) {
        closeAllFlyouts()

        val existing = _openWindows.value.firstOrNull { win ->
            when (type) {
                WindowType.PC_SETTINGS,
                WindowType.RECYCLE_BIN,
                WindowType.TASK_MONITOR,
                WindowType.GALLERY,
                WindowType.PRIVATE_VAULT -> win.type == type
                WindowType.DESKTOP_FOLDER -> win.type == type && win.folderId == folderId
                WindowType.FILE_EXPLORER -> win.type == type
                WindowType.NOTEPAD, WindowType.EXTERNAL_APP_HOST -> false
            }
        }

        if (existing != null) {
            focusWindow(existing.id)
            if (type == WindowType.FILE_EXPLORER && initialSection != null) {
                navigateExplorerToSection(initialSection)
            }
            return
        }

        val count = _openWindows.value.size
        val newId = "win_${type.name}_${UUID.randomUUID().toString().take(6)}"
        val defaultDims = when (type) {
            WindowType.FILE_EXPLORER -> 640f to 360f
            WindowType.PC_SETTINGS -> 660f to 370f
            WindowType.RECYCLE_BIN -> 520f to 330f
            WindowType.DESKTOP_FOLDER -> 500f to 320f
            WindowType.NOTEPAD -> 520f to 340f
            WindowType.TASK_MONITOR -> 560f to 350f
            WindowType.GALLERY -> 680f to 380f
            WindowType.PRIVATE_VAULT -> 580f to 360f
            WindowType.EXTERNAL_APP_HOST -> 560f to 360f
        }
        val window = DesktopWindow(
            id = newId,
            type = type,
            title = title,
            folderId = folderId,
            xOffsetDp = 20f + (count % 4) * 22f,
            yOffsetDp = 12f + (count % 4) * 18f,
            widthDp = defaultDims.first,
            heightDp = defaultDims.second,
            isMinimized = false,
            isMaximized = false,
            zIndex = ++nextZIndex
        )
        _openWindows.update { it + window }
        _activeWindowId.value = newId

        if (type == WindowType.FILE_EXPLORER) {
            if (initialSection != null) {
                navigateExplorerToSection(initialSection)
            } else {
                navigateExplorerToThisPc()
            }
        }
    }

    fun openNotepadWindow(title: String, pathOrUri: String, isSaf: Boolean) {
        closeAllFlyouts()
        val existingSession = _notepadSessions.value.values.firstOrNull { it.pathOrUri == pathOrUri }
        if (existingSession != null) {
            focusWindow(existingSession.windowId)
            return
        }

        viewModelScope.launch {
            val content = fileRepository.readTextFile(pathOrUri, isSaf).getOrElse {
                showMessage("Could not open $title: ${it.message}")
                return@launch
            }
            val winId = "win_NOTEPAD_${UUID.randomUUID().toString().take(6)}"
            val count = _openWindows.value.size
            val win = DesktopWindow(
                id = winId,
                type = WindowType.NOTEPAD,
                title = "$title - Notepad",
                fileUriOrPath = pathOrUri,
                xOffsetDp = 28f + (count % 4) * 20f,
                yOffsetDp = 16f + (count % 4) * 18f,
                widthDp = 520f,
                heightDp = 340f,
                zIndex = ++nextZIndex
            )
            _notepadSessions.update {
                it + (winId to NotepadState(winId, title, pathOrUri, isSaf, content, isDirty = false))
            }
            _openWindows.update { it + win }
            _activeWindowId.value = winId
        }
    }

    fun updateNotepadContent(windowId: String, newText: String) {
        _notepadSessions.update { map ->
            val current = map[windowId] ?: return@update map
            map + (windowId to current.copy(content = newText, isDirty = true))
        }
    }

    fun saveNotepad(windowId: String) {
        val session = _notepadSessions.value[windowId] ?: return
        viewModelScope.launch {
            fileRepository.writeTextFile(session.pathOrUri, session.content, session.isSaf)
                .onSuccess {
                    _notepadSessions.update { map ->
                        val cur = map[windowId] ?: return@update map
                        map + (windowId to cur.copy(isDirty = false))
                    }
                    showMessage("Saved ${session.title}")
                    refreshExplorerCurrentDir()
                }
                .onFailure {
                    showMessage("Save failed: ${it.message}")
                }
        }
    }

    fun focusWindow(windowId: String) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId) win.copy(isMinimized = false, zIndex = ++nextZIndex)
                else win
            }
        }
        _activeWindowId.value = windowId
    }

    fun toggleMinimizeFromTaskbar(windowId: String) {
        val target = _openWindows.value.firstOrNull { it.id == windowId } ?: return
        if (target.isMinimized || _activeWindowId.value != windowId) {
            focusWindow(windowId)
        } else {
            minimizeWindow(windowId)
        }
    }

    fun minimizeWindow(windowId: String) {
        _openWindows.update { list ->
            list.map { if (it.id == windowId) it.copy(isMinimized = true) else it }
        }
        if (_activeWindowId.value == windowId) {
            _activeWindowId.value = _openWindows.value
                .filter { it.id != windowId && !it.isMinimized }
                .maxByOrNull { it.zIndex }?.id
        }
    }

    fun toggleMaximizeWindow(windowId: String) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId) {
                    win.copy(isMaximized = !win.isMaximized, isMinimized = false, zIndex = ++nextZIndex)
                } else win
            }
        }
        _activeWindowId.value = windowId
    }

    fun moveWindow(windowId: String, dxDp: Float, dyDp: Float) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId && !win.isMaximized) {
                    win.copy(
                        xOffsetDp = (win.xOffsetDp + dxDp).coerceAtLeast(0f),
                        yOffsetDp = (win.yOffsetDp + dyDp).coerceAtLeast(0f)
                    )
                } else win
            }
        }
    }

    fun resizeWindow(windowId: String, dwDp: Float, dhDp: Float) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId && !win.isMaximized) {
                    win.copy(
                        widthDp = (win.widthDp + dwDp).coerceIn(280f, 1400f),
                        heightDp = (win.heightDp + dhDp).coerceIn(200f, 960f)
                    )
                } else win
            }
        }
    }

    fun closeWindow(windowId: String) {
        val target = _openWindows.value.firstOrNull { it.id == windowId }
        _openWindows.update { list -> list.filterNot { it.id == windowId } }
        _notepadSessions.update { it - windowId }
        if (target?.type == WindowType.PRIVATE_VAULT) {
            _isVaultUnlocked.value = false
        }
        if (_activeWindowId.value == windowId) {
            _activeWindowId.value = _openWindows.value.filterNot { it.isMinimized }.maxByOrNull { it.zIndex }?.id
        }
    }

    fun closeTopActiveWindowIfAny(): Boolean {
        val top = _openWindows.value.filterNot { it.isMinimized }.maxByOrNull { it.zIndex } ?: return false
        closeWindow(top.id)
        return true
    }

    // ---- File Explorer Navigation & Operations ----
    fun navigateExplorerToThisPc() {
        _explorerState.update {
            it.copy(
                currentLocationLabel = "This PC",
                currentPathOrUri = null,
                currentIsSaf = false,
                breadcrumbs = listOf("This PC" to null),
                files = emptyList(),
                isLoading = false
            )
        }
        systemMonitor.refreshClockAndMetrics()
    }

    fun navigateExplorerToSection(section: ExplorerRootSection) {
        if (section == ExplorerRootSection.THIS_PC) {
            navigateExplorerToThisPc()
            return
        }
        val path = fileRepository.getSectionPath(section)
        navigateExplorerToLocalPath(path, section.label)
    }

    fun navigateExplorerToLocalPath(path: String, labelOverride: String? = null) {
        viewModelScope.launch {
            _explorerState.update { it.copy(isLoading = true) }
            val files = fileRepository.listLocalDirectory(path)
            val rootPath = fileRepository.getWorkspaceRootPath()
            val rel = path.removePrefix(rootPath).trim('/')
            val crumbs = mutableListOf<Pair<String, String?>>("This PC" to null)
            if (rel.isNotEmpty()) {
                var accum = rootPath
                rel.split('/').forEach { seg ->
                    accum = "$accum/$seg"
                    crumbs.add(seg to accum)
                }
            }
            val label = labelOverride ?: File(path).name.ifEmpty { "Local Storage" }
            _explorerState.update {
                it.copy(
                    currentLocationLabel = label,
                    currentPathOrUri = path,
                    currentIsSaf = false,
                    breadcrumbs = crumbs,
                    files = files,
                    isLoading = false
                )
            }
        }
    }

    fun navigateExplorerToSafUri(uriString: String, label: String) {
        viewModelScope.launch {
            _explorerState.update { it.copy(isLoading = true) }
            val files = fileRepository.listSafDirectory(uriString)
            val existingCrumbs = _explorerState.value.breadcrumbs
            val updatedCrumbs = if (existingCrumbs.any { it.second == uriString }) {
                existingCrumbs.takeWhile { it.second != uriString } + (label to uriString)
            } else if (_explorerState.value.currentIsSaf) {
                existingCrumbs + (label to uriString)
            } else {
                listOf("This PC" to null, label to uriString)
            }
            _explorerState.update {
                it.copy(
                    currentLocationLabel = label,
                    currentPathOrUri = uriString,
                    currentIsSaf = true,
                    breadcrumbs = updatedCrumbs,
                    files = files,
                    isLoading = false
                )
            }
        }
    }

    fun navigateExplorerUp() {
        val crumbs = _explorerState.value.breadcrumbs
        if (crumbs.size <= 1) return
        val parent = crumbs[crumbs.size - 2]
        val parentPath = parent.second
        if (parentPath == null) {
            navigateExplorerToThisPc()
        } else if (parentPath.startsWith("content://")) {
            navigateExplorerToSafUri(parentPath, parent.first)
        } else {
            navigateExplorerToLocalPath(parentPath, parent.first)
        }
    }

    fun refreshExplorerCurrentDir() {
        val state = _explorerState.value
        val path = state.currentPathOrUri
        if (path == null) {
            systemMonitor.refreshClockAndMetrics()
        } else if (state.currentIsSaf) {
            navigateExplorerToSafUri(path, state.currentLocationLabel)
        } else {
            navigateExplorerToLocalPath(path, state.currentLocationLabel)
        }
    }

    fun setExplorerSearch(query: String) {
        _explorerState.update { it.copy(searchQuery = query) }
    }

    fun toggleExplorerViewMode() {
        _explorerState.update { it.copy(isGridView = !it.isGridView) }
    }

    fun mountSafTreeUri(uri: Uri) {
        viewModelScope.launch {
            fileRepository.addSafMount(uri)
                .onSuccess { mount ->
                    showMessage("Mounted \"${mount.displayName}\"")
                    pushNotification("Drive Mounted", "Connected ${mount.displayName} via Storage Access Framework.")
                    navigateExplorerToSafUri(mount.treeUri, mount.displayName)
                }
                .onFailure {
                    showMessage("Could not mount folder: ${it.message}")
                }
        }
    }

    fun unmountSafDrive(mount: SafMount) {
        viewModelScope.launch {
            fileRepository.removeSafMount(mount)
            if (_explorerState.value.currentPathOrUri == mount.treeUri) {
                navigateExplorerToThisPc()
            }
            showMessage("Disconnected \"${mount.displayName}\"")
        }
    }

    fun openFileNode(node: FileNode) {
        if (node.isDirectory) {
            if (node.isSafDocument) {
                navigateExplorerToSafUri(node.pathOrUri, node.name)
            } else {
                navigateExplorerToLocalPath(node.pathOrUri, node.name)
            }
        } else if (fileRepository.isTextEditable(node.name, node.mimeType)) {
            openNotepadWindow(node.name, node.pathOrUri, node.isSafDocument)
        } else {
            fileRepository.openNodeExternally(node).onFailure {
                showMessage("No compatible Android app found for ${node.name}")
            }
        }
    }

    fun openFileNodeWithAndroidApp(node: FileNode) {
        if (node.isDirectory) return
        fileRepository.openNodeExternally(node).onFailure {
            showMessage("No compatible Android app found for ${node.name}")
        }
    }

    fun createFolderInExplorer(name: String) {
        val state = _explorerState.value
        val parent = state.currentPathOrUri ?: fileRepository.getSectionPath(ExplorerRootSection.DOCUMENTS)
        val isSaf = state.currentPathOrUri != null && state.currentIsSaf
        viewModelScope.launch {
            fileRepository.createFolder(parent, name, isSaf)
                .onSuccess {
                    refreshExplorerCurrentDir()
                    showMessage("Folder created")
                }
                .onFailure { showMessage(it.message ?: "Could not create folder") }
        }
    }

    fun createTextFileInExplorer(name: String) {
        val state = _explorerState.value
        val parent = state.currentPathOrUri ?: fileRepository.getSectionPath(ExplorerRootSection.DOCUMENTS)
        val isSaf = state.currentPathOrUri != null && state.currentIsSaf
        viewModelScope.launch {
            fileRepository.createTextFile(parent, name, "", isSaf)
                .onSuccess { path ->
                    refreshExplorerCurrentDir()
                    openNotepadWindow(name, path, isSaf)
                }
                .onFailure { showMessage(it.message ?: "Could not create file") }
        }
    }

    fun renameFileNode(node: FileNode, newName: String) {
        viewModelScope.launch {
            fileRepository.renameNode(node, newName)
                .onSuccess {
                    refreshExplorerCurrentDir()
                    showMessage("Renamed to $newName")
                }
                .onFailure { showMessage(it.message ?: "Rename failed") }
        }
    }

    fun deleteFileNode(node: FileNode) {
        viewModelScope.launch {
            fileRepository.deleteNode(node)
                .onSuccess {
                    refreshExplorerCurrentDir()
                    showMessage("Deleted ${node.name}")
                }
                .onFailure { showMessage(it.message ?: "Delete failed") }
        }
    }

    fun setExplorerClipboard(node: FileNode, isCut: Boolean) {
        _explorerState.update { it.copy(clipboard = FileClipboard(node, isCut)) }
        showMessage(if (isCut) "Cut \"${node.name}\"" else "Copied \"${node.name}\"")
    }

    fun pasteExplorerClipboard() {
        val state = _explorerState.value
        val clip = state.clipboard ?: return
        val destDir = state.currentPathOrUri ?: return
        viewModelScope.launch {
            fileRepository.copyOrMoveNode(clip.node, destDir, state.currentIsSaf, clip.isCut)
                .onSuccess {
                    if (clip.isCut) _explorerState.update { it.copy(clipboard = null) }
                    refreshExplorerCurrentDir()
                    showMessage(if (clip.isCut) "Moved ${clip.node.name}" else "Copied ${clip.node.name}")
                }
                .onFailure { showMessage(it.message ?: "Paste failed") }
        }
    }

    // ---- Hardware Controls ----
    fun setMediaVolumePercent(percent: Int) = systemMonitor.setMediaVolumePercent(percent)
    fun setRingVolumePercent(percent: Int) = systemMonitor.setRingVolumePercent(percent)
    fun toggleMute() = systemMonitor.toggleMute()

    // ---- Theme Presets, Custom Profiles & Import/Export ----
    fun applyThemePreset(preset: DesktopThemePreset) {
        updateSettings { cur ->
            if (preset == DesktopThemePreset.CUSTOM) {
                cur.copy(themePreset = DesktopThemePreset.CUSTOM)
            } else {
                cur.copy(
                    themePreset = preset,
                    themeMode = if (preset.defaultDark) ThemeMode.DARK else ThemeMode.LIGHT,
                    accentKey = preset.defaultAccentKey,
                    customAccentArgb = null,
                    customTaskbarArgb = null,
                    wallpaperId = preset.defaultWallpaperId,
                    customWallpaperUri = null,
                    taskbarPosition = preset.defaultTaskbarPos,
                    taskbarStyle = preset.defaultTaskbarStyle,
                    cornerStyle = preset.defaultCornerStyle,
                    windowAppearance = preset.defaultWindowAppearance,
                    fontStyle = preset.defaultFontStyle,
                    iconPack = preset.defaultIconPack
                )
            }
        }
        showMessage("Applied ${preset.label} theme")
    }

    fun saveCurrentAsCustomTheme(name: String) {
        val cleanName = name.trim().ifEmpty { "My Desktop Theme" }
        val json = settings.value.copy(themePreset = DesktopThemePreset.CUSTOM).toThemeJson()
        viewModelScope.launch {
            dao.upsertSavedTheme(
                SavedThemeEntity(
                    id = "theme_${UUID.randomUUID()}",
                    name = cleanName,
                    themeJson = json,
                    createdAt = System.currentTimeMillis()
                )
            )
            updateSettings { it.copy(themePreset = DesktopThemePreset.CUSTOM) }
            pushNotification("Custom Theme Saved", "Saved theme profile \"$cleanName\".")
            showMessage("Saved custom theme \"$cleanName\"")
        }
    }

    fun applySavedTheme(profile: SavedThemeProfile) {
        runCatching {
            val next = PcSettingsState.applyJsonTo(settings.value, profile.themeJson)
            viewModelScope.launch { settingsStore.update { next } }
            showMessage("Applied \"${profile.name}\"")
        }.onFailure {
            showMessage("Failed to apply saved theme")
        }
    }

    fun deleteSavedTheme(id: String) {
        viewModelScope.launch {
            dao.deleteSavedTheme(id)
            showMessage("Deleted custom theme")
        }
    }

    fun resetAllSettingsToDefaults() {
        updateSettings { PcSettingsState() }
        showMessage("Restored default PC Desktop settings")
        pushNotification("Settings Reset", "All desktop customization settings were restored to defaults.")
    }

    fun exportThemeToUri(uri: Uri) {
        val json = settings.value.toThemeJson()
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray())
                } ?: error("Cannot write destination file")
            }.onSuccess {
                withContext(Dispatchers.Main) {
                    showMessage("Theme settings exported")
                    pushNotification("Theme Exported", "Exported desktop theme configuration.")
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    showMessage("Export failed: ${e.message}")
                }
            }
        }
    }

    fun importThemeFromUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val text = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.bufferedReader()?.use { it.readText() }
                    ?: error("Could not read file")
                val parsed = PcSettingsState.applyJsonTo(settings.value, text)
                settingsStore.update { parsed }
            }.onSuccess {
                withContext(Dispatchers.Main) {
                    showMessage("Theme imported and applied")
                    pushNotification("Theme Imported", "Loaded custom theme configuration from file.")
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    showMessage("Invalid theme file: ${e.message}")
                }
            }
        }
    }

    // ---- PC Settings Mutations ----
    fun setAutoLaunchAppInDesktopMode(enabled: Boolean) = updateSettings { it.copy(autoLaunchAppInDesktopMode = enabled) }
    fun setLockScreenEnabled(enabled: Boolean) = updateSettings { it.copy(lockScreenEnabled = enabled) }
    fun setLockScreenShowClockSeconds(show: Boolean) = updateSettings { it.copy(lockScreenShowClockSeconds = show) }
    fun setLockScreenBiometricEnabled(enabled: Boolean) = updateSettings { it.copy(lockScreenBiometricEnabled = enabled) }
    fun updateLockWallpaperPreset(id: String) = updateSettings { it.copy(lockWallpaperId = id, customLockWallpaperUri = null) }
    fun setCustomLockWallpaperUri(uri: String) = updateSettings { it.copy(customLockWallpaperUri = uri) }
    fun setVaultAccessMethod(method: VaultAccessMethod) = updateSettings { it.copy(vaultAccessMethod = method) }
    fun setVaultSecretPhrase(phrase: String) = updateSettings {
        it.copy(vaultSecretPhrase = phrase.trim().ifEmpty { "//vault" })
    }
    fun setVaultBiometricEnabled(enabled: Boolean) = updateSettings { it.copy(vaultBiometricEnabled = enabled) }

    fun setFullScreenImmersive(enabled: Boolean) = updateSettings { it.copy(fullScreenImmersive = enabled) }
    fun setOrientationMode(mode: OrientationMode) = updateSettings { it.copy(orientationMode = mode) }
    fun toggleOrientationQuick() = updateSettings {
        val next = if (it.orientationMode == OrientationMode.LANDSCAPE) OrientationMode.PORTRAIT else OrientationMode.LANDSCAPE
        it.copy(orientationMode = next)
    }
    fun setDesktopScale(scale: Float) = updateSettings { it.copy(desktopScale = scale.coerceIn(0.8f, 1.25f)) }
    fun setScreenLayout(layout: ScreenLayoutDensity) = updateSettings {
        it.copy(screenLayout = layout, desktopScale = layout.scaleMultiplier)
    }
    fun updateThemeMode(mode: ThemeMode) = updateSettings { it.copy(themeMode = mode) }
    fun updateAccentKey(key: String) = updateSettings { it.copy(accentKey = key, customAccentArgb = null, themePreset = DesktopThemePreset.CUSTOM) }
    fun setCustomAccentColor(argb: Long?) = updateSettings { it.copy(customAccentArgb = argb, themePreset = DesktopThemePreset.CUSTOM) }
    fun setDesktopBackgroundColor(argb: Long) = updateSettings {
        it.copy(desktopBackgroundArgb = argb, themePreset = DesktopThemePreset.CUSTOM)
    }
    fun updateWallpaperPreset(id: String) = updateSettings {
        it.copy(wallpaperId = id, customWallpaperUri = null)
    }
    fun setCustomWallpaperUri(uri: String) = updateSettings { it.copy(customWallpaperUri = uri) }
    fun setWallpaperFit(fit: WallpaperFitOption) = updateSettings { it.copy(wallpaperFit = fit) }
    fun setWallpaperDimAlpha(alpha: Float) = updateSettings { it.copy(wallpaperDimAlpha = alpha.coerceIn(0f, 0.7f)) }
    fun updateIconSize(size: IconSizeOption) = updateSettings { it.copy(iconSize = size) }
    fun setIconScale(scale: Float) = updateSettings { it.copy(iconScale = scale.coerceIn(0.75f, 1.35f)) }
    fun setIconPack(pack: IconPackStyle) = updateSettings { it.copy(iconPack = pack, themePreset = DesktopThemePreset.CUSTOM) }
    fun setShowDesktopIconScrim(show: Boolean) = updateSettings { it.copy(showDesktopIconScrim = show) }
    fun setAutoArrangeGrid(enabled: Boolean) = updateSettings { it.copy(autoArrangeGrid = enabled) }
    fun setShowDesktopClock(show: Boolean) = updateSettings { it.copy(showDesktopClock = show) }
    fun setShowFileExtensions(show: Boolean) = updateSettings { it.copy(showFileExtensions = show) }
    fun updateTaskbarPosition(pos: TaskbarPosition) = updateSettings { it.copy(taskbarPosition = pos) }
    fun updateTaskbarSize(size: TaskbarSizeOption) = updateSettings { it.copy(taskbarSize = size, taskbarHeightOverrideDp = null) }
    fun setTaskbarHeightOverride(dp: Int?) = updateSettings { it.copy(taskbarHeightOverrideDp = dp?.coerceIn(36, 80)) }
    fun setTaskbarIconSpacing(dp: Int) = updateSettings { it.copy(taskbarIconSpacingDp = dp.coerceIn(0, 16)) }
    fun setTaskbarStyle(style: TaskbarStyle) = updateSettings { it.copy(taskbarStyle = style) }
    fun updateTaskbarTransparency(alpha: Float) = updateSettings { it.copy(taskbarTransparency = alpha.coerceIn(0.2f, 1.0f)) }
    fun setCustomTaskbarColor(argb: Long?) = updateSettings {
        it.copy(customTaskbarArgb = argb, taskbarStyle = if (argb != null) TaskbarStyle.CUSTOM else it.taskbarStyle)
    }
    fun setShowTaskbarSearch(show: Boolean) = updateSettings { it.copy(showTaskbarSearch = show) }
    fun setShowTaskbarDate(show: Boolean) = updateSettings { it.copy(showTaskbarDate = show) }
    fun setShowTaskbarNotificationBadge(show: Boolean) = updateSettings { it.copy(showTaskbarNotificationBadge = show) }
    fun setWindowAppearance(appearance: WindowAppearance) = updateSettings { it.copy(windowAppearance = appearance, themePreset = DesktopThemePreset.CUSTOM) }
    fun setCornerStyle(corner: CornerStyle) = updateSettings { it.copy(cornerStyle = corner, themePreset = DesktopThemePreset.CUSTOM) }
    fun setFontStyle(font: FontStyleOption) = updateSettings { it.copy(fontStyle = font, themePreset = DesktopThemePreset.CUSTOM) }
    fun setAnimationsEnabled(enabled: Boolean) = updateSettings { it.copy(animationsEnabled = enabled) }
    fun updateAnimationSpeed(speed: AnimationSpeed) = updateSettings { it.copy(animationSpeed = speed) }
    fun setAnimationEffect(effect: AnimationEffectStyle) = updateSettings { it.copy(animationEffect = effect) }
    fun setBatterySaverMode(enabled: Boolean) = updateSettings {
        it.copy(
            batterySaverMode = enabled,
            animationsEnabled = if (enabled) false else it.animationsEnabled
        )
    }
    fun setHapticFeedbackEnabled(enabled: Boolean) = updateSettings { it.copy(hapticFeedbackEnabled = enabled) }
    fun setShowToastNotifications(show: Boolean) = updateSettings { it.copy(showToastNotifications = show) }
    fun setPreferFreeformLaunch(enabled: Boolean) = updateSettings { it.copy(preferFreeformLaunch = enabled) }
    fun setDefaultShortcut(slot: String, pkg: String?) = updateSettings {
        when (slot) {
            "browser" -> it.copy(defaultBrowserPackage = pkg)
            "files" -> it.copy(defaultFilesPackage = pkg)
            "gallery" -> it.copy(defaultGalleryPackage = pkg)
            "music" -> it.copy(defaultMusicPackage = pkg)
            else -> it
        }
    }

    private fun updateSettings(transform: (PcSettingsState) -> PcSettingsState) {
        viewModelScope.launch {
            settingsStore.update(transform)
        }
    }
}
