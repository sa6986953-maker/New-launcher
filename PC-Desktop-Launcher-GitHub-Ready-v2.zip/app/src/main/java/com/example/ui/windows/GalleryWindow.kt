package com.example.ui.windows

import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PhotoAlbum
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.data.model.GalleryAlbum
import com.example.data.model.GalleryMediaItem
import com.example.data.model.GallerySortOrder
import com.example.data.model.MediaType
import com.example.data.repository.GalleryRepository
import com.example.ui.components.TextInputDialog
import com.example.ui.components.formatBytes
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel
import java.io.File
import java.util.Locale

private enum class GallerySection(val label: String) {
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    ALBUMS("Albums"),
    PRIVATE_SAFE("Private Safe")
}

@Composable
fun GalleryWindow(
    albums: List<GalleryAlbum>,
    mediaItems: List<GalleryMediaItem>,
    privateUnlocked: Boolean,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current
    var activeSection by remember { mutableStateOf(GallerySection.PHOTOS) }
    var selectedAlbumId by remember { mutableStateOf<String?>(null) }
    var isGridView by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var sortOrder by remember { mutableStateOf(GallerySortOrder.NEWEST) }
    var showSortMenu by remember { mutableStateOf(false) }

    var viewerItem by remember { mutableStateOf<GalleryMediaItem?>(null) }
    var showNewAlbumDialog by remember { mutableStateOf(false) }
    var renameAlbumTarget by remember { mutableStateOf<GalleryAlbum?>(null) }
    var moveMediaTarget by remember { mutableStateOf<GalleryMediaItem?>(null) }
    var deleteConfirmTarget by remember { mutableStateOf<GalleryMediaItem?>(null) }
    var pendingExportItem by remember { mutableStateOf<GalleryMediaItem?>(null) }

    val importTargetAlbumId = when {
        selectedAlbumId != null -> selectedAlbumId!!
        activeSection == GallerySection.PRIVATE_SAFE -> GalleryRepository.DEFAULT_ALBUM_PRIVATE_SAFE
        else -> GalleryRepository.DEFAULT_ALBUM_IMPORTS
    }
    val importAsPrivate = activeSection == GallerySection.PRIVATE_SAFE ||
        albums.firstOrNull { it.id == importTargetAlbumId }?.isPrivate == true

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importGalleryUris(uris, importTargetAlbumId, markPrivate = importAsPrivate)
        }
    }

    val exportDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val item = pendingExportItem
        pendingExportItem = null
        if (uri != null && item != null) {
            viewModel.exportGalleryMediaToUri(item, uri)
        }
    }

    val displayedMedia = remember(mediaItems, activeSection, selectedAlbumId, searchQuery, sortOrder, privateUnlocked) {
        val base = when {
            selectedAlbumId != null -> {
                val alb = albums.firstOrNull { it.id == selectedAlbumId }
                if (alb?.isPrivate == true && !privateUnlocked) emptyList()
                else mediaItems.filter { it.albumId == selectedAlbumId }
            }
            activeSection == GallerySection.PHOTOS -> mediaItems.filter { !it.isPrivate && it.mediaType == MediaType.PHOTO }
            activeSection == GallerySection.VIDEOS -> mediaItems.filter { !it.isPrivate && it.mediaType == MediaType.VIDEO }
            activeSection == GallerySection.PRIVATE_SAFE -> if (privateUnlocked) mediaItems.filter { it.isPrivate } else emptyList()
            else -> mediaItems.filter { !it.isPrivate }
        }
        val searched = if (searchQuery.isBlank()) base else base.filter {
            it.displayName.contains(searchQuery, ignoreCase = true)
        }
        when (sortOrder) {
            GallerySortOrder.NEWEST -> searched.sortedByDescending { it.addedAt }
            GallerySortOrder.OLDEST -> searched.sortedBy { it.addedAt }
            GallerySortOrder.NAME_ASC -> searched.sortedBy { it.displayName.lowercase() }
            GallerySortOrder.SIZE_DESC -> searched.sortedByDescending { it.sizeBytes }
        }
    }

    Column(modifier = Modifier.fillMaxSize().testTag("gallery_window")) {
        // Gallery Section Tabs + Toolbar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .background(pcPalette.windowHeader.copy(alpha = 0.55f))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            GallerySection.entries.forEach { sec ->
                FilterChip(
                    selected = activeSection == sec && selectedAlbumId == null,
                    onClick = {
                        activeSection = sec
                        selectedAlbumId = null
                        if (sec == GallerySection.PRIVATE_SAFE && !privateUnlocked) {
                            viewModel.requestPrivateGalleryAccess()
                        }
                    },
                    label = { Text(sec.label) },
                    leadingIcon = {
                        Icon(
                            imageVector = when (sec) {
                                GallerySection.PHOTOS -> Icons.Rounded.Photo
                                GallerySection.VIDEOS -> Icons.Rounded.VideoLibrary
                                GallerySection.ALBUMS -> Icons.Rounded.PhotoAlbum
                                GallerySection.PRIVATE_SAFE -> if (privateUnlocked) Icons.Rounded.LockOpen else Icons.Rounded.Lock
                            },
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    modifier = Modifier.testTag("gallery_tab_${sec.name}")
                )
            }

            Spacer(Modifier.width(4.dp))

            Button(
                onClick = {
                    val mediaFilter = when (activeSection) {
                        GallerySection.VIDEOS -> ActivityResultContracts.PickVisualMedia.VideoOnly
                        GallerySection.PHOTOS -> ActivityResultContracts.PickVisualMedia.ImageOnly
                        else -> ActivityResultContracts.PickVisualMedia.ImageAndVideo
                    }
                    photoPickerLauncher.launch(PickVisualMediaRequest(mediaFilter))
                },
                modifier = Modifier.testTag("gallery_import_button")
            ) {
                Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Import")
            }

            if (activeSection == GallerySection.ALBUMS) {
                OutlinedButton(
                    onClick = { showNewAlbumDialog = true },
                    modifier = Modifier.testTag("gallery_new_album_button")
                ) {
                    Icon(Icons.Rounded.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("New Album")
                }
            }
        }

        // Search + Sort + Grid/List Controls
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            if (selectedAlbumId != null) {
                val albumName = albums.firstOrNull { it.id == selectedAlbumId }?.name ?: "Album"
                IconButton(onClick = { selectedAlbumId = null }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to Albums")
                }
                Text(albumName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search media") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )

            Box {
                IconButton(onClick = { showSortMenu = true }) {
                    Icon(Icons.Rounded.Sort, contentDescription = "Sort media")
                }
                DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                    GallerySortOrder.entries.forEach { order ->
                        DropdownMenuItem(
                            text = { Text(order.label, fontWeight = if (sortOrder == order) FontWeight.Bold else FontWeight.Normal) },
                            onClick = {
                                sortOrder = order
                                showSortMenu = false
                            }
                        )
                    }
                }
            }

            IconButton(
                onClick = { isGridView = !isGridView },
                modifier = Modifier.testTag("gallery_view_toggle")
            ) {
                Icon(
                    imageVector = if (isGridView) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                    contentDescription = if (isGridView) "Switch to List View" else "Switch to Grid View"
                )
            }
        }

        HorizontalDivider(color = pcPalette.windowBorder)

        // Content Area
        when {
            activeSection == GallerySection.PRIVATE_SAFE && !privateUnlocked -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize().padding(24.dp)
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(52.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Private Safe is Locked", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Authenticate with your PIN or biometrics to view protected photos and videos.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = { viewModel.requestPrivateGalleryAccess() },
                        modifier = Modifier.testTag("gallery_unlock_private_button")
                    ) {
                        Text("Unlock Private Safe")
                    }
                }
            }

            activeSection == GallerySection.ALBUMS && selectedAlbumId == null -> {
                val visibleAlbums = albums.filter { !it.isPrivate || privateUnlocked }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 148.dp),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(visibleAlbums, key = { it.id }) { album ->
                        val count = mediaItems.count { it.albumId == album.id }
                        val cover = mediaItems.firstOrNull { it.albumId == album.id }
                        var showAlbumMenu by remember { mutableStateOf(false) }
                        val isProtectedDefault = album.id == GalleryRepository.DEFAULT_ALBUM_IMPORTS ||
                            album.id == GalleryRepository.DEFAULT_ALBUM_PRIVATE_SAFE

                        Box {
                            Surface(
                                shape = RoundedCornerShape(pcPalette.cardCornerDp),
                                color = pcPalette.windowCard,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
                                    .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                                    .clickable { selectedAlbumId = album.id }
                            ) {
                                Column {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(96.dp)
                                            .background(pcPalette.windowHeader.copy(alpha = 0.5f))
                                    ) {
                                        if (cover != null) {
                                            AsyncImage(
                                                model = File(cover.filePath),
                                                contentDescription = album.name,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        } else {
                                            Icon(
                                                imageVector = if (album.isPrivate) Icons.Rounded.Lock else Icons.Rounded.PhotoLibrary,
                                                contentDescription = null,
                                                tint = pcPalette.accent,
                                                modifier = Modifier.size(34.dp)
                                            )
                                        }
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(album.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("$count item(s)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        if (!isProtectedDefault) {
                                            IconButton(onClick = { showAlbumMenu = true }, modifier = Modifier.size(28.dp)) {
                                                Icon(Icons.Rounded.MoreVert, contentDescription = "Album options", modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                            DropdownMenu(expanded = showAlbumMenu, onDismissRequest = { showAlbumMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Rename Album") },
                                    leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                                    onClick = { showAlbumMenu = false; renameAlbumTarget = album }
                                )
                                DropdownMenuItem(
                                    text = { Text("Delete Album", color = MaterialTheme.colorScheme.error) },
                                    leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                    onClick = { showAlbumMenu = false; viewModel.deleteGalleryAlbum(album.id) }
                                )
                            }
                        }
                    }
                }
            }

            displayedMedia.isEmpty() -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize().padding(24.dp)
                ) {
                    Icon(
                        imageVector = if (activeSection == GallerySection.VIDEOS) Icons.Rounded.VideoLibrary else Icons.Rounded.PhotoLibrary,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("No media items here yet", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Tap Import to add photos or videos safely via Android Photo Picker into your PC Gallery.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            isGridView -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 112.dp),
                    contentPadding = PaddingValues(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(displayedMedia, key = { it.id }) { item ->
                        MediaGridTile(
                            item = item,
                            onClick = { viewerItem = item },
                            onMoveAlbum = { moveMediaTarget = item },
                            onTogglePrivate = { viewModel.setMediaPrivate(item.id, !item.isPrivate) },
                            onExport = {
                                pendingExportItem = item
                                exportDocLauncher.launch(item.displayName)
                            },
                            onDelete = { deleteConfirmTarget = item }
                        )
                    }
                }
            }

            else -> {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(displayedMedia, key = { it.id }) { item ->
                        MediaListRow(
                            item = item,
                            onClick = { viewerItem = item },
                            onMoveAlbum = { moveMediaTarget = item },
                            onTogglePrivate = { viewModel.setMediaPrivate(item.id, !item.isPrivate) },
                            onExport = {
                                pendingExportItem = item
                                exportDocLauncher.launch(item.displayName)
                            },
                            onDelete = { deleteConfirmTarget = item }
                        )
                    }
                }
            }
        }
    }

    // Full-screen Photo Viewer or Video Player
    viewerItem?.let { item ->
        if (item.mediaType == MediaType.VIDEO) {
            GalleryVideoPlayerDialog(
                item = item,
                onDismiss = { viewerItem = null }
            )
        } else {
            GalleryPhotoViewerDialog(
                item = item,
                onDismiss = { viewerItem = null },
                onTogglePrivate = {
                    viewModel.setMediaPrivate(item.id, !item.isPrivate)
                    viewerItem = null
                },
                onExport = {
                    pendingExportItem = item
                    exportDocLauncher.launch(item.displayName)
                },
                onDelete = {
                    viewerItem = null
                    deleteConfirmTarget = item
                }
            )
        }
    }

    if (showNewAlbumDialog) {
        TextInputDialog(
            title = "New Gallery Album",
            label = "Album name",
            initialValue = "Favorites",
            confirmLabel = "Create",
            onDismiss = { showNewAlbumDialog = false },
            onConfirm = { name ->
                showNewAlbumDialog = false
                viewModel.createGalleryAlbum(name, isPrivate = false)
            }
        )
    }

    renameAlbumTarget?.let { target ->
        TextInputDialog(
            title = "Rename Album",
            label = "Album name",
            initialValue = target.name,
            confirmLabel = "Save",
            onDismiss = { renameAlbumTarget = null },
            onConfirm = { name ->
                renameAlbumTarget = null
                viewModel.renameGalleryAlbum(target.id, name)
            }
        )
    }

    moveMediaTarget?.let { item ->
        AlertDialog(
            onDismissRequest = { moveMediaTarget = null },
            title = { Text("Move \"${item.displayName}\"") },
            text = {
                LazyColumn(modifier = Modifier.height(220.dp)) {
                    items(albums.filter { !it.isPrivate || privateUnlocked }, key = { it.id }) { album ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.moveMediaToAlbum(item.id, album.id)
                                    moveMediaTarget = null
                                }
                                .padding(10.dp)
                        ) {
                            Icon(
                                imageVector = if (album.isPrivate) Icons.Rounded.Lock else Icons.Rounded.PhotoAlbum,
                                contentDescription = null,
                                tint = pcPalette.accent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(album.name, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { moveMediaTarget = null }) { Text("Cancel") }
            }
        )
    }

    deleteConfirmTarget?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteConfirmTarget = null },
            title = { Text("Delete Media Item?") },
            text = {
                Text("Remove \"${item.displayName}\" from your PC Gallery? Original files outside this app are never altered.")
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteGalleryMedia(item.id)
                    deleteConfirmTarget = null
                }) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaGridTile(
    item: GalleryMediaItem,
    onClick: () -> Unit,
    onMoveAlbum: () -> Unit,
    onTogglePrivate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    var showMenu by remember { mutableStateOf(false) }

    Box {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(pcPalette.cardCornerDp))
                .background(pcPalette.windowCard)
                .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = { showMenu = true }
                )
        ) {
            AsyncImage(
                model = File(item.filePath),
                contentDescription = item.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (item.mediaType == MediaType.VIDEO) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PlayCircle, contentDescription = "Video", tint = Color.White, modifier = Modifier.size(26.dp))
                }
                if (item.durationMs > 0L) {
                    Text(
                        text = formatDurationMs(item.durationMs),
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFamily,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(5.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xAA000000))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.align(Alignment.TopEnd).size(28.dp)
            ) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Media Options", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
        MediaContextMenu(
            expanded = showMenu,
            isPrivate = item.isPrivate,
            onDismiss = { showMenu = false },
            onOpen = { showMenu = false; onClick() },
            onMoveAlbum = { showMenu = false; onMoveAlbum() },
            onTogglePrivate = { showMenu = false; onTogglePrivate() },
            onExport = { showMenu = false; onExport() },
            onDelete = { showMenu = false; onDelete() }
        )
    }
}

@Composable
private fun MediaListRow(
    item: GalleryMediaItem,
    onClick: () -> Unit,
    onMoveAlbum: () -> Unit,
    onTogglePrivate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    var showMenu by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(pcPalette.cardCornerDp),
        color = pcPalette.windowCard,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(pcPalette.cardCornerDp))
            .clip(RoundedCornerShape(pcPalette.cardCornerDp))
            .clickable(onClick = onClick)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(10.dp)) {
            AsyncImage(
                model = File(item.filePath),
                contentDescription = item.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(item.displayName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    text = "${if (item.mediaType == MediaType.VIDEO) "Video" else "Photo"} • ${formatBytes(item.sizeBytes)} • ${formatTimestamp(item.addedAt)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "Options")
                }
                MediaContextMenu(
                    expanded = showMenu,
                    isPrivate = item.isPrivate,
                    onDismiss = { showMenu = false },
                    onOpen = { showMenu = false; onClick() },
                    onMoveAlbum = { showMenu = false; onMoveAlbum() },
                    onTogglePrivate = { showMenu = false; onTogglePrivate() },
                    onExport = { showMenu = false; onExport() },
                    onDelete = { showMenu = false; onDelete() }
                )
            }
        }
    }
}

@Composable
private fun MediaContextMenu(
    expanded: Boolean,
    isPrivate: Boolean,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onMoveAlbum: () -> Unit,
    onTogglePrivate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("Open") }, onClick = onOpen)
        DropdownMenuItem(
            text = { Text("Move to Album") },
            leadingIcon = { Icon(Icons.Rounded.DriveFileMove, contentDescription = null) },
            onClick = onMoveAlbum
        )
        DropdownMenuItem(
            text = { Text(if (isPrivate) "Restore from Private Safe" else "Move to Private Safe") },
            leadingIcon = { Icon(if (isPrivate) Icons.Rounded.LockOpen else Icons.Rounded.Lock, contentDescription = null) },
            onClick = onTogglePrivate
        )
        DropdownMenuItem(
            text = { Text("Export Copy") },
            leadingIcon = { Icon(Icons.Rounded.Upload, contentDescription = null) },
            onClick = onExport
        )
        DropdownMenuItem(
            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
            leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            onClick = onDelete
        )
    }
}

@Composable
private fun GalleryPhotoViewerDialog(
    item: GalleryMediaItem,
    onDismiss: () -> Unit,
    onTogglePrivate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1.2f) {
                                scale = 1f; offsetX = 0f; offsetY = 0f
                            } else {
                                scale = 2.4f
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val nextScale = (scale * zoom).coerceIn(1f, 5f)
                        scale = nextScale
                        if (nextScale > 1f) {
                            offsetX += pan.x
                            offsetY += pan.y
                        } else {
                            offsetX = 0f; offsetY = 0f
                        }
                    }
                }
        ) {
            AsyncImage(
                model = File(item.filePath),
                contentDescription = item.displayName,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0x88000000))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close Viewer", tint = Color.White)
                    }
                    Text(item.displayName, color = Color.White, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Row {
                    IconButton(onClick = onTogglePrivate) {
                        Icon(
                            imageVector = if (item.isPrivate) Icons.Rounded.LockOpen else Icons.Rounded.Lock,
                            contentDescription = "Toggle Privacy",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = onExport) {
                        Icon(Icons.Rounded.Upload, contentDescription = "Export Copy", tint = Color.White)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = Color(0xFFFCA5A5))
                    }
                }
            }
        }
    }
}

@Composable
private fun GalleryVideoPlayerDialog(
    item: GalleryMediaItem,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val player = remember(item.filePath) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(item.filePath))))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        onDispose {
            player.release()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0x88000000))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close Video Player", tint = Color.White)
                }
                Text(item.displayName, color = Color.White, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

private fun formatDurationMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return String.format(Locale.US, "%d:%02d", mins, secs)
}
