package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.data.model.PcSettingsState
import com.example.data.model.SystemStatus
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DesktopLockScreen(
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    hasPinConfigured: Boolean,
    errorMessage: String?,
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val canBiometric = remember(viewModel, settings.lockScreenBiometricEnabled) {
        settings.lockScreenBiometricEnabled && viewModel.canUseBiometrics()
    }

    var showSignInPanel by remember { mutableStateOf(false) }
    var showRecoveryDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var showPin by remember { mutableStateOf(false) }

    val nowDate = remember(systemStatus.currentTimeMillis) { Date(systemStatus.currentTimeMillis) }
    val clockPattern = if (settings.lockScreenShowClockSeconds) "HH:mm:ss" else "HH:mm"
    val timeStr = remember(systemStatus.currentTimeMillis, clockPattern) {
        SimpleDateFormat(clockPattern, Locale.getDefault()).format(nowDate)
    }
    val dateStr = remember(systemStatus.currentTimeMillis) {
        SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(nowDate)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                if (!showSignInPanel) showSignInPanel = true
            }
            .testTag("desktop_lock_screen")
    ) {
        WallpaperSurface(
            wallpaperId = settings.lockWallpaperId,
            customUri = settings.customLockWallpaperUri,
            backgroundArgb = settings.desktopBackgroundArgb,
            fitOption = settings.wallpaperFit,
            dimAlpha = if (showSignInPanel) 0.48f else 0.22f
        )

        // Subtle scrim gradient for legibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x55000000),
                            Color(0x22000000),
                            Color(0x88000000)
                        )
                    )
                )
        )

        // Top Bar: Status Indicators (Wi-Fi, Battery %, Launcher Lock Badge)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 24.dp, vertical = 18.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0x550F172A),
                modifier = Modifier.border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("PC Desktop Lock", color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0x550F172A),
                modifier = Modifier.border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (systemStatus.wifiConnected) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                        contentDescription = "Network",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (systemStatus.isCharging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryFull,
                            contentDescription = "Battery",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "${systemStatus.batteryPercent}%",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = JetBrainsMonoFamily
                        )
                    }
                }
            }
        }

        // Main Animated Transition: Ambient Clock Cover <-> Sign-In Screen
        AnimatedContent(
            targetState = showSignInPanel,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            modifier = Modifier.align(Alignment.Center),
            label = "lock_screen_state"
        ) { signingIn ->
            if (!signingIn) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = timeStr,
                        color = Color.White,
                        fontSize = 72.sp,
                        fontWeight = FontWeight.Light,
                        fontFamily = JetBrainsMonoFamily
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = dateStr,
                        color = Color.White.copy(alpha = 0.92f),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(28.dp))
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = Color(0x660F172A),
                        modifier = Modifier
                            .clip(RoundedCornerShape(28.dp))
                            .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(28.dp))
                            .clickable { showSignInPanel = true }
                            .testTag("lock_screen_reveal_signin")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp)
                        ) {
                            Icon(Icons.Rounded.LockOpen, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Click or Tap to Unlock",
                                color = Color.White,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = pcPalette.flyoutSurface.copy(alpha = 0.94f),
                    tonalElevation = 16.dp,
                    shadowElevation = 24.dp,
                    modifier = Modifier
                        .widthIn(min = 300.dp, max = 380.dp)
                        .padding(horizontal = 20.dp)
                        .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(20.dp))
                        .testTag("lock_screen_signin_card")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            IconButton(onClick = { showSignInPanel = false }) {
                                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to lock cover")
                            }
                            Spacer(Modifier.weight(1f))
                            Text(
                                text = timeStr,
                                style = MaterialTheme.typography.labelLarge,
                                fontFamily = JetBrainsMonoFamily
                            )
                        }

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(pcPalette.accent.copy(alpha = 0.2f))
                                .border(1.5.dp, pcPalette.accent, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Person,
                                contentDescription = null,
                                tint = pcPalette.accent,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = android.os.Build.MODEL ?: "Android PC",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        if (!hasPinConfigured) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "Quick unlock enabled. Configure a PIN in PC Settings → Security for stronger protection.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.attemptUnlockDesktopWithPin("") },
                                modifier = Modifier.fillMaxWidth().testTag("lock_screen_quick_unlock_button")
                            ) {
                                Text("Sign In to Desktop")
                            }
                        } else {
                            Spacer(Modifier.height(14.dp))
                            OutlinedTextField(
                                value = pinInput,
                                onValueChange = { pinInput = it },
                                label = { Text("Enter PIN or Password") },
                                singleLine = true,
                                visualTransformation = if (showPin) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { showPin = !showPin }) {
                                        Icon(
                                            imageVector = if (showPin) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                            contentDescription = "Toggle visibility"
                                        )
                                    }
                                },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        if (viewModel.attemptUnlockDesktopWithPin(pinInput)) {
                                            pinInput = ""
                                        }
                                    }
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("lock_screen_pin_input")
                            )

                            if (!errorMessage.isNullOrBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = errorMessage,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    textAlign = TextAlign.Center
                                )
                            }

                            Spacer(Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    if (viewModel.attemptUnlockDesktopWithPin(pinInput)) {
                                        pinInput = ""
                                    }
                                },
                                enabled = pinInput.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("lock_screen_unlock_button")
                            ) {
                                Text("Unlock")
                            }

                            if (canBiometric && activity != null) {
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = { viewModel.attemptUnlockDesktopWithBiometric(activity) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Rounded.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Use Fingerprint / Biometrics")
                                }
                            }

                            Spacer(Modifier.height(6.dp))
                            TextButton(onClick = { showRecoveryDialog = true }) {
                                Text("Forgot PIN? Recover Access")
                            }
                        }
                    }
                }
            }
        }

        // Honest Android Note in footer
        Text(
            text = "Launcher Lock Screen (does not replace Android system lock screen)",
            color = Color.White.copy(alpha = 0.65f),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 14.dp)
        )
    }

    if (showRecoveryDialog) {
        RecoveryAccessDialog(
            viewModel = viewModel,
            onDismiss = { showRecoveryDialog = false },
            onRecovered = { showRecoveryDialog = false }
        )
    }
}
