package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.CornerStyle
import com.example.data.model.DesktopThemePreset
import com.example.data.model.FontStyleOption
import com.example.data.model.IconPackStyle
import com.example.data.model.PcSettingsState
import com.example.data.model.WindowAppearance

@Immutable
data class PcSurfacePalette(
    val isDark: Boolean,
    val themePreset: DesktopThemePreset,
    val accent: Color,
    val windowSurface: Color,
    val windowHeader: Color,
    val windowCard: Color,
    val windowBorder: Color,
    val flyoutSurface: Color,
    val taskbarBase: Color,
    val desktopLabelScrim: Color,
    val hoverHighlight: Color,
    val windowCornerDp: Dp,
    val cardCornerDp: Dp,
    val windowAppearance: WindowAppearance,
    val iconPack: IconPackStyle
)

val LocalPcPalette = staticCompositionLocalOf {
    PcSurfacePalette(
        isDark = true,
        themePreset = DesktopThemePreset.WINDOWS_11,
        accent = Color(0xFF60CDFF),
        windowSurface = DarkSurface,
        windowHeader = Color(0xFF181C24),
        windowCard = DarkSurfaceVariant,
        windowBorder = DarkBorder,
        flyoutSurface = Color(0xEB1D222C),
        taskbarBase = TaskbarDarkBase,
        desktopLabelScrim = Color(0x66000000),
        hoverHighlight = Color(0x1FFFFFFF),
        windowCornerDp = 14.dp,
        cardCornerDp = 10.dp,
        windowAppearance = WindowAppearance.ACRYLIC,
        iconPack = IconPackStyle.FLUENT
    )
}

@Composable
fun PcLauncherTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    settings: PcSettingsState = PcSettingsState(),
    content: @Composable () -> Unit
) {
    val accentPreset = AccentPreset.fromKey(settings.accentKey)
    val accent = settings.customAccentArgb?.let { Color(it.toInt()) }
        ?: if (darkTheme) accentPreset.dark else accentPreset.light

    val isClassic = settings.themePreset == DesktopThemePreset.CLASSIC_WINDOWS ||
        settings.windowAppearance == WindowAppearance.BEVELED

    val windowCorner = when (settings.cornerStyle) {
        CornerStyle.ROUNDED -> if (settings.themePreset == DesktopThemePreset.MACOS_INSPIRED) 18.dp else 14.dp
        CornerStyle.SUBTLE -> 6.dp
        CornerStyle.SQUARE -> 0.dp
    }
    val cardCorner = settings.cornerStyle.cardRadiusDp.dp

    val shapes = Shapes(
        extraSmall = RoundedCornerShape((cardCorner / 2).coerceAtLeast(0.dp)),
        small = RoundedCornerShape(cardCorner),
        medium = RoundedCornerShape(windowCorner),
        large = RoundedCornerShape(windowCorner + 2.dp),
        extraLarge = RoundedCornerShape(windowCorner + 6.dp)
    )

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF00203A),
            primaryContainer = accent.copy(alpha = 0.22f),
            onPrimaryContainer = Color.White,
            secondary = Color(0xFF94A3B8),
            onSecondary = Color(0xFF0F172A),
            background = DarkBackground,
            onBackground = DarkTextPrimary,
            surface = if (isClassic) Color(0xFF262A34) else DarkSurface,
            onSurface = DarkTextPrimary,
            surfaceVariant = DarkSurfaceVariant,
            onSurfaceVariant = DarkTextSecondary,
            outline = DarkBorder,
            error = DangerRed,
            onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.14f),
            onPrimaryContainer = Color(0xFF0B2545),
            secondary = Color(0xFF475569),
            onSecondary = Color.White,
            background = if (isClassic) Color(0xFFD4D0C8) else LightBackground,
            onBackground = LightTextPrimary,
            surface = if (isClassic) Color(0xFFECE9D8) else LightSurface,
            onSurface = LightTextPrimary,
            surfaceVariant = if (isClassic) Color(0xFFD4D0C8) else LightSurfaceVariant,
            onSurfaceVariant = LightTextSecondary,
            outline = LightBorder,
            error = DangerRed,
            onError = Color.White
        )
    }

    val surfaceAlpha = when (settings.windowAppearance) {
        WindowAppearance.ACRYLIC -> if (settings.batterySaverMode) 0.97f else 0.90f
        WindowAppearance.SOLID -> 1.0f
        WindowAppearance.BEVELED -> 1.0f
        WindowAppearance.MINIMAL -> 0.86f
    }

    val pcPalette = if (darkTheme) {
        PcSurfacePalette(
            isDark = true,
            themePreset = settings.themePreset,
            accent = accent,
            windowSurface = if (isClassic) Color(0xFF262A34) else Color(0xFF1F242D).copy(alpha = surfaceAlpha),
            windowHeader = if (isClassic) Color(0xFF0054A6) else Color(0xFF171B22),
            windowCard = DarkSurfaceVariant,
            windowBorder = if (isClassic) Color(0xFF8C97A8) else if (settings.windowAppearance == WindowAppearance.MINIMAL) Color(0x18FFFFFF) else Color(0x2BFFFFFF),
            flyoutSurface = Color(0xFF1B2029).copy(alpha = if (settings.batterySaverMode) 0.98f else 0.93f),
            taskbarBase = settings.customTaskbarArgb?.let { Color(it.toInt()) }
                ?: if (isClassic) Color(0xFF1D222B) else TaskbarDarkBase,
            desktopLabelScrim = Color(0x70000000),
            hoverHighlight = Color(0x1CFFFFFF),
            windowCornerDp = windowCorner,
            cardCornerDp = cardCorner,
            windowAppearance = settings.windowAppearance,
            iconPack = settings.iconPack
        )
    } else {
        PcSurfacePalette(
            isDark = false,
            themePreset = settings.themePreset,
            accent = accent,
            windowSurface = if (isClassic) Color(0xFFECE9D8) else Color(0xFFF8FAFC).copy(alpha = surfaceAlpha),
            windowHeader = if (isClassic) Color(0xFF0A246A) else Color(0xFFEEF2F6),
            windowCard = if (isClassic) Color(0xFFF5F4EA) else Color(0xFFFFFFFF),
            windowBorder = if (isClassic) Color(0xFF808080) else if (settings.windowAppearance == WindowAppearance.MINIMAL) Color(0x140F172A) else Color(0x220F172A),
            flyoutSurface = Color(0xFFF4F7FA).copy(alpha = if (settings.batterySaverMode) 0.99f else 0.95f),
            taskbarBase = settings.customTaskbarArgb?.let { Color(it.toInt()) }
                ?: if (isClassic) Color(0xFFD4D0C8) else TaskbarLightBase,
            desktopLabelScrim = Color(0x66000000),
            hoverHighlight = Color(0x14000000),
            windowCornerDp = windowCorner,
            cardCornerDp = cardCorner,
            windowAppearance = settings.windowAppearance,
            iconPack = settings.iconPack
        )
    }

    CompositionLocalProvider(LocalPcPalette provides pcPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = buildPcTypography(settings.fontStyle),
            shapes = shapes,
            content = content
        )
    }
}
