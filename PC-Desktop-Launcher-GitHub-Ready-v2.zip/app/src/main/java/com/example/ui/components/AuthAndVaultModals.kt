package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.AuthGateState
import com.example.ui.viewmodel.LauncherViewModel

@Composable
fun SecurityAuthDialog(
    authGate: AuthGateState,
    biometricAllowed: Boolean,
    viewModel: LauncherViewModel
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val canBiometric = remember(viewModel, biometricAllowed) {
        biometricAllowed && viewModel.canUseBiometrics()
    }
    var pin by remember { mutableStateOf("") }
    var showPin by remember { mutableStateOf(false) }
    var showRecovery by remember { mutableStateOf(false) }

    if (showRecovery) {
        RecoveryAccessDialog(
            viewModel = viewModel,
            onDismiss = { showRecovery = false },
            onRecovered = { showRecovery = false }
        )
        return
    }

    AlertDialog(
        onDismissRequest = { viewModel.dismissAuthGate() },
        icon = { Icon(Icons.Rounded.Lock, contentDescription = null) },
        title = { Text(authGate.purpose.title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = authGate.purpose.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text("PIN or Password") },
                    singleLine = true,
                    visualTransformation = if (showPin) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showPin = !showPin }) {
                            Icon(
                                imageVector = if (showPin) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = "Toggle visibility"
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("auth_gate_pin_input")
                )
                if (!authGate.error.isNullOrBlank()) {
                    Text(
                        text = authGate.error,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (canBiometric && activity != null) {
                    OutlinedButton(
                        onClick = { viewModel.submitAuthGateBiometric(activity) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Unlock with Fingerprint")
                    }
                }
                TextButton(
                    onClick = { showRecovery = true },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Recover Access")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { viewModel.submitAuthGatePin(pin) },
                enabled = pin.isNotBlank(),
                modifier = Modifier.testTag("auth_gate_unlock_button")
            ) {
                Text("Unlock")
            }
        },
        dismissButton = {
            TextButton(onClick = { viewModel.dismissAuthGate() }) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RecoveryAccessDialog(
    viewModel: LauncherViewModel,
    onDismiss: () -> Unit,
    onRecovered: () -> Unit
) {
    val question by viewModel.securityQuestion.collectAsStateWithLifecycle()
    var useBackupKey by remember { mutableStateOf(question.isNullOrBlank()) }
    var recoveryInput by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var verified by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Key, contentDescription = null) },
        title = { Text(if (!verified) "Recover Launcher Access" else "Set New PIN / Password") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                if (!verified) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!question.isNullOrBlank()) {
                            FilterChip(
                                selected = !useBackupKey,
                                onClick = { useBackupKey = false; error = null },
                                label = { Text("Security Question") }
                            )
                        }
                        FilterChip(
                            selected = useBackupKey,
                            onClick = { useBackupKey = true; error = null },
                            label = { Text("Backup Key") }
                        )
                    }

                    if (!useBackupKey && !question.isNullOrBlank()) {
                        Text(
                            text = question!!,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Medium
                        )
                        OutlinedTextField(
                            value = recoveryInput,
                            onValueChange = { recoveryInput = it; error = null },
                            label = { Text("Recovery Answer") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("recovery_answer_input")
                        )
                    } else {
                        Text(
                            text = "Enter the 12-character Backup Recovery Key generated when you created your PIN (e.g., PCD-XXXX-XXXX).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = recoveryInput,
                            onValueChange = { recoveryInput = it; error = null },
                            label = { Text("Backup Recovery Key") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("recovery_key_input")
                        )
                    }
                } else {
                    Text(
                        text = "Identity verified! Choose a new PIN or password (at least 4 characters), or keep your existing setup.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { newPin = it; error = null },
                        label = { Text("New PIN / Password") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("recovery_new_pin_input")
                    )
                }

                if (!error.isNullOrBlank()) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            if (!verified) {
                Button(
                    onClick = {
                        val ok = viewModel.verifyRecoveryCredential(recoveryInput, isBackupKey = useBackupKey)
                        if (ok) {
                            verified = true
                            error = null
                        } else {
                            error = if (useBackupKey) "Backup key does not match." else "Answer does not match."
                        }
                    },
                    enabled = recoveryInput.isNotBlank(),
                    modifier = Modifier.testTag("recovery_verify_button")
                ) {
                    Text("Verify")
                }
            } else {
                Button(
                    onClick = {
                        viewModel.resetPinAfterRecovery(newPin)
                            .onSuccess { onRecovered() }
                            .onFailure { error = it.message }
                    },
                    enabled = newPin.trim().length >= 4,
                    modifier = Modifier.testTag("recovery_save_pin_button")
                ) {
                    Text("Save New PIN")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = {
                if (verified) onRecovered() else onDismiss()
            }) {
                Text(if (verified) "Done" else "Cancel")
            }
        }
    )
}

@Composable
fun PinSetupWizardDialog(
    viewModel: LauncherViewModel,
    onDismiss: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("What is your recovery keyword?") }
    var answer by remember { mutableStateOf("") }
    var generatedCode by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Shield, contentDescription = null) },
        title = {
            Text(if (generatedCode == null) "Set Launcher PIN & Recovery" else "Save Your Backup Key")
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                if (generatedCode == null) {
                    Text(
                        text = "Protects your Desktop Lock Screen, Private Vault (Hidden Apps), and Private Gallery Safe. Stored locally via AndroidKeyStore + salted PBKDF2.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it; error = null },
                        label = { Text("PIN or Password (min 4 chars)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("setup_pin_input")
                    )
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { confirmPin = it; error = null },
                        label = { Text("Confirm PIN / Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("setup_confirm_pin_input")
                    )
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it; error = null },
                        label = { Text("Recovery Question") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("setup_question_input")
                    )
                    OutlinedTextField(
                        value = answer,
                        onValueChange = { answer = it; error = null },
                        label = { Text("Recovery Answer") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("setup_answer_input")
                    )
                } else {
                    Text(
                        text = "Write down or store this Backup Recovery Key safely. It is shown only once and can unlock your Private Vault or Lock Screen if you forget your PIN.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Surface(
                        color = pcPalette.windowCard,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = generatedCode!!,
                            style = MaterialTheme.typography.headlineSmall,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(16.dp).testTag("generated_recovery_key_text")
                        )
                    }
                }

                if (!error.isNullOrBlank()) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            if (generatedCode == null) {
                Button(
                    onClick = {
                        when {
                            pin.trim().length < 4 -> error = "PIN must be at least 4 characters."
                            pin.trim() != confirmPin.trim() -> error = "PIN entries do not match."
                            answer.trim().isEmpty() -> error = "Please enter a recovery answer."
                            else -> {
                                viewModel.setupPinAndRecovery(pin, question, answer)
                                    .onSuccess { code -> generatedCode = code }
                                    .onFailure { error = it.message }
                            }
                        }
                    },
                    modifier = Modifier.testTag("setup_save_security_button")
                ) {
                    Text("Enable Security")
                }
            } else {
                Button(
                    onClick = {
                        viewModel.dismissRecoveryKeyBanner()
                        onDismiss()
                    },
                    modifier = Modifier.testTag("setup_done_security_button")
                ) {
                    Text("I Saved My Key")
                }
            }
        },
        dismissButton = {
            if (generatedCode == null) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
