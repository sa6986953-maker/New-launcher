package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasAnyAncestor
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.LauncherDatabase
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherMode
import com.example.data.model.PcSettingsState
import com.example.data.model.WallpaperCategory
import com.example.data.model.WallpaperPreset
import com.example.data.repository.DesktopRepository
import com.example.data.repository.GalleryRepository
import com.example.data.security.SecurityVaultManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SecurityGalleryUpgradeTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `security vault manager hashes verifies and recovers PIN securely`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vault = SecurityVaultManager(context)
        vault.clearSecurityConfig()
        assertFalse(vault.hasPinConfigured())

        val backupKey = vault.setupPinAndRecovery(
            pin = "4829",
            recoveryQuestion = "First pet?",
            recoveryAnswer = "Sparky"
        )
        assertTrue(vault.hasPinConfigured())
        assertTrue(backupKey.startsWith("PCD-"))
        assertTrue(vault.verifyPin("4829"))
        assertFalse(vault.verifyPin("0000"))

        assertTrue(vault.verifyRecoveryAnswer("  sparky "))
        assertFalse(vault.verifyRecoveryAnswer("wrong"))

        assertTrue(vault.verifyBackupKey(backupKey.lowercase()))
        assertFalse(vault.verifyBackupKey("PCD-0000-0000"))

        vault.updatePin("9173")
        assertTrue(vault.verifyPin("9173"))
        assertFalse(vault.verifyPin("4829"))

        vault.clearSecurityConfig()
        assertFalse(vault.hasPinConfigured())
    }

    @Test
    fun `gallery repository manages albums app-private media privacy and cleanup`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LauncherDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = GalleryRepository(context, db.launcherDao())
            repo.ensureSeeded()

            val albums = repo.albums.first()
            assertEquals(3, albums.size)
            assertTrue(albums.any { it.isPrivate && it.id == GalleryRepository.DEFAULT_ALBUM_PRIVATE_SAFE })

            val customAlbum = repo.createAlbum("Travel", isPrivate = false)
            val tempPhoto = File(context.cacheDir, "sample_pic.jpg").apply {
                writeBytes(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0x01, 0x02))
            }

            val imported = repo.importLocalFile(tempPhoto, targetAlbumId = customAlbum.id).getOrThrow()
            assertFalse(imported.isPrivate)
            assertEquals(customAlbum.id, imported.albumId)
            assertTrue(File(imported.filePath).exists())

            repo.setMediaPrivate(imported.id, true)
            val afterPrivate = repo.mediaItems.first().first { it.id == imported.id }
            assertTrue(afterPrivate.isPrivate)
            assertEquals(GalleryRepository.DEFAULT_ALBUM_PRIVATE_SAFE, afterPrivate.albumId)

            repo.deleteMedia(imported.id)
            assertTrue(repo.mediaItems.first().none { it.id == imported.id })
            assertFalse(File(imported.filePath).exists())
        } finally {
            db.close()
        }
    }

    @Test
    fun `desktop repository hides and restores apps cleanly without data loss`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LauncherDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = DesktopRepository(db.launcherDao())
            val demoApp = InstalledApp("com.demo.notes", "com.demo.notes.Main", "Demo Notes")
            repo.ensureSeeded(listOf(demoApp))

            repo.hideApp(demoApp)
            val hidden = repo.hiddenApps.first()
            assertEquals(1, hidden.size)
            assertEquals(demoApp.componentKey, hidden.first().componentKey)

            repo.unhideApp(demoApp.componentKey)
            assertTrue(repo.hiddenApps.first().isEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `settings ships 24 wallpapers across 6 categories and dual mode defaults`() {
        assertEquals(24, WallpaperPreset.entries.size)
        WallpaperCategory.entries.forEach { cat ->
            assertTrue(WallpaperPreset.entries.any { it.category == cat })
        }
        val defaults = PcSettingsState()
        assertEquals(LauncherMode.DESKTOP, defaults.launcherMode)
        assertEquals("//vault", defaults.vaultSecretPhrase)
    }

    @Test
    @Config(qualifiers = "w840dp-h390dp-land")
    fun `dual mode toggle switches between desktop and mobile home smoothly`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("taskbar_mode_switch").assertIsDisplayed().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("mobile_home_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("mobile_to_desktop_switch").assertIsDisplayed().performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("start_button").assertIsDisplayed()
    }

    @Test
    @Config(qualifiers = "w840dp-h390dp-land")
    fun `pin setup desktop lock screen unlock and discreet secret vault flow`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        SecurityVaultManager(context).clearSecurityConfig()

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNode(
            hasText("PC Settings") and hasAnyAncestor(hasTestTag("start_menu_panel"))
        ).performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_sidebar_list")
            .performScrollToNode(hasTestTag("settings_tab_SECURITY"))
        composeRule.onNodeWithTag("settings_tab_SECURITY").performClick()
        composeRule.waitForIdle()

        // Setup PIN & Recovery
        composeRule.onNodeWithTag("security_setup_pin_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("setup_pin_input").performTextInput("2468")
        composeRule.onNodeWithTag("setup_confirm_pin_input").performTextInput("2468")
        composeRule.onNodeWithTag("setup_answer_input").performTextInput("ocean")
        composeRule.onNodeWithTag("setup_save_security_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("generated_recovery_key_text").assertIsDisplayed()
        composeRule.onNodeWithTag("setup_done_security_button").performClick()
        composeRule.waitForIdle()

        // Lock Desktop and Unlock with PIN
        composeRule.onNodeWithTag("security_lock_now_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("desktop_lock_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("lock_screen_reveal_signin").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("lock_screen_pin_input").performTextInput("2468")
        composeRule.onNodeWithTag("lock_screen_unlock_button").performClick()
        composeRule.waitForIdle()

        // Switch vault entry to Secret Command and open Private Vault discreetly
        composeRule.onNodeWithTag("settings_content_list")
            .performScrollToNode(hasText("Start Search Secret Command"))
        composeRule.onNodeWithText("Start Search Secret Command").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("start_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_menu_search_input").performTextInput("//vault")
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_secret_vault_result").assertIsDisplayed().performClick()
        composeRule.waitForIdle()

        // Auth Gate -> Enter PIN -> Private Vault Window opens
        composeRule.onNodeWithTag("auth_gate_pin_input").performTextInput("2468")
        composeRule.onNodeWithTag("auth_gate_unlock_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("private_vault_window").assertIsDisplayed()
        composeRule.onNodeWithTag("vault_lock_button").performClick()
        composeRule.waitForIdle()

        SecurityVaultManager(context).clearSecurityConfig()
    }

    @Test
    @Config(qualifiers = "w840dp-h390dp-land")
    fun `gallery window opens tabs and creates new album`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNode(
            hasText("Gallery") and hasAnyAncestor(hasTestTag("start_menu_panel"))
        ).performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("gallery_window").assertIsDisplayed()
        composeRule.onNodeWithTag("gallery_tab_ALBUMS").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("gallery_new_album_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Create").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Favorites").assertIsDisplayed()
    }
}
