package com.example

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.LauncherDatabase
import com.example.data.local.SavedThemeEntity
import com.example.data.model.AnimationEffectStyle
import com.example.data.model.CornerStyle
import com.example.data.model.DesktopThemePreset
import com.example.data.model.ExplorerRootSection
import com.example.data.model.FontStyleOption
import com.example.data.model.IconPackStyle
import com.example.data.model.IconSizeOption
import com.example.data.model.OrientationMode
import com.example.data.model.PcSettingsState
import com.example.data.model.ScreenLayoutDensity
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarSizeOption
import com.example.data.model.TaskbarStyle
import com.example.data.model.ThemeMode
import com.example.data.model.WallpaperFitOption
import com.example.data.model.WindowAppearance
import com.example.data.repository.DesktopRepository
import com.example.data.repository.FileExplorerRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches PC Desktop Launcher`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PC Desktop Launcher", appName)
    }

    @Test
    fun `manifest registers HOME launcher intent filter`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        val resolved = context.packageManager.queryIntentActivities(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
        val hasLauncherActivity = resolved.any {
            it.activityInfo.packageName == context.packageName &&
                it.activityInfo.name == MainActivity::class.java.name
        }
        assertTrue("MainActivity must be registered as a valid Android HOME launcher", hasLauncherActivity)
    }

    @Test
    fun `default settings enforce full screen immersive and landscape pc mode`() {
        val defaults = PcSettingsState()
        assertTrue(defaults.fullScreenImmersive)
        assertEquals(OrientationMode.LANDSCAPE, defaults.orientationMode)
        assertEquals(DesktopThemePreset.WINDOWS_11, defaults.themePreset)
        assertEquals(TaskbarPosition.BOTTOM, defaults.taskbarPosition)
    }

    @Test
    fun `theme json export and import preserves all customization fields`() {
        val custom = PcSettingsState(
            themePreset = DesktopThemePreset.LINUX_INSPIRED,
            themeMode = ThemeMode.LIGHT,
            accentKey = "amber",
            customAccentArgb = 0xFFFF8800L,
            desktopBackgroundArgb = 0xFF008080L,
            wallpaperId = "aurora",
            wallpaperFit = WallpaperFitOption.FIT,
            wallpaperDimAlpha = 0.35f,
            fullScreenImmersive = false,
            orientationMode = OrientationMode.PORTRAIT,
            desktopScale = 1.15f,
            screenLayout = ScreenLayoutDensity.SPACIOUS_MONITOR,
            iconSize = IconSizeOption.LARGE,
            iconScale = 1.25f,
            iconPack = IconPackStyle.CLASSIC,
            showDesktopIconScrim = false,
            autoArrangeGrid = true,
            showDesktopClock = false,
            showFileExtensions = false,
            taskbarPosition = TaskbarPosition.LEFT,
            taskbarSize = TaskbarSizeOption.LARGE,
            taskbarHeightOverrideDp = 64,
            taskbarIconSpacingDp = 10,
            taskbarStyle = TaskbarStyle.CUSTOM,
            taskbarTransparency = 0.72f,
            customTaskbarArgb = 0xFF223344L,
            showTaskbarSearch = false,
            showTaskbarDate = false,
            showTaskbarNotificationBadge = false,
            windowAppearance = WindowAppearance.BEVELED,
            cornerStyle = CornerStyle.SQUARE,
            fontStyle = FontStyleOption.UBUNTU,
            animationsEnabled = false,
            animationEffect = AnimationEffectStyle.REDUCED,
            batterySaverMode = true,
            hapticFeedbackEnabled = false,
            showToastNotifications = false
        )

        val json = custom.toThemeJson()
        val restored = PcSettingsState.applyJsonTo(PcSettingsState(), json)

        assertEquals(custom.themePreset, restored.themePreset)
        assertEquals(custom.themeMode, restored.themeMode)
        assertEquals(custom.customAccentArgb, restored.customAccentArgb)
        assertEquals(custom.desktopBackgroundArgb, restored.desktopBackgroundArgb)
        assertEquals(custom.wallpaperId, restored.wallpaperId)
        assertEquals(custom.wallpaperFit, restored.wallpaperFit)
        assertEquals(custom.wallpaperDimAlpha, restored.wallpaperDimAlpha, 0.01f)
        assertEquals(custom.fullScreenImmersive, restored.fullScreenImmersive)
        assertEquals(custom.orientationMode, restored.orientationMode)
        assertEquals(custom.desktopScale, restored.desktopScale, 0.01f)
        assertEquals(custom.screenLayout, restored.screenLayout)
        assertEquals(custom.iconSize, restored.iconSize)
        assertEquals(custom.iconScale, restored.iconScale, 0.01f)
        assertEquals(custom.iconPack, restored.iconPack)
        assertEquals(custom.taskbarPosition, restored.taskbarPosition)
        assertEquals(custom.taskbarHeightOverrideDp, restored.taskbarHeightOverrideDp)
        assertEquals(custom.taskbarIconSpacingDp, restored.taskbarIconSpacingDp)
        assertEquals(custom.taskbarStyle, restored.taskbarStyle)
        assertEquals(custom.customTaskbarArgb, restored.customTaskbarArgb)
        assertEquals(custom.windowAppearance, restored.windowAppearance)
        assertEquals(custom.cornerStyle, restored.cornerStyle)
        assertEquals(custom.fontStyle, restored.fontStyle)
        assertEquals(custom.animationEffect, restored.animationEffect)
        assertEquals(custom.batterySaverMode, restored.batterySaverMode)
    }

    @Test
    fun `saved theme entity persists and deletes in launcher database`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LauncherDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = db.launcherDao()
            val themeJson = PcSettingsState(themePreset = DesktopThemePreset.CLASSIC_WINDOWS).toThemeJson()
            val entity = SavedThemeEntity(
                id = "theme_1",
                name = "Retro 95 Setup",
                themeJson = themeJson,
                createdAt = 123456L
            )
            dao.upsertSavedTheme(entity)
            val saved = dao.observeSavedThemes().first()
            assertEquals(1, saved.size)
            assertEquals("Retro 95 Setup", saved.first().name)

            dao.deleteSavedTheme("theme_1")
            assertTrue(dao.observeSavedThemes().first().isEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `desktop repository seeds defaults and supports recycle bin restore`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LauncherDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = DesktopRepository(db.launcherDao())
            repo.ensureSeeded(emptyList())
            val seeded = repo.desktopItems.first()
            assertTrue(seeded.any { it.id == "sys_this_pc" })
            assertTrue(seeded.any { it.id == "sys_pc_settings" })
            assertTrue(seeded.any { it.id == "sys_recycle_bin" })

            repo.createDesktopFolder("Projects")
            val afterCreate = repo.desktopItems.first()
            val folder = afterCreate.first { it.title == "Projects" }

            repo.moveToRecycleBin(folder)
            val bin = repo.recycleBinItems.first()
            assertEquals(1, bin.size)
            assertEquals("Projects", bin.first().title)

            repo.restoreFromRecycleBin(bin.first())
            val afterRestore = repo.desktopItems.first()
            assertTrue(afterRestore.any { it.title == "Projects" })
            assertTrue(repo.recycleBinItems.first().isEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `file explorer repository creates lists renames and deletes workspace items`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LauncherDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = FileExplorerRepository(context, db.launcherDao())
            repo.ensureWorkspaceSeeded()
            val docsPath = repo.getSectionPath(ExplorerRootSection.DOCUMENTS)

            repo.createFolder(docsPath, "TestDir", isSaf = false).getOrThrow()
            val createdPath = repo.createTextFile(docsPath, "Draft.txt", "Hello PC", isSaf = false).getOrThrow()
            val nodes = repo.listLocalDirectory(docsPath)
            assertTrue(nodes.any { it.isDirectory && it.name == "TestDir" })
            val fileNode = nodes.first { !it.isDirectory && it.pathOrUri == createdPath }

            val readBack = repo.readTextFile(fileNode.pathOrUri, isSaf = false).getOrThrow()
            assertEquals("Hello PC", readBack)

            repo.renameNode(fileNode, "Renamed.txt").getOrThrow()
            val afterRename = repo.listLocalDirectory(docsPath)
            val renamedNode = afterRename.first { it.name == "Renamed.txt" }

            repo.deleteNode(renamedNode).getOrThrow()
            val afterDelete = repo.listLocalDirectory(docsPath)
            assertTrue(afterDelete.none { it.name == "Renamed.txt" })
        } finally {
            db.close()
        }
    }

    @Test
    @Config(qualifiers = "w840dp-h390dp-land")
    fun `main activity defaults to sensor landscape orientation`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, activity.requestedOrientation)
    }
}
