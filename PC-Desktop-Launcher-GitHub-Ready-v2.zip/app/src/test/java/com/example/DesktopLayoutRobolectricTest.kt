package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasAnyAncestor
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DesktopLayoutRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    private fun openPcSettingsFromStartMenu() {
        composeRule.onNodeWithTag("start_button").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_menu_panel").assertIsDisplayed()
        composeRule.onNode(
            hasText("PC Settings") and hasAnyAncestor(hasTestTag("start_menu_panel"))
        ).performClick()
        composeRule.waitForIdle()
    }

    private fun selectSettingsTab(tabTag: String) {
        composeRule.onNodeWithTag("settings_sidebar_list")
            .performScrollToNode(hasTestTag(tabTag))
        composeRule.onNodeWithTag(tabTag).performClick()
        composeRule.waitForIdle()
    }

    @Test
    @Config(qualifiers = "w840dp-h390dp-land")
    fun `landscape desktop opens start menu and navigates all 12 settings tabs`() {
        composeRule.waitForIdle()
        openPcSettingsFromStartMenu()

        // Navigate through all 12 functional Settings categories
        val tabTags = listOf(
            "settings_tab_PERSONALIZATION",
            "settings_tab_DISPLAY",
            "settings_tab_DESKTOP",
            "settings_tab_TASKBAR",
            "settings_tab_THEMES",
            "settings_tab_ICONS",
            "settings_tab_WALLPAPER",
            "settings_tab_APPLICATIONS",
            "settings_tab_PERFORMANCE",
            "settings_tab_SOUND",
            "settings_tab_NOTIFICATIONS",
            "settings_tab_SECURITY",
            "settings_tab_ABOUT"
        )
        tabTags.forEach { tag ->
            selectSettingsTab(tag)
        }

        // Verify About Launcher tab content renders cleanly
        composeRule.onNodeWithTag("settings_set_default_home").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_content_list")
            .performScrollToNode(hasText("Package ID"))
        composeRule.onNodeWithText(BuildConfig.APPLICATION_ID).assertIsDisplayed()
    }

    @Test
    @Config(qualifiers = "w840dp-h390dp-land")
    fun `switching taskbar edges and theme presets works smoothly`() {
        composeRule.waitForIdle()
        openPcSettingsFromStartMenu()

        // Open Themes tab and apply Linux Desktop (switches taskbar to Left & Ubuntu font)
        selectSettingsTab("settings_tab_THEMES")
        composeRule.onNodeWithTag("settings_content_list")
            .performScrollToNode(hasText("Linux Desktop"))
        composeRule.onNodeWithText("Linux Desktop").performClick()
        composeRule.waitForIdle()

        // Verify Start button remains displayed in vertical left dock
        composeRule.onNodeWithTag("start_button").assertIsDisplayed()

        // Open Taskbar tab and switch to Top, Right, Bottom
        selectSettingsTab("settings_tab_TASKBAR")
        composeRule.onNodeWithText("Top").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_button").assertIsDisplayed()

        composeRule.onNodeWithText("Right").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_button").assertIsDisplayed()

        composeRule.onNodeWithText("Bottom").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_button").assertIsDisplayed()

        // Restore Windows 11 preset cleanly
        selectSettingsTab("settings_tab_THEMES")
        composeRule.onNodeWithTag("settings_content_list")
            .performScrollToNode(hasText("Windows 11"))
        composeRule.onNodeWithText("Windows 11").performClick()
        composeRule.waitForIdle()
    }

    @Test
    @Config(qualifiers = "w390dp-h840dp-port")
    fun `portrait mobile layout renders desktop and compact settings`() {
        composeRule.waitForIdle()
        openPcSettingsFromStartMenu()

        composeRule.onNodeWithTag("settings_tab_DISPLAY").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Immersive Full-Screen Mode").assertIsDisplayed()
    }
}
