# PC Desktop Launcher — Android Project

## GitHub Actions APK build

This repository is an Android Gradle project. The Gradle project root is the repository root and contains:

- `settings.gradle.kts`
- `build.gradle.kts`
- `app/build.gradle.kts`
- `gradle/libs.versions.toml`

### Build an APK

1. Create a GitHub repository.
2. Extract this ZIP on your device/computer.
3. Upload **the contents** of the extracted folder to the repository root (do not upload the ZIP as the only file).
4. Open the repository's **Actions** tab.
5. Select **Android APK Build**.
6. Select **Run workflow**.
7. When the run completes successfully, open the run and download the artifact named `PC-Desktop-Launcher-debug-APK`.

The workflow creates a temporary Android debug keystore during each run and builds:
`app/build/outputs/apk/debug/app-debug.apk`

This is a debug APK for testing. A separately managed, persistent signing key is required for release distribution and seamless updates between separately signed builds.

## Local build

Open the repository root in Android Studio and allow Gradle sync to finish. The project currently uses Gradle 9.3.1, Android Gradle Plugin 9.1.1, JDK 17, and compile SDK 36.1.

## Notes

- Keep the repository structure intact.
- Do not upload `.env` files or signing keys to GitHub.
- The GitHub workflow builds the existing source code; it does not automatically implement features that are only described in a prompt.
